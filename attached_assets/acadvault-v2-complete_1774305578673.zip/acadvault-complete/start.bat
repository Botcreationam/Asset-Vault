@echo off
REM ============================================================
REM  AcadVault — Windows Quick Start
REM  Double-click this file to start the app
REM ============================================================

title AcadVault

echo.
echo  ╔══════════════════════════════════════╗
echo  ║         AcadVault  Launcher          ║
echo  ╚══════════════════════════════════════╝
echo.

REM Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found!
    echo Please install it from https://nodejs.org
    pause
    exit /b 1
)

echo [OK] Node.js found: 
node -v

REM Copy .env if missing
if not exist "backend\.env" (
    copy "backend\.env.example" "backend\.env" >nul
    echo.
    echo [NOTICE] Created backend\.env
    echo Please open backend\.env and add your PostgreSQL database URL
    echo Then run this file again.
    echo.
    notepad backend\.env
    pause
    exit /b 0
)

REM Install dependencies if needed
if not exist "backend\node_modules" (
    echo.
    echo [Installing backend dependencies...]
    cd backend
    call npm install
    cd ..
)

if not exist "frontend\node_modules" (
    echo.
    echo [Installing frontend dependencies...]
    cd frontend
    call npm install
    cd ..
)

REM Run migration if asked
echo.
set /p MIGRATE="Run database migration? (first time only) [y/N]: "
if /i "%MIGRATE%"=="y" (
    echo [Running migration...]
    cd backend
    node scripts/migrate.js
    node scripts/seed.js
    cd ..
)

REM Start backend in new window
echo.
echo [Starting backend on port 5000...]
start "AcadVault Backend" cmd /k "cd backend && npm run dev"

REM Wait for backend to be ready
timeout /t 3 /nobreak >nul

REM Start frontend in new window
echo [Starting frontend on port 3000...]
start "AcadVault Frontend" cmd /k "cd frontend && npm start"

echo.
echo ============================================================
echo  AcadVault is starting up!
echo  Open your browser to: http://localhost:3000
echo.
echo  Admin:   admin@acadvault.com  /  Admin@123
echo  Student: student@demo.com     /  Student@123
echo ============================================================
echo.
timeout /t 5 /nobreak >nul
start http://localhost:3000
