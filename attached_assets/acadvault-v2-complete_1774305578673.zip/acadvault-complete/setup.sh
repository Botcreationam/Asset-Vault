#!/bin/bash
# ============================================================
#  AcadVault — Automated Setup Script
#  Run: bash setup.sh
# ============================================================

set -e
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║        AcadVault Setup Script        ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${NC}"

# Check Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org"
  exit 1
fi
echo -e "${GREEN}✅ Node.js $(node -v) found${NC}"

# Check PostgreSQL
if ! command -v psql &> /dev/null; then
  echo -e "${YELLOW}⚠️  PostgreSQL not found. Install from https://postgresql.org${NC}"
  echo "   Or use Neon (free cloud): https://neon.tech"
fi

# Copy .env if not exists
if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo -e "${YELLOW}📋 Created backend/.env — please edit it with your database details${NC}"
fi

# Install backend dependencies
echo ""
echo -e "${BLUE}📦 Installing backend dependencies...${NC}"
cd backend
npm install
cd ..

# Install frontend dependencies
echo ""
echo -e "${BLUE}📦 Installing frontend dependencies...${NC}"
cd frontend
npm install
cd ..

echo ""
echo -e "${GREEN}✅ Dependencies installed!${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "  1. Edit backend/.env with your PostgreSQL details"
echo "  2. Run: cd backend && node scripts/migrate.js"
echo "  3. Run: cd backend && node scripts/seed.js"
echo "  4. Start backend:  cd backend && npm run dev"
echo "  5. Start frontend: cd frontend && npm start"
echo ""
echo -e "${GREEN}🚀 Then open: http://localhost:3000${NC}"
echo ""
echo "  Admin:   admin@acadvault.com / Admin@123"
echo "  Student: student@demo.com    / Student@123"
