// backend/utils/jwt.js
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

const ACCESS_SECRET  = process.env.JWT_ACCESS_SECRET  || 'dev_access_secret_change_in_prod';
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev_refresh_secret_change_in_prod';
const ACCESS_EXP     = process.env.JWT_ACCESS_EXPIRES  || '15m';
const REFRESH_EXP    = process.env.JWT_REFRESH_EXPIRES || '7d';

/**
 * Sign an access token (short-lived)
 */
function signAccessToken(payload) {
  return jwt.sign(
    { ...payload, type: 'access' },
    ACCESS_SECRET,
    { expiresIn: ACCESS_EXP, issuer: 'acadvault' }
  );
}

/**
 * Sign a refresh token (long-lived, stored in DB)
 */
function signRefreshToken(userId) {
  const jti = uuidv4();
  const token = jwt.sign(
    { sub: userId, jti, type: 'refresh' },
    REFRESH_SECRET,
    { expiresIn: REFRESH_EXP, issuer: 'acadvault' }
  );
  return { token, jti };
}

/**
 * Verify an access token — returns decoded payload or throws
 */
function verifyAccessToken(token) {
  return jwt.verify(token, ACCESS_SECRET, { issuer: 'acadvault' });
}

/**
 * Verify a refresh token
 */
function verifyRefreshToken(token) {
  return jwt.verify(token, REFRESH_SECRET, { issuer: 'acadvault' });
}

/**
 * Generate a cryptographically random opaque token (for download links etc.)
 */
function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Calculate refresh token expiry Date
 */
function refreshTokenExpiry() {
  const days = parseInt(REFRESH_EXP) || 7;
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d;
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  randomToken,
  refreshTokenExpiry,
};
