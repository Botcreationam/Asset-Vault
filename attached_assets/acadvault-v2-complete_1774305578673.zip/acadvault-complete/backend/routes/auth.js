// backend/routes/auth.js
const express  = require('express');
const bcrypt   = require('bcryptjs');
const crypto   = require('crypto');
const { body, validationResult } = require('express-validator');
const router   = express.Router();

const { query }  = require('../config/db');
const { signAccessToken, signRefreshToken, verifyRefreshToken, refreshTokenExpiry } = require('../utils/jwt');
const { requireAuth } = require('../middleware/auth');
const logger = require('../config/logger');
const emailSvc = require('../services/emailService');

function sendTokens(user) {
  const accessToken  = signAccessToken({ sub: user.id, email: user.email, role: user.role, name: user.full_name });
  const { token: refreshToken } = signRefreshToken(user.id);
  return { accessToken, refreshToken };
}

async function storeRefresh(userId, token, req) {
  await query(
    `INSERT INTO sessions (user_id, refresh_token, user_agent, ip_address, expires_at)
     VALUES ($1,$2,$3,$4,$5)`,
    [userId, token, req.headers['user-agent'] || '', req.ip, refreshTokenExpiry()]
  );
}

function safe(u) { const { password_hash, two_fa_secret, reset_token, verify_token, ...rest } = u; return rest; }

// ── Register ─────────────────────────────────────────────
router.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).matches(/^(?=.*[A-Za-z])(?=.*\d)/),
  body('full_name').trim().isLength({ min: 2, max: 100 }),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });

  const { email, password, full_name } = req.body;
  try {
    if ((await query('SELECT id FROM users WHERE email=$1', [email])).rows.length)
      return res.status(409).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    const verifyToken  = crypto.randomBytes(32).toString('hex');
    const verifyExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const { rows } = await query(
      `INSERT INTO users (email, password_hash, full_name, role, wallet_balance, verify_token, verify_token_expires)
       VALUES ($1,$2,$3,'student',0,$4,$5) RETURNING *`,
      [email, hash, full_name, verifyToken, verifyExpiry]
    );
    const user = rows[0];
    const tokens = sendTokens(user);
    await storeRefresh(user.id, tokens.refreshToken, req);
    await query(`INSERT INTO activity_log (user_id,action,ip_address) VALUES ($1,'user_registered',$2)`, [user.id, req.ip]);

    // Emails (non-blocking)
    emailSvc.sendWelcome(email, full_name).catch(() => {});
    emailSvc.sendEmailVerification(email, full_name, verifyToken).catch(() => {});

    res.status(201).json({ user: safe(user), ...tokens });
  } catch (err) {
    logger.error('Register error', { error: err.message });
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ── Login ─────────────────────────────────────────────────
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });

  const { email, password } = req.body;
  try {
    const { rows } = await query('SELECT * FROM users WHERE email=$1', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const user = rows[0];

    if (!user.is_active)      return res.status(403).json({ error: 'Account deactivated' });
    if (!user.password_hash)  return res.status(401).json({ error: 'Please sign in with OAuth' });
    if (!await bcrypt.compare(password, user.password_hash))
      return res.status(401).json({ error: 'Invalid credentials' });

    if (user.two_fa_enabled) return res.json({ requires2FA: true, userId: user.id });

    const tokens = sendTokens(user);
    await storeRefresh(user.id, tokens.refreshToken, req);
    await query(`INSERT INTO activity_log (user_id,action,ip_address) VALUES ($1,'user_login',$2)`, [user.id, req.ip]);
    emailSvc.sendLoginAlert(email, user.full_name, req.ip).catch(() => {});

    res.json({ user: safe(user), ...tokens });
  } catch (err) {
    logger.error('Login error', { error: err.message });
    res.status(500).json({ error: 'Login failed' });
  }
});

// ── Refresh ───────────────────────────────────────────────
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(401).json({ error: 'Refresh token required' });
  try {
    verifyRefreshToken(refreshToken);
    const { rows } = await query(
      `SELECT s.*, u.email, u.full_name, u.role, u.is_active FROM sessions s
       JOIN users u ON s.user_id = u.id
       WHERE s.refresh_token=$1 AND s.expires_at > NOW()`,
      [refreshToken]
    );
    if (!rows.length || !rows[0].is_active)
      return res.status(401).json({ error: 'Invalid or expired refresh token' });

    await query('DELETE FROM sessions WHERE refresh_token=$1', [refreshToken]);
    const { token: newRefresh } = signRefreshToken(rows[0].user_id);
    await storeRefresh(rows[0].user_id, newRefresh, req);
    const newAccess = signAccessToken({ sub: rows[0].user_id, email: rows[0].email, role: rows[0].role, name: rows[0].full_name });
    res.json({ accessToken: newAccess, refreshToken: newRefresh });
  } catch {
    res.status(401).json({ error: 'Token refresh failed' });
  }
});

// ── Logout ────────────────────────────────────────────────
router.post('/logout', requireAuth, async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) await query('DELETE FROM sessions WHERE refresh_token=$1', [refreshToken]);
  res.json({ message: 'Logged out' });
});

// ── OAuth ─────────────────────────────────────────────────
router.post('/oauth', [
  body('provider').isIn(['google','facebook','apple']),
  body('oauthId').notEmpty(),
  body('email').isEmail().normalizeEmail(),
  body('full_name').trim().notEmpty(),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });
  const { provider, oauthId, email, full_name, avatar_url } = req.body;
  try {
    let { rows } = await query('SELECT * FROM users WHERE oauth_provider=$1 AND oauth_id=$2', [provider, oauthId]);
    if (!rows.length) {
      const byEmail = await query('SELECT * FROM users WHERE email=$1', [email]);
      if (byEmail.rows.length) {
        await query('UPDATE users SET oauth_provider=$1, oauth_id=$2, avatar_url=$3, is_verified=TRUE WHERE id=$4',
          [provider, oauthId, avatar_url, byEmail.rows[0].id]);
        rows = [{ ...byEmail.rows[0] }];
      } else {
        const ins = await query(
          `INSERT INTO users (email, full_name, role, oauth_provider, oauth_id, avatar_url, is_verified)
           VALUES ($1,$2,'student',$3,$4,$5,TRUE) RETURNING *`,
          [email, full_name, provider, oauthId, avatar_url]
        );
        rows = ins.rows;
        emailSvc.sendWelcome(email, full_name).catch(() => {});
      }
    }
    const user = rows[0];
    if (!user.is_active) return res.status(403).json({ error: 'Account deactivated' });
    const tokens = sendTokens(user);
    await storeRefresh(user.id, tokens.refreshToken, req);
    res.json({ user: safe(user), ...tokens });
  } catch (err) {
    logger.error('OAuth error', { error: err.message });
    res.status(500).json({ error: 'OAuth login failed' });
  }
});

// ── Me ────────────────────────────────────────────────────
router.get('/me', requireAuth, async (req, res) => {
  const { rows } = await query(
    `SELECT id, email, full_name, role, wallet_balance, avatar_url,
            is_verified, two_fa_enabled, created_at FROM users WHERE id=$1`,
    [req.user.id]
  );
  res.json({ user: rows[0] });
});

// ── FIX #1: Update profile ───────────────────────────────
router.patch('/profile', requireAuth, [
  body('full_name').optional().trim().isLength({ min: 2, max: 100 }),
  body('avatar_url').optional({ nullable: true }),
], async (req, res) => {
  const { full_name, avatar_url } = req.body;
  const updates = []; const values = []; let i = 1;
  if (full_name  !== undefined) { updates.push(`full_name=$${i++}`);  values.push(full_name); }
  if (avatar_url !== undefined) { updates.push(`avatar_url=$${i++}`); values.push(avatar_url); }
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(req.user.id);
  try {
    const { rows } = await query(
      `UPDATE users SET ${updates.join(',')} WHERE id=$${i}
       RETURNING id, email, full_name, role, wallet_balance, avatar_url, is_verified, created_at`,
      values
    );
    res.json({ user: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Profile update failed' });
  }
});

// ── FIX #2: Forgot password ──────────────────────────────
router.post('/forgot-password', [body('email').isEmail().normalizeEmail()], async (req, res) => {
  // Always 200 to prevent user enumeration
  res.json({ message: 'If that email is registered, a reset link has been sent.' });
  try {
    const { rows } = await query('SELECT * FROM users WHERE email=$1 AND is_active=TRUE', [req.body.email]);
    if (!rows.length) return;
    const token  = crypto.randomBytes(32).toString('hex');
    const expiry = new Date(Date.now() + 60 * 60 * 1000);
    await query('UPDATE users SET reset_token=$1, reset_token_expires=$2 WHERE id=$3', [token, expiry, rows[0].id]);
    emailSvc.sendPasswordReset(req.body.email, rows[0].full_name, token).catch(() => {});
  } catch (err) {
    logger.error('Forgot password error', { error: err.message });
  }
});

// ── FIX #2: Reset password ───────────────────────────────
router.post('/reset-password', [
  body('token').notEmpty(),
  body('newPassword').isLength({ min: 8 }).matches(/^(?=.*[A-Za-z])(?=.*\d)/),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });
  const { token, newPassword } = req.body;
  try {
    const { rows } = await query(
      'SELECT * FROM users WHERE reset_token=$1 AND reset_token_expires > NOW()', [token]
    );
    if (!rows.length) return res.status(400).json({ error: 'Invalid or expired reset link' });
    const hash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    await query('UPDATE users SET password_hash=$1, reset_token=NULL, reset_token_expires=NULL WHERE id=$2',
      [hash, rows[0].id]);
    await query('DELETE FROM sessions WHERE user_id=$1', [rows[0].id]);
    res.json({ message: 'Password reset. Please log in.' });
  } catch (err) {
    res.status(500).json({ error: 'Reset failed' });
  }
});

// ── FIX #3: Verify email ─────────────────────────────────
router.get('/verify-email', async (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ error: 'Token required' });
  try {
    const { rows } = await query(
      'SELECT id FROM users WHERE verify_token=$1 AND verify_token_expires > NOW()', [token]
    );
    if (!rows.length) return res.status(400).json({ error: 'Invalid or expired link' });
    await query('UPDATE users SET is_verified=TRUE, verify_token=NULL, verify_token_expires=NULL WHERE id=$1',
      [rows[0].id]);
    res.json({ message: 'Email verified!' });
  } catch {
    res.status(500).json({ error: 'Verification failed' });
  }
});

// ── Resend verification ──────────────────────────────────
router.post('/resend-verification', requireAuth, async (req, res) => {
  try {
    const { rows } = await query('SELECT * FROM users WHERE id=$1', [req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'User not found' });
    if (rows[0].is_verified) return res.status(400).json({ error: 'Already verified' });
    const token  = crypto.randomBytes(32).toString('hex');
    const expiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await query('UPDATE users SET verify_token=$1, verify_token_expires=$2 WHERE id=$3', [token, expiry, rows[0].id]);
    await emailSvc.sendEmailVerification(rows[0].email, rows[0].full_name, token);
    res.json({ message: 'Verification email sent' });
  } catch {
    res.status(500).json({ error: 'Could not resend' });
  }
});

// ── Change password ──────────────────────────────────────
router.patch('/change-password', requireAuth, [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 8 }),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });
  const { currentPassword, newPassword } = req.body;
  try {
    const { rows } = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
    if (!await bcrypt.compare(currentPassword, rows[0].password_hash || ''))
      return res.status(401).json({ error: 'Current password incorrect' });
    const hash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    await query('UPDATE users SET password_hash=$1 WHERE id=$2', [hash, req.user.id]);
    await query('DELETE FROM sessions WHERE user_id=$1', [req.user.id]);
    res.json({ message: 'Password changed. Please log in again.' });
  } catch {
    res.status(500).json({ error: 'Password change failed' });
  }
});

module.exports = router;
