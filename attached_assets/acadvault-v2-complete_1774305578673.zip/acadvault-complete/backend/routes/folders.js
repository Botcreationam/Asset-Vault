// backend/routes/folders.js
const express = require('express');
const { body, param, validationResult } = require('express-validator');
const router  = express.Router();
const { query } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const logger = require('../config/logger');

// ── GET /api/folders  (root folders or children of a parent) ──
router.get('/', async (req, res) => {
  const { parent_id } = req.query;
  try {
    const { rows } = await query(
      `SELECT f.*,
              (SELECT COUNT(*) FROM folders c WHERE c.parent_id = f.id) AS subfolder_count,
              (SELECT COUNT(*) FROM files  fi WHERE fi.folder_id = f.id AND fi.is_published = TRUE) AS file_count
       FROM folders f
       WHERE ($1::uuid IS NULL AND f.parent_id IS NULL)
          OR ($1::uuid IS NOT NULL AND f.parent_id = $1::uuid)
       ORDER BY f.position ASC, f.name ASC`,
      [parent_id || null]
    );
    res.json({ folders: rows });
  } catch (err) {
    logger.error('Get folders error', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch folders' });
  }
});

// ── GET /api/folders/tree  (full nested tree) ────────────
router.get('/tree', async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT f.id, f.name, f.parent_id, f.position,
              (SELECT COUNT(*) FROM files fi WHERE fi.folder_id = f.id AND fi.is_published = TRUE) AS file_count
       FROM folders f ORDER BY f.position ASC, f.name ASC`
    );

    const map = {};
    rows.forEach(r => { map[r.id] = { ...r, children: [] }; });

    const roots = [];
    rows.forEach(r => {
      if (r.parent_id && map[r.parent_id]) {
        map[r.parent_id].children.push(map[r.id]);
      } else if (!r.parent_id) {
        roots.push(map[r.id]);
      }
    });

    res.json({ tree: roots });
  } catch (err) {
    logger.error('Get tree error', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch folder tree' });
  }
});

// ── GET /api/folders/:id  (single folder + contents) ─────
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const { rows: folders } = await query(
      `SELECT f.*,
              (SELECT COUNT(*) FROM folders c WHERE c.parent_id = f.id) AS subfolder_count,
              (SELECT COUNT(*) FROM files fi WHERE fi.folder_id = f.id AND fi.is_published = TRUE) AS file_count
       FROM folders f WHERE f.id = $1`,
      [id]
    );
    if (!folders.length) return res.status(404).json({ error: 'Folder not found' });

    // Breadcrumb path
    const breadcrumbs = [];
    let current = folders[0];
    breadcrumbs.unshift(current);
    while (current.parent_id) {
      const { rows } = await query('SELECT * FROM folders WHERE id=$1', [current.parent_id]);
      if (!rows.length) break;
      current = rows[0];
      breadcrumbs.unshift(current);
    }

    // Subfolders
    const { rows: subfolders } = await query(
      `SELECT f.*,
              (SELECT COUNT(*) FROM folders c WHERE c.parent_id = f.id) AS subfolder_count,
              (SELECT COUNT(*) FROM files fi WHERE fi.folder_id = f.id AND fi.is_published = TRUE) AS file_count
       FROM folders f WHERE f.parent_id = $1 ORDER BY f.position, f.name`,
      [id]
    );

    // Files in this folder
    const { rows: files } = await query(
      `SELECT id, name, description, file_type, size_bytes, page_count,
              thumbnail_key, is_published, download_price, download_count, view_count, created_at
       FROM files WHERE folder_id = $1 AND is_published = TRUE
       ORDER BY name ASC`,
      [id]
    );

    res.json({ folder: folders[0], subfolders, files, breadcrumbs });
  } catch (err) {
    logger.error('Get folder error', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch folder' });
  }
});

// ── POST /api/folders  (admin only) ──────────────────────
router.post('/', requireAuth, requireAdmin, [
  body('name').trim().isLength({ min: 1, max: 200 }),
  body('parent_id').optional({ nullable: true }).isUUID(),
  body('position').optional().isInt({ min: 0 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  const { name, parent_id, position = 0 } = req.body;
  try {
    if (parent_id) {
      const exists = await query('SELECT id FROM folders WHERE id=$1', [parent_id]);
      if (!exists.rows.length) return res.status(404).json({ error: 'Parent folder not found' });
    }
    const { rows } = await query(
      `INSERT INTO folders (name, parent_id, created_by, position)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [name, parent_id || null, req.user.id, position]
    );
    logger.info('Folder created', { folderId: rows[0].id, name, adminId: req.user.id });
    res.status(201).json({ folder: rows[0] });
  } catch (err) {
    logger.error('Create folder error', { error: err.message });
    res.status(500).json({ error: 'Failed to create folder' });
  }
});

// ── PATCH /api/folders/:id  (admin only) ─────────────────
router.patch('/:id', requireAuth, requireAdmin, [
  param('id').isUUID(),
  body('name').optional().trim().isLength({ min: 1, max: 200 }),
  body('position').optional().isInt({ min: 0 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  const { id } = req.params;
  const updates = [];
  const values  = [];
  let i = 1;

  if (req.body.name !== undefined)     { updates.push(`name=$${i++}`);     values.push(req.body.name); }
  if (req.body.position !== undefined) { updates.push(`position=$${i++}`); values.push(req.body.position); }

  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  values.push(id);

  try {
    const { rows } = await query(
      `UPDATE folders SET ${updates.join(',')} WHERE id=$${i} RETURNING *`,
      values
    );
    if (!rows.length) return res.status(404).json({ error: 'Folder not found' });
    res.json({ folder: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

// ── DELETE /api/folders/:id  (admin only) ────────────────
router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await query('DELETE FROM folders WHERE id=$1 RETURNING id', [id]);
    if (!rows.length) return res.status(404).json({ error: 'Folder not found' });
    logger.info('Folder deleted', { folderId: id, adminId: req.user.id });
    res.json({ message: 'Folder deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
});

module.exports = router;
