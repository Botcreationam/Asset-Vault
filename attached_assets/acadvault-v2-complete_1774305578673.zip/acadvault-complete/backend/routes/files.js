// backend/routes/files.js
const express = require('express');
const fs      = require('fs');
const path    = require('path');
const { body, query: qv, param, validationResult } = require('express-validator');
const router  = express.Router();

const db       = require('../config/db');
const { requireAuth, requireAdmin, optionalAuth } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const storage  = require('../services/storageService');
const { randomToken } = require('../utils/jwt');
const logger   = require('../config/logger');

const DOWNLOAD_EXPIRES = parseInt(process.env.DOWNLOAD_TOKEN_EXPIRES_MINUTES) || 30;

// ── GET /api/files/search ─────────────────────────────────
router.get('/search', optionalAuth, async (req, res) => {
  const { q, type, folder_id, limit = 20, offset = 0 } = req.query;
  if (!q || q.trim().length < 2) return res.json({ files: [], total: 0 });

  try {
    const { rows } = await db.query(
      `SELECT f.id, f.name, f.description, f.file_type, f.size_bytes, f.page_count,
              f.download_price, f.download_count, f.view_count, f.created_at,
              fo.name AS folder_name, fo.id AS folder_id,
              ts_rank(to_tsvector('english', f.name || ' ' || COALESCE(f.description,'')),
                      plainto_tsquery('english', $1)) AS rank
       FROM files f
       JOIN folders fo ON fo.id = f.folder_id
       WHERE f.is_published = TRUE
         AND to_tsvector('english', f.name || ' ' || COALESCE(f.description,''))
             @@ plainto_tsquery('english', $1)
         AND ($2::text IS NULL OR f.file_type = $2)
         AND ($3::uuid IS NULL OR f.folder_id = $3::uuid)
       ORDER BY rank DESC
       LIMIT $4 OFFSET $5`,
      [q.trim(), type || null, folder_id || null, limit, offset]
    );
    res.json({ files: rows, total: rows.length });
  } catch (err) {
    logger.error('Search error', { error: err.message });
    res.status(500).json({ error: 'Search failed' });
  }
});

// ── GET /api/files/recent  (user's recently viewed) ───────
router.get('/recent', requireAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT f.id, f.name, f.description, f.file_type, f.size_bytes, f.page_count,
              f.download_price, fo.name AS folder_name, vh.viewed_at
       FROM view_history vh
       JOIN files f   ON f.id = vh.file_id
       JOIN folders fo ON fo.id = f.folder_id
       WHERE vh.user_id = $1 AND f.is_published = TRUE
       ORDER BY vh.viewed_at DESC LIMIT 20`,
      [req.user.id]
    );
    res.json({ files: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch recent files' });
  }
});

// ── GET /api/files/purchased  (user's purchased files) ────
router.get('/purchased', requireAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT f.id, f.name, f.description, f.file_type, f.size_bytes, f.page_count,
              f.download_price, fo.name AS folder_name, p.created_at AS purchased_at
       FROM purchases p
       JOIN files f    ON f.id = p.file_id
       JOIN folders fo ON fo.id = f.folder_id
       WHERE p.user_id = $1 AND p.status = 'completed' AND f.is_published = TRUE
       ORDER BY p.created_at DESC`,
      [req.user.id]
    );
    res.json({ files: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch purchased files' });
  }
});

// ── GET /api/files/:id  (metadata) ────────────────────────
router.get('/:id', optionalAuth, async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await db.query(
      `SELECT f.id, f.name, f.description, f.file_type, f.size_bytes, f.page_count,
              f.download_price, f.download_count, f.view_count, f.created_at, f.is_published,
              fo.name AS folder_name, fo.id AS folder_id
       FROM files f JOIN folders fo ON fo.id = f.folder_id
       WHERE f.id = $1`,
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: 'File not found' });
    const file = rows[0];
    if (!file.is_published && (!req.user || !['admin','superadmin'].includes(req.user.role))) {
      return res.status(403).json({ error: 'File not published' });
    }

    // Check ownership
    let owned = false;
    if (req.user) {
      const { rows: p } = await db.query(
        `SELECT id FROM purchases WHERE user_id=$1 AND file_id=$2 AND status='completed'`,
        [req.user.id, id]
      );
      owned = p.length > 0;
    }

    res.json({ file: { ...file, owned } });
  } catch (err) {
    logger.error('Get file error', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch file' });
  }
});

// ── POST /api/files/:id/view  (record view, increment counter) ──
router.post('/:id/view', requireAuth, async (req, res) => {
  const { id } = req.params;
  try {
    await db.query(
      `INSERT INTO view_history (user_id, file_id, viewed_at) VALUES ($1,$2,NOW())
       ON CONFLICT (user_id, file_id) DO UPDATE SET viewed_at = NOW()`,
      [req.user.id, id]
    );
    await db.query('UPDATE files SET view_count = view_count + 1 WHERE id=$1', [id]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to record view' });
  }
});

// ── GET /api/files/:id/stream  (read-only stream — no auth needed for viewing) ──
router.get('/:id/stream', requireAuth, async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await db.query(
      `SELECT storage_key, name, mime_type, is_published FROM files WHERE id=$1`,
      [id]
    );
    if (!rows.length || !rows[0].is_published) {
      return res.status(404).json({ error: 'File not found' });
    }
    const file = rows[0];

    if (process.env.STORAGE_PROVIDER === 's3') {
      const url = await storage.getDownloadUrl(file.storage_key, 60, file.name);
      return res.redirect(url);
    }

    const filePath = path.join(__dirname, '..', 'uploads', file.storage_key);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File data not found' });
    res.setHeader('Content-Type', file.mime_type);
    res.setHeader('Content-Disposition', 'inline');
    // Prevent browser caching of protected content
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    logger.error('Stream error', { error: err.message });
    res.status(500).json({ error: 'Streaming failed' });
  }
});

// ── POST /api/files/:id/download-token  (exchange purchase for download link) ──
router.post('/:id/download-token', requireAuth, async (req, res) => {
  const { id } = req.params;
  try {
    // Verify purchase
    const { rows: purchases } = await db.query(
      `SELECT id FROM purchases WHERE user_id=$1 AND file_id=$2 AND status='completed'`,
      [req.user.id, id]
    );
    if (!purchases.length) {
      return res.status(403).json({ error: 'Purchase required to download' });
    }

    const token  = randomToken(32);
    const expiry = new Date(Date.now() + DOWNLOAD_EXPIRES * 60 * 1000);

    await db.query(
      `INSERT INTO download_tokens (token, user_id, file_id, expires_at)
       VALUES ($1,$2,$3,$4)`,
      [token, req.user.id, id, expiry]
    );

    res.json({ downloadToken: token, expiresAt: expiry });
  } catch (err) {
    logger.error('Download token error', { error: err.message });
    res.status(500).json({ error: 'Failed to generate download token' });
  }
});

// ── GET /api/files/download/:token  (actual file delivery) ─
router.get('/download/:token', async (req, res) => {
  const { token } = req.params;
  try {
    const { rows } = await db.query(
      `SELECT dt.*, f.storage_key, f.name, f.mime_type, u.email
       FROM download_tokens dt
       JOIN files f ON f.id = dt.file_id
       JOIN users u ON u.id = dt.user_id
       WHERE dt.token = $1 AND dt.expires_at > NOW() AND dt.used_at IS NULL`,
      [token]
    );
    if (!rows.length) {
      return res.status(403).json({ error: 'Invalid, expired, or already-used download link' });
    }
    const dl = rows[0];

    // Mark as used
    await db.query('UPDATE download_tokens SET used_at=NOW() WHERE token=$1', [token]);
    await db.query('UPDATE files SET download_count=download_count+1 WHERE id=$1', [dl.file_id]);

    if (process.env.STORAGE_PROVIDER === 's3') {
      const signedUrl = await storage.getDownloadUrl(dl.storage_key, 5, dl.name);
      return res.redirect(signedUrl);
    }

    const filePath = path.join(__dirname, '..', 'uploads', dl.storage_key);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File data missing' });

    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(dl.name)}"`);
    res.setHeader('Content-Type', dl.mime_type);
    res.setHeader('Cache-Control', 'no-store');
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    logger.error('Download error', { error: err.message });
    res.status(500).json({ error: 'Download failed' });
  }
});

// ── POST /api/files  (admin: upload file) ────────────────
router.post('/', requireAuth, requireAdmin, upload.single('file'), [
  body('folder_id').isUUID(),
  body('name').trim().isLength({ min: 1, max: 300 }),
  body('description').optional().trim().isLength({ max: 1000 }),
  body('download_price').optional().isFloat({ min: 0 }),
  body('is_published').optional().isBoolean(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(422).json({ errors: errors.array() });
  }
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const { folder_id, name, description, download_price = 5.00, is_published = false } = req.body;

  try {
    // Verify folder exists
    const { rows: fRows } = await db.query('SELECT id FROM folders WHERE id=$1', [folder_id]);
    if (!fRows.length) return res.status(404).json({ error: 'Folder not found' });

    const buffer = fs.readFileSync(req.file.path);
    const storageKey = await storage.saveFile(buffer, req.file.originalname, req.file.mimetype, 'resources');
    fs.unlinkSync(req.file.path); // Remove tmp file

    const fileType = detectFileType(req.file.mimetype);

    const { rows } = await db.query(
      `INSERT INTO files (folder_id, name, description, file_type, storage_key, original_name,
                          mime_type, size_bytes, download_price, is_published, uploaded_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [
        folder_id, name, description || null, fileType, storageKey,
        req.file.originalname, req.file.mimetype, req.file.size,
        download_price, is_published === 'true' || is_published === true,
        req.user.id,
      ]
    );

    logger.info('File uploaded', { fileId: rows[0].id, name, adminId: req.user.id });
    res.status(201).json({ file: rows[0] });
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    logger.error('Upload error', { error: err.message });
    res.status(500).json({ error: 'Upload failed' });
  }
});

// ── PATCH /api/files/:id  (admin: update metadata) ───────
router.patch('/:id', requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;
  const fields  = ['name', 'description', 'download_price', 'is_published', 'folder_id'];
  const updates = [];
  const values  = [];
  let i = 1;

  fields.forEach(f => {
    if (req.body[f] !== undefined) {
      updates.push(`${f}=$${i++}`);
      values.push(req.body[f]);
    }
  });
  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  values.push(id);

  try {
    const { rows } = await db.query(
      `UPDATE files SET ${updates.join(',')} WHERE id=$${i} RETURNING *`,
      values
    );
    if (!rows.length) return res.status(404).json({ error: 'File not found' });
    res.json({ file: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

// ── DELETE /api/files/:id  (admin) ────────────────────────
router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await db.query('SELECT storage_key FROM files WHERE id=$1', [id]);
    if (!rows.length) return res.status(404).json({ error: 'File not found' });
    await storage.deleteFile(rows[0].storage_key);
    await db.query('DELETE FROM files WHERE id=$1', [id]);
    logger.info('File deleted', { fileId: id, adminId: req.user.id });
    res.json({ message: 'File deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
});

function detectFileType(mime) {
  if (mime === 'application/pdf') return 'pdf';
  if (mime.includes('presentation') || mime.includes('powerpoint')) return 'slides';
  if (mime.startsWith('image/')) return 'image';
  if (mime.includes('word') || mime.includes('document')) return 'doc';
  return 'other';
}

module.exports = router;
