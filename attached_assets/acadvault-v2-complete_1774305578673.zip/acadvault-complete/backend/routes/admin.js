// backend/routes/admin.js
const express = require('express');
const router  = express.Router();
const { query } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// All routes require auth + admin
router.use(requireAuth, requireAdmin);

// ── GET /api/admin/stats ───────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [usersR, filesR, purchasesR, revenueR, downloadsR, viewsR] = await Promise.all([
      query('SELECT COUNT(*) FROM users WHERE role=\'student\''),
      query('SELECT COUNT(*) FROM files WHERE is_published=TRUE'),
      query('SELECT COUNT(*) FROM purchases WHERE status=\'completed\''),
      query('SELECT COALESCE(SUM(amount_paid),0) AS total FROM purchases WHERE status=\'completed\''),
      query('SELECT COALESCE(SUM(download_count),0) AS total FROM files'),
      query('SELECT COALESCE(SUM(view_count),0) AS total FROM files'),
    ]);

    // Recent activity (last 7 days purchases per day)
    const { rows: dailyRevenue } = await query(
      `SELECT DATE(created_at) AS day, COUNT(*) AS purchases, SUM(amount_paid) AS revenue
       FROM purchases WHERE status='completed' AND created_at > NOW() - INTERVAL '7 days'
       GROUP BY DATE(created_at) ORDER BY day ASC`
    );

    // Top files
    const { rows: topFiles } = await query(
      `SELECT f.name, f.download_count, f.view_count, fo.name AS folder
       FROM files f JOIN folders fo ON fo.id=f.folder_id
       WHERE f.is_published=TRUE ORDER BY f.download_count DESC LIMIT 10`
    );

    res.json({
      stats: {
        totalStudents: parseInt(usersR.rows[0].count),
        totalFiles: parseInt(filesR.rows[0].count),
        totalPurchases: parseInt(purchasesR.rows[0].count),
        totalRevenue: parseFloat(revenueR.rows[0].total),
        totalDownloads: parseInt(downloadsR.rows[0].total),
        totalViews: parseInt(viewsR.rows[0].total),
      },
      dailyRevenue,
      topFiles,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// ── GET /api/admin/users ───────────────────────────────────
router.get('/users', async (req, res) => {
  const { limit = 50, offset = 0, search } = req.query;
  try {
    const { rows } = await query(
      `SELECT id, email, full_name, role, wallet_balance, is_active, is_verified,
              created_at, oauth_provider,
              (SELECT COUNT(*) FROM purchases WHERE user_id=users.id AND status='completed') AS purchase_count
       FROM users
       WHERE ($1::text IS NULL OR email ILIKE '%'||$1||'%' OR full_name ILIKE '%'||$1||'%')
       ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [search || null, limit, offset]
    );
    res.json({ users: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// ── PATCH /api/admin/users/:id ─────────────────────────────
router.patch('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { is_active, role, wallet_balance } = req.body;
  const updates = []; const values = []; let i = 1;
  if (is_active !== undefined) { updates.push(`is_active=$${i++}`); values.push(is_active); }
  if (role)           { updates.push(`role=$${i++}`);           values.push(role); }
  if (wallet_balance !== undefined) { updates.push(`wallet_balance=$${i++}`); values.push(wallet_balance); }
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(id);
  try {
    const { rows } = await query(
      `UPDATE users SET ${updates.join(',')} WHERE id=$${i} RETURNING id,email,role,is_active,wallet_balance`,
      values
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found' });
    res.json({ user: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

// ── GET /api/admin/activity ────────────────────────────────
router.get('/activity', async (req, res) => {
  const { limit = 100, offset = 0 } = req.query;
  try {
    const { rows } = await query(
      `SELECT al.*, u.email, u.full_name
       FROM activity_log al LEFT JOIN users u ON u.id=al.user_id
       ORDER BY al.created_at DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    res.json({ logs: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch activity' });
  }
});

// ── PATCH /api/admin/files/:id/publish ────────────────────
router.patch('/files/:id/publish', async (req, res) => {
  const { id } = req.params;
  const { is_published } = req.body;
  try {
    const { rows } = await query(
      'UPDATE files SET is_published=$1 WHERE id=$2 RETURNING id,name,is_published',
      [is_published, id]
    );
    if (!rows.length) return res.status(404).json({ error: 'File not found' });
    res.json({ file: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

module.exports = router;
