// backend/routes/payments.js
const express = require('express');
const { body, validationResult } = require('express-validator');
const router  = express.Router();
const { query, transaction } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { randomToken } = require('../utils/jwt');
const logger   = require('../config/logger');
const emailSvc = require('../services/emailService');

// ── GET /api/payments/wallet ─────────────────────────────
router.get('/wallet', requireAuth, async (req, res) => {
  try {
    const [txRows, balRows] = await Promise.all([
      query(`SELECT id, type, amount, balance_after, description, reference, created_at
             FROM wallet_transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`, [req.user.id]),
      query('SELECT wallet_balance FROM users WHERE id=$1', [req.user.id]),
    ]);
    res.json({
      balance: parseFloat(balRows.rows[0]?.wallet_balance || 0),
      transactions: txRows.rows,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wallet' });
  }
});

// ── POST /api/payments/topup ─────────────────────────────
router.post('/topup', requireAuth, [
  body('amount').isFloat({ min: 1, max: 10000 }),
  body('method').isIn(['mtn', 'airtel', 'mastercard', 'stripe']),
  body('phone').optional().isMobilePhone(),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });

  const { amount, method, phone } = req.body;
  const reference = `TOPUP-${randomToken(8).toUpperCase()}`;

  try {
    // FIX #15: In development mode, auto-credit wallet immediately
    if (process.env.NODE_ENV !== 'production' || method === 'wallet') {
      await transaction(async (client) => {
        const { rows: uRows } = await client.query('SELECT wallet_balance FROM users WHERE id=$1', [req.user.id]);
        const newBalance = parseFloat(uRows[0].wallet_balance) + parseFloat(amount);
        await client.query('UPDATE users SET wallet_balance=$1 WHERE id=$2', [newBalance, req.user.id]);
        await client.query(
          `INSERT INTO wallet_transactions (user_id, type, amount, balance_after, description, reference)
           VALUES ($1,'credit',$2,$3,$4,$5)`,
          [req.user.id, amount, newBalance, `Top-up via ${method} (dev auto-credit)`, reference]
        );
      });
      return res.json({
        reference, status: 'completed',
        message: `✅ ${amount} units added to your wallet!`,
        autoCredit: true,
      });
    }

    // Production: initiate gateway and wait for webhook
    const gateway = await initiatePayment({ method, amount, phone, reference, userId: req.user.id });
    await query(
      `INSERT INTO wallet_transactions (user_id, type, amount, balance_after, description, reference)
       VALUES ($1,'credit',$2,(SELECT wallet_balance FROM users WHERE id=$1)+$2,$3,$4)`,
      [req.user.id, amount, `Top-up via ${method} — pending`, reference]
    );
    res.json({ reference, status: 'pending', message: gateway.message, redirectUrl: gateway.redirectUrl || null });
  } catch (err) {
    logger.error('Topup error', { error: err.message });
    res.status(500).json({ error: 'Payment initiation failed' });
  }
});

// ── POST /api/payments/topup/confirm (webhook) ───────────
router.post('/topup/confirm', async (req, res) => {
  const { reference, status, gateway_ref } = req.body;
  try {
    if (status !== 'success') return res.json({ message: 'Payment not completed' });
    const { rows } = await query(
      `SELECT wt.*, u.wallet_balance FROM wallet_transactions wt
       JOIN users u ON u.id = wt.user_id WHERE wt.reference=$1 AND wt.type='credit'`,
      [reference]
    );
    if (!rows.length) return res.status(404).json({ error: 'Transaction not found' });
    const tx = rows[0];
    await transaction(async (client) => {
      await client.query('UPDATE users SET wallet_balance = wallet_balance + $1 WHERE id=$2', [tx.amount, tx.user_id]);
      await client.query('UPDATE wallet_transactions SET description=$1 WHERE reference=$2',
        [`Top-up confirmed (${gateway_ref})`, reference]);
    });
    res.json({ message: 'Wallet credited' });
  } catch (err) {
    res.status(500).json({ error: 'Confirmation failed' });
  }
});

// ── POST /api/payments/purchase ──────────────────────────
router.post('/purchase', requireAuth, [
  body('file_id').isUUID(),
  body('method').isIn(['wallet', 'mtn', 'airtel', 'mastercard', 'stripe']),
], async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(422).json({ errors: errs.array() });

  const { file_id, method } = req.body;
  try {
    const { rows: fileRows } = await query(
      'SELECT id, name, download_price, is_published FROM files WHERE id=$1', [file_id]
    );
    if (!fileRows.length || !fileRows[0].is_published)
      return res.status(404).json({ error: 'File not found' });
    const file = fileRows[0];

    const { rows: existing } = await query(
      `SELECT id FROM purchases WHERE user_id=$1 AND file_id=$2 AND status='completed'`,
      [req.user.id, file_id]
    );
    if (existing.length) return res.status(409).json({ error: 'Already purchased', alreadyOwned: true });

    const price = parseFloat(file.download_price);

    if (method === 'wallet') {
      const { rows: uRows } = await query('SELECT wallet_balance, email, full_name FROM users WHERE id=$1', [req.user.id]);
      const balance = parseFloat(uRows[0].wallet_balance);
      if (balance < price) return res.status(402).json({ error: 'Insufficient balance', balance, required: price });

      await transaction(async (client) => {
        const newBalance = balance - price;
        await client.query('UPDATE users SET wallet_balance=$1 WHERE id=$2', [newBalance, req.user.id]);
        await client.query(
          `INSERT INTO wallet_transactions (user_id, type, amount, balance_after, description)
           VALUES ($1,'debit',$2,$3,$4)`,
          [req.user.id, price, newBalance, `Purchase: ${file.name}`]
        );
        await client.query(
          `INSERT INTO purchases (user_id, file_id, amount_paid, payment_method, status)
           VALUES ($1,$2,$3,'wallet','completed')`,
          [req.user.id, file_id, price]
        );
        await client.query(
          `INSERT INTO activity_log (user_id, action, entity, entity_id) VALUES ($1,'file_purchased','file',$2)`,
          [req.user.id, file_id]
        );
      });

      // FIX #12: Send purchase confirmation email
      emailSvc.sendPurchaseConfirmation(uRows[0].email, uRows[0].full_name, file.name, price).catch(() => {});

      logger.info('File purchased via wallet', { userId: req.user.id, fileId: file_id, price });
      return res.json({ success: true, message: 'Purchase successful' });
    }

    // External payment gateway
    const reference = `PUR-${randomToken(8).toUpperCase()}`;
    await query(
      `INSERT INTO purchases (user_id, file_id, amount_paid, payment_method, payment_ref, status)
       VALUES ($1,$2,$3,$4,$5,'pending')
       ON CONFLICT (user_id, file_id) DO UPDATE SET status='pending', payment_ref=$5`,
      [req.user.id, file_id, price, method, reference]
    );
    const gateway = await initiatePayment({ method, amount: price, reference, userId: req.user.id });
    res.json({ reference, redirectUrl: gateway.redirectUrl, message: gateway.message });
  } catch (err) {
    logger.error('Purchase error', { error: err.message });
    res.status(500).json({ error: 'Purchase failed' });
  }
});

// ── POST /api/payments/purchase/confirm ──────────────────
router.post('/purchase/confirm', async (req, res) => {
  const { reference, status } = req.body;
  try {
    if (status !== 'success') {
      await query(`UPDATE purchases SET status='failed' WHERE payment_ref=$1`, [reference]);
      return res.json({ message: 'Payment failed' });
    }
    await query(`UPDATE purchases SET status='completed' WHERE payment_ref=$1`, [reference]);
    res.json({ success: true, message: 'Purchase confirmed' });
  } catch {
    res.status(500).json({ error: 'Confirmation failed' });
  }
});

// ── GET /api/payments/history (admin) ────────────────────
router.get('/history', requireAuth, requireAdmin, async (req, res) => {
  const { limit = 50, offset = 0, status } = req.query;
  try {
    const { rows } = await query(
      `SELECT p.*, u.email, u.full_name, f.name AS file_name
       FROM purchases p JOIN users u ON u.id=p.user_id JOIN files f ON f.id=p.file_id
       WHERE ($1::text IS NULL OR p.status=$1) ORDER BY p.created_at DESC LIMIT $2 OFFSET $3`,
      [status || null, limit, offset]
    );
    res.json({ purchases: rows });
  } catch {
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

// ── Gateway stub (replace with real SDKs) ────────────────
async function initiatePayment({ method, amount, phone, reference }) {
  if (method === 'mtn')        return { message: `MTN MoMo request sent to ${phone || 'your number'}. Enter PIN.`, redirectUrl: null };
  if (method === 'airtel')     return { message: `Airtel Money request sent to ${phone || 'your number'}.`, redirectUrl: null };
  if (method === 'stripe' || method === 'mastercard')
    return { message: 'Redirecting to card payment...', redirectUrl: `/checkout?ref=${reference}&amount=${amount}` };
  return { message: 'Payment initiated', redirectUrl: null };
}

module.exports = router;
