// backend/middleware/auth.js
const { verifyAccessToken } = require('../utils/jwt');
const { query } = require('../config/db');
const logger = require('../config/logger');

/**
 * requireAuth — attaches req.user or returns 401
 */
async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.slice(7);
  try {
    const decoded = verifyAccessToken(token);

    // Fetch user from DB on every request (ensures revocation is respected)
    const { rows } = await query(
      'SELECT id, email, full_name, role, wallet_balance, is_active, two_fa_enabled FROM users WHERE id = $1',
      [decoded.sub]
    );

    if (!rows.length || !rows[0].is_active) {
      return res.status(401).json({ error: 'User account not found or deactivated' });
    }

    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    logger.warn('Invalid token attempt', { error: err.message, ip: req.ip });
    return res.status(401).json({ error: 'Invalid token' });
  }
}

/**
 * requireAdmin — must be admin or superadmin
 */
function requireAdmin(req, res, next) {
  if (!req.user || !['admin', 'superadmin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

/**
 * optionalAuth — attaches req.user if token present, continues either way
 */
async function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }
  try {
    const decoded = verifyAccessToken(authHeader.slice(7));
    const { rows } = await query(
      'SELECT id, email, full_name, role, wallet_balance FROM users WHERE id = $1 AND is_active = TRUE',
      [decoded.sub]
    );
    if (rows.length) req.user = rows[0];
  } catch {
    // Silently ignore — optional auth
  }
  next();
}

module.exports = { requireAuth, requireAdmin, optionalAuth };
