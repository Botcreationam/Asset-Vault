-- ============================================================
--  AcadVault Database Schema (PostgreSQL)
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email           TEXT UNIQUE NOT NULL,
  password_hash   TEXT,                          -- NULL for OAuth users
  full_name       TEXT NOT NULL,
  avatar_url      TEXT,
  role            TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin','superadmin')),
  oauth_provider  TEXT,                          -- 'google' | 'facebook' | 'apple' | NULL
  oauth_id        TEXT,
  wallet_balance  NUMERIC(10,2) NOT NULL DEFAULT 0.00,
  is_verified     BOOLEAN NOT NULL DEFAULT FALSE,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  two_fa_secret   TEXT,
  two_fa_enabled  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_oauth ON users(oauth_provider, oauth_id);

-- ─────────────────────────────────────────────
-- SESSIONS / REFRESH TOKENS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token TEXT UNIQUE NOT NULL,
  user_agent    TEXT,
  ip_address    TEXT,
  expires_at    TIMESTAMPTZ NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token ON sessions(refresh_token);

-- ─────────────────────────────────────────────
-- FOLDERS  (self-referencing hierarchy)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS folders (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT NOT NULL,
  parent_id   UUID REFERENCES folders(id) ON DELETE CASCADE,
  created_by  UUID REFERENCES users(id) ON DELETE SET NULL,
  position    INT NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_folders_parent ON folders(parent_id);

-- ─────────────────────────────────────────────
-- FILES / RESOURCES
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS files (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  folder_id       UUID NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  description     TEXT,
  file_type       TEXT NOT NULL CHECK (file_type IN ('pdf','slides','image','doc','other')),
  storage_key     TEXT UNIQUE NOT NULL,           -- S3 / local storage path
  original_name   TEXT NOT NULL,
  mime_type       TEXT NOT NULL,
  size_bytes      BIGINT NOT NULL DEFAULT 0,
  page_count      INT,
  thumbnail_key   TEXT,
  is_published    BOOLEAN NOT NULL DEFAULT FALSE,
  download_price  NUMERIC(10,2) NOT NULL DEFAULT 5.00,
  download_count  INT NOT NULL DEFAULT 0,
  view_count      INT NOT NULL DEFAULT 0,
  uploaded_by     UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_files_folder ON files(folder_id);
CREATE INDEX idx_files_type ON files(file_type);
CREATE INDEX idx_files_published ON files(is_published);
-- Full-text search index
CREATE INDEX idx_files_search ON files USING gin(
  to_tsvector('english', name || ' ' || COALESCE(description,''))
);

-- ─────────────────────────────────────────────
-- PURCHASES  (file unlocks)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchases (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  file_id         UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  amount_paid     NUMERIC(10,2) NOT NULL,
  payment_method  TEXT NOT NULL CHECK (payment_method IN ('wallet','mtn','airtel','mastercard','stripe')),
  payment_ref     TEXT,
  status          TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','failed','refunded')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, file_id)
);
CREATE INDEX idx_purchases_user ON purchases(user_id);
CREATE INDEX idx_purchases_file ON purchases(file_id);
CREATE INDEX idx_purchases_status ON purchases(status);

-- ─────────────────────────────────────────────
-- WALLET TRANSACTIONS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type         TEXT NOT NULL CHECK (type IN ('credit','debit')),
  amount       NUMERIC(10,2) NOT NULL,
  balance_after NUMERIC(10,2) NOT NULL,
  description  TEXT,
  reference    TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_wallet_user ON wallet_transactions(user_id);

-- ─────────────────────────────────────────────
-- DOWNLOAD TOKENS  (expiring signed links)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS download_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  token      TEXT UNIQUE NOT NULL,
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  file_id    UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_dl_tokens_token ON download_tokens(token);
CREATE INDEX idx_dl_tokens_expires ON download_tokens(expires_at);

-- ─────────────────────────────────────────────
-- ACTIVITY LOG
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_log (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,
  entity     TEXT,
  entity_id  TEXT,
  metadata   JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_activity_user ON activity_log(user_id);
CREATE INDEX idx_activity_action ON activity_log(action);
CREATE INDEX idx_activity_created ON activity_log(created_at DESC);

-- ─────────────────────────────────────────────
-- VIEW HISTORY
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS view_history (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  file_id    UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  viewed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, file_id)
);
CREATE INDEX idx_view_history_user ON view_history(user_id);

-- ─────────────────────────────────────────────
-- SEED: default admin user  (password: Admin@123)
-- ─────────────────────────────────────────────
INSERT INTO users (email, password_hash, full_name, role, is_verified, wallet_balance)
VALUES (
  'admin@acadvault.com',
  crypt('Admin@123', gen_salt('bf', 12)),
  'AcadVault Admin',
  'admin',
  TRUE,
  999.00
) ON CONFLICT (email) DO NOTHING;

-- ─────────────────────────────────────────────
-- UPDATED_AT trigger function
-- ─────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at    BEFORE UPDATE ON users    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_folders_updated_at  BEFORE UPDATE ON folders  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_files_updated_at    BEFORE UPDATE ON files    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── FIX #2+3: Password reset & email verification columns ─
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token          TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_expires  TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS verify_token         TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS verify_token_expires TIMESTAMPTZ;

-- Indexes for token lookups
CREATE INDEX IF NOT EXISTS idx_users_reset_token  ON users(reset_token)  WHERE reset_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_verify_token ON users(verify_token) WHERE verify_token IS NOT NULL;
