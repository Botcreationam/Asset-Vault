// backend/scripts/seed.js
// Run: node scripts/seed.js
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

const PROGRAMS = [
  {
    name: 'Computer Science',
    years: [
      {
        name: 'Year 1', semesters: [
          {
            name: 'Semester 1', courses: [
              { name: 'Programming Fundamentals', files: [
                { name: 'Intro to Python.pdf',          desc: 'Comprehensive introduction to Python covering syntax, data structures, and OOP.',          type: 'pdf',    size: 4404019,  pages: 120, price: 5 },
                { name: 'Data Structures Notes.pdf',    desc: 'Lecture notes on arrays, linked lists, trees, graphs and sorting algorithms.',              type: 'pdf',    size: 2936013,  pages: 85,  price: 5 },
                { name: 'Week 1 Slides.pptx',           desc: 'Week 1 lecture slides: Variables, Types, and Control Flow.',                                type: 'slides', size: 1153434,  pages: 34,  price: 5 },
              ]},
              { name: 'Mathematics for Computing', files: [
                { name: 'Calculus Textbook.pdf',        desc: 'Full calculus textbook covering limits, derivatives, integrals and series.',                 type: 'pdf',    size: 13002137, pages: 340, price: 5 },
                { name: 'Linear Algebra Notes.pdf',     desc: 'Course notes on vectors, matrices, eigenvalues and linear transformations.',                 type: 'pdf',    size: 3774873,  pages: 98,  price: 5 },
              ]},
            ]
          },
          {
            name: 'Semester 2', courses: [
              { name: 'Object Oriented Programming', files: [
                { name: 'OOP Concepts.pdf',             desc: 'Deep dive into OOP: classes, inheritance, polymorphism, encapsulation.',                     type: 'pdf',    size: 5348024,  pages: 150, price: 5 },
                { name: 'Design Patterns.pdf',          desc: 'Gang of Four design patterns with real-world examples in Java and Python.',                  type: 'pdf',    size: 7654321,  pages: 200, price: 5 },
              ]},
            ]
          },
        ]
      },
      {
        name: 'Year 2', semesters: [
          {
            name: 'Semester 1', courses: [
              { name: 'Database Systems', files: [
                { name: 'SQL Complete Guide.pdf',       desc: 'Complete SQL guide from basic queries to advanced joins, indexes and optimization.',          type: 'pdf',    size: 6502137,  pages: 180, price: 5 },
                { name: 'ER Diagram Notes.pdf',         desc: 'Entity-Relationship diagrams, normalization forms and database design principles.',            type: 'pdf',    size: 2201230,  pages: 60,  price: 5 },
              ]},
              { name: 'Computer Networks', files: [
                { name: 'Networking Fundamentals.pdf',  desc: 'OSI model, TCP/IP stack, routing protocols and network security basics.',                     type: 'pdf',    size: 8112348,  pages: 210, price: 5 },
              ]},
            ]
          },
        ]
      },
    ]
  },
  {
    name: 'Business Administration',
    years: [
      {
        name: 'Year 1', semesters: [
          {
            name: 'Semester 1', courses: [
              { name: 'Introduction to Business', files: [
                { name: 'Business Fundamentals.pdf',    desc: 'Core business concepts: management, marketing, finance and operations.',                     type: 'pdf',    size: 9334022,  pages: 260, price: 5 },
                { name: 'Entrepreneurship Guide.pdf',   desc: 'Practical guide to starting and scaling a business from ideation to funding.',               type: 'pdf',    size: 4718592,  pages: 130, price: 5 },
              ]},
            ]
          },
        ]
      },
    ]
  },
  {
    name: 'Medicine & Health Sciences',
    years: [
      {
        name: 'Year 1', semesters: [
          {
            name: 'Semester 1', courses: [
              { name: 'Human Anatomy', files: [
                { name: 'Human Anatomy Atlas.pdf',      desc: 'Illustrated atlas of human anatomy with detailed diagrams of all body systems.',             type: 'pdf',    size: 19293734, pages: 450, price: 5 },
                { name: 'Physiology Notes.pdf',         desc: 'Comprehensive physiology notes covering cardiovascular, respiratory and nervous systems.',    type: 'pdf',    size: 9646867,  pages: 280, price: 5 },
              ]},
            ]
          },
        ]
      },
    ]
  },
];

async function seed() {
  const client = await pool.connect();
  console.log('🌱 Seeding AcadVault database...\n');
  try {
    await client.query('BEGIN');

    // Get admin user ID
    const { rows: admins } = await client.query(
      "SELECT id FROM users WHERE email='admin@acadvault.com'"
    );
    const adminId = admins[0]?.id;
    if (!adminId) {
      throw new Error('Admin user not found. Run migrate.js first.');
    }

    // Seed demo student
    const studentEmail = 'student@demo.com';
    const { rows: existing } = await client.query('SELECT id FROM users WHERE email=$1', [studentEmail]);
    if (!existing.length) {
      const hash = await bcrypt.hash('Student@123', 12);
      await client.query(
        `INSERT INTO users (email, password_hash, full_name, role, is_verified, wallet_balance)
         VALUES ($1, $2, 'Demo Student', 'student', TRUE, 50.00)`,
        [studentEmail, hash]
      );
      console.log('  ✓ Demo student: student@demo.com / Student@123 (50 units)');
    }

    let fileCount = 0;

    for (const program of PROGRAMS) {
      // Root folder
      const { rows: [prog] } = await client.query(
        `INSERT INTO folders (name, parent_id, created_by) VALUES ($1, NULL, $2)
         ON CONFLICT DO NOTHING RETURNING id`,
        [program.name, adminId]
      );
      if (!prog) continue;
      console.log(`  📁 ${program.name}`);

      for (const year of program.years) {
        const { rows: [yearF] } = await client.query(
          `INSERT INTO folders (name, parent_id, created_by) VALUES ($1, $2, $3) RETURNING id`,
          [year.name, prog.id, adminId]
        );
        for (const sem of year.semesters) {
          const { rows: [semF] } = await client.query(
            `INSERT INTO folders (name, parent_id, created_by) VALUES ($1, $2, $3) RETURNING id`,
            [sem.name, yearF.id, adminId]
          );
          for (const course of sem.courses) {
            const { rows: [courseF] } = await client.query(
              `INSERT INTO folders (name, parent_id, created_by) VALUES ($1, $2, $3) RETURNING id`,
              [course.name, semF.id, adminId]
            );
            for (const file of course.files) {
              const key = `resources/${uuidv4()}.${file.type === 'slides' ? 'pptx' : 'pdf'}`;
              await client.query(
                `INSERT INTO files
                   (folder_id, name, description, file_type, storage_key, original_name,
                    mime_type, size_bytes, page_count, download_price, is_published, uploaded_by)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,TRUE,$11)`,
                [
                  courseF.id, file.name, file.desc, file.type, key, file.name,
                  file.type === 'slides' ? 'application/vnd.openxmlformats-officedocument.presentationml.presentation' : 'application/pdf',
                  file.size, file.pages, file.price, adminId,
                ]
              );
              fileCount++;
            }
          }
        }
      }
    }

    await client.query('COMMIT');
    console.log(`\n✅ Seeded ${fileCount} files across ${PROGRAMS.length} programs.`);
    console.log('✅ Demo student: student@demo.com / Student@123 (50 units)\n');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
