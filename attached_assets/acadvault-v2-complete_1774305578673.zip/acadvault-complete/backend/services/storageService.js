// backend/services/storageService.js
const fs   = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const logger = require('../config/logger');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ── Lazy-load AWS SDK only when needed ───────────────────
let s3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, getSignedUrl;

async function initS3() {
  if (s3Client) return;
  try {
    const s3Module   = require('@aws-sdk/client-s3');
    const presigner  = require('@aws-sdk/s3-request-presigner');
    s3Client            = new s3Module.S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
    PutObjectCommand    = s3Module.PutObjectCommand;
    GetObjectCommand    = s3Module.GetObjectCommand;
    DeleteObjectCommand = s3Module.DeleteObjectCommand;
    getSignedUrl        = presigner.getSignedUrl;
  } catch (e) {
    logger.warn('AWS SDK not available — using local storage');
  }
}

const PROVIDER = process.env.STORAGE_PROVIDER || 'local';
const BUCKET   = process.env.AWS_S3_BUCKET    || 'acadvault-resources';

/**
 * Save a file buffer/stream. Returns the storage key.
 */
async function saveFile(buffer, originalName, mimeType, folder = 'resources') {
  const ext = path.extname(originalName) || '';
  const key = `${folder}/${uuidv4()}${ext}`;

  if (PROVIDER === 's3') {
    await initS3();
    await s3Client.send(new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      Body: buffer,
      ContentType: mimeType,
      ServerSideEncryption: 'AES256',
      // Never public
      ACL: 'private',
    }));
    logger.info('File uploaded to S3', { key });
  } else {
    // Local storage
    const dir = path.join(UPLOAD_DIR, folder);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(UPLOAD_DIR, key), buffer);
    logger.info('File saved locally', { key });
  }

  return key;
}

/**
 * Generate a pre-signed download URL (expires in N minutes).
 * For local: returns a signed express route URL.
 */
async function getDownloadUrl(storageKey, expiresMinutes = 30, filename = 'download') {
  if (PROVIDER === 's3') {
    await initS3();
    const command = new GetObjectCommand({
      Bucket: BUCKET,
      Key: storageKey,
      ResponseContentDisposition: `attachment; filename="${encodeURIComponent(filename)}"`,
    });
    return getSignedUrl(s3Client, command, { expiresIn: expiresMinutes * 60 });
  }
  // Local: return a path the express route will serve
  return `/api/files/stream/${Buffer.from(storageKey).toString('base64url')}`;
}

/**
 * Stream a file directly to a response (local storage only)
 */
function streamLocal(storageKey, res) {
  const filePath = path.join(UPLOAD_DIR, storageKey);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: 'File not found in storage' });
    return;
  }
  res.sendFile(filePath);
}

/**
 * Delete a file from storage
 */
async function deleteFile(storageKey) {
  if (PROVIDER === 's3') {
    await initS3();
    await s3Client.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: storageKey }));
  } else {
    const filePath = path.join(UPLOAD_DIR, storageKey);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
  logger.info('File deleted from storage', { key: storageKey });
}

/**
 * Get file buffer (for local watermarking etc.)
 */
async function getFileBuffer(storageKey) {
  if (PROVIDER === 's3') {
    await initS3();
    const { Body } = await s3Client.send(new GetObjectCommand({ Bucket: BUCKET, Key: storageKey }));
    const chunks = [];
    for await (const chunk of Body) chunks.push(chunk);
    return Buffer.concat(chunks);
  }
  return fs.readFileSync(path.join(UPLOAD_DIR, storageKey));
}

module.exports = { saveFile, getDownloadUrl, streamLocal, deleteFile, getFileBuffer };
