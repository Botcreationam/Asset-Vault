// backend/services/emailService.js
const nodemailer = require('nodemailer');
const logger = require('../config/logger');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) {
    logger.warn('Email not configured — SMTP_HOST/SMTP_USER missing. Emails will be logged only.');
    return null;
  }
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_PORT === '465',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  return transporter;
}

async function sendMail({ to, subject, html, text }) {
  const t = getTransporter();
  if (!t) {
    logger.info('EMAIL (not sent — SMTP not configured)', { to, subject });
    return { messageId: 'dev-mode' };
  }
  try {
    const info = await t.sendMail({
      from: process.env.EMAIL_FROM || '"AcadVault" <noreply@acadvault.com>',
      to, subject, html, text,
    });
    logger.info('Email sent', { to, subject, messageId: info.messageId });
    return info;
  } catch (err) {
    logger.error('Email send failed', { error: err.message, to, subject });
    throw err;
  }
}

// ── Email templates ──────────────────────────────────────
const BASE = (body) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <style>
    body{margin:0;padding:0;background:#07080f;font-family:'Segoe UI',Arial,sans-serif}
    .wrap{max-width:520px;margin:40px auto;background:#0d1526;border:1px solid rgba(59,130,246,0.2);border-radius:16px;overflow:hidden}
    .header{background:linear-gradient(135deg,#1e3a8a,#3b82f6);padding:28px 32px;text-align:center}
    .header h1{color:#fff;font-size:22px;margin:0;font-weight:700}
    .header p{color:rgba(255,255,255,0.7);font-size:13px;margin:4px 0 0}
    .body{padding:32px}
    .body p{color:#94a3b8;font-size:14px;line-height:1.7;margin:0 0 16px}
    .btn{display:inline-block;padding:12px 28px;background:linear-gradient(135deg,#1e3a8a,#3b82f6);color:#fff;text-decoration:none;border-radius:10px;font-weight:600;font-size:14px;margin:8px 0}
    .code{background:#1e293b;border:1px solid rgba(59,130,246,0.3);border-radius:8px;padding:16px;text-align:center;font-size:28px;font-weight:800;color:#60a5fa;letter-spacing:6px;margin:16px 0}
    .footer{padding:20px 32px;border-top:1px solid rgba(255,255,255,0.06);text-align:center;color:#475569;font-size:11px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <h1>🎓 AcadVault</h1>
      <p>Academic Resource Platform</p>
    </div>
    <div class="body">${body}</div>
    <div class="footer">© 2025 AcadVault · Zambia · This email was sent to you because you have an account on AcadVault.</div>
  </div>
</body>
</html>`;

async function sendWelcome(to, name) {
  return sendMail({
    to, subject: 'Welcome to AcadVault! 🎓',
    html: BASE(`
      <p>Hi <strong>${name}</strong>,</p>
      <p>Welcome to AcadVault — your secure academic resource platform! You can now browse and read thousands of resources for free.</p>
      <p>To download files for offline use, top up your wallet with units.</p>
      <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}" class="btn">Start Browsing →</a>
      <p style="margin-top:24px;font-size:12px;color:#475569">Your login: <strong>${to}</strong></p>
    `),
  });
}

async function sendPasswordReset(to, name, resetToken) {
  const link = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password?token=${resetToken}`;
  return sendMail({
    to, subject: 'Reset your AcadVault password',
    html: BASE(`
      <p>Hi <strong>${name}</strong>,</p>
      <p>We received a request to reset your password. Click the button below — this link expires in <strong>1 hour</strong>.</p>
      <a href="${link}" class="btn">Reset Password →</a>
      <p>Or paste this link into your browser:</p>
      <p style="word-break:break-all;font-size:12px;color:#3b82f6">${link}</p>
      <p style="margin-top:24px;font-size:12px;color:#475569">If you didn't request this, you can safely ignore this email.</p>
    `),
  });
}

async function sendEmailVerification(to, name, verifyToken) {
  const link = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-email?token=${verifyToken}`;
  return sendMail({
    to, subject: 'Verify your AcadVault email',
    html: BASE(`
      <p>Hi <strong>${name}</strong>,</p>
      <p>Please verify your email address to activate your AcadVault account.</p>
      <a href="${link}" class="btn">Verify Email →</a>
      <p style="margin-top:24px;font-size:12px;color:#475569">This link expires in 24 hours.</p>
    `),
  });
}

async function sendPurchaseConfirmation(to, name, fileName, amount) {
  return sendMail({
    to, subject: `Download unlocked: ${fileName}`,
    html: BASE(`
      <p>Hi <strong>${name}</strong>,</p>
      <p>Your purchase was successful! You have unlocked:</p>
      <div style="background:#1e293b;border-radius:10px;padding:16px;margin:16px 0">
        <p style="margin:0;font-size:15px;font-weight:600;color:#e8eaf6">📄 ${fileName}</p>
        <p style="margin:6px 0 0;font-size:13px;color:#60a5fa">${amount} units deducted</p>
      </div>
      <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/downloads" class="btn">View My Downloads →</a>
    `),
  });
}

async function sendLoginAlert(to, name, ip) {
  return sendMail({
    to, subject: 'New login to your AcadVault account',
    html: BASE(`
      <p>Hi <strong>${name}</strong>,</p>
      <p>A new login was detected on your account from IP: <strong>${ip}</strong></p>
      <p>If this was you, no action is needed. If not, please change your password immediately.</p>
      <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/profile" class="btn">Secure My Account →</a>
    `),
  });
}

module.exports = { sendWelcome, sendPasswordReset, sendEmailVerification, sendPurchaseConfirmation, sendLoginAlert };
