// frontend/src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';

import AppLayout      from './components/layout/AppLayout';
import HomePage,      { FolderBrowser } from './pages/HomePage';
import FileViewerPage from './pages/FileViewerPage';
import AuthPage       from './pages/AuthPage';
import WalletPage     from './pages/WalletPage';
import AdminPage      from './pages/AdminPage';
import RecentPage     from './pages/RecentPage';
import DownloadsPage  from './pages/DownloadsPage';
import { TermsPage, PrivacyPage, AboutPage } from './pages/LegalPages';
import { Spinner }    from './components/ui';
import { authAPI }    from './api/client';
import toast          from 'react-hot-toast';

// ── Guards ────────────────────────────────────────────────────
function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <FullPageSpinner />;
  if (!user)   return <Navigate to="/login" state={{ from: location }} replace />;
  return children;
}

function RequireAdmin({ children }) {
  const { user, loading, isAdmin } = useAuth();
  const location = useLocation();
  if (loading)  return <FullPageSpinner />;
  if (!user)    return <Navigate to="/login" state={{ from: location }} replace />;
  if (!isAdmin) return <Navigate to="/" replace />;
  return children;
}

function RedirectIfAuth({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <FullPageSpinner />;
  if (user)    return <Navigate to="/" replace />;
  return children;
}

function FullPageSpinner() {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh', background:'var(--bg-base)', flexDirection:'column', gap:16 }}>
      <div style={{ width:52, height:52, borderRadius:14, background:'linear-gradient(135deg,#1e40af,#3b82f6)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 8px 24px rgba(59,130,246,0.4)' }}>
        <svg width={26} height={26} viewBox="0 0 24 24" fill="white"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
      </div>
      <Spinner size={28} />
    </div>
  );
}

function ThemedToaster() {
  const { dark } = useTheme();
  return (
    <Toaster position="top-right" toastOptions={{
      duration: 3500,
      style: {
        background: dark ? '#1a2540' : '#ffffff', color: dark ? '#e8eaf6' : '#0d1b3e',
        border: `1px solid ${dark ? 'rgba(59,130,246,0.25)' : 'rgba(59,130,246,0.2)'}`,
        borderRadius: 10, fontSize: 13, fontFamily:"'Sora', sans-serif",
        boxShadow: dark ? '0 8px 32px rgba(0,0,0,0.4)' : '0 8px 32px rgba(13,27,62,0.12)',
        padding: '10px 16px',
      },
      success: { iconTheme: { primary:'#059669', secondary:'#fff' } },
      error:   { iconTheme: { primary:'#dc2626', secondary:'#fff' } },
    }}/>
  );
}

// Safe date formatter
function safeDate(d) {
  if (!d) return '—';
  try { const p=new Date(d); if(isNaN(p.getTime())) return '—'; return p.toLocaleDateString('en-GB',{dateStyle:'long'}); }
  catch { return '—'; }
}

// ── FIX #1: Profile Page with working save ────────────────────
function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [editing,  setEditing]  = React.useState(false);
  const [name,     setName]     = React.useState('');
  const [saving,   setSaving]   = React.useState(false);

  if (!user) return <Navigate to="/login" replace />;

  const startEdit = () => { setName(user.full_name || ''); setEditing(true); };

  const saveProfile = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await authAPI.patch('/api/auth/profile', { full_name: name.trim() });
      await refreshUser();
      setEditing(false);
      toast.success('Profile updated!');
    } catch (e) {
      toast.error(e.response?.data?.error || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ padding:'28px', maxWidth:560 }}>
      <h1 style={{ fontFamily:'var(--font-display)', fontSize:28, marginBottom:28 }}>My Profile</h1>

      <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-xl)', padding:'28px', marginBottom:20 }}>
        {/* Avatar */}
        <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:24 }}>
          {user.avatar_url ? (
            <img src={user.avatar_url} alt="avatar" style={{ width:64, height:64, borderRadius:'50%', objectFit:'cover' }}/>
          ) : (
            <div style={{ width:64, height:64, borderRadius:'50%', background:'linear-gradient(135deg,#1e40af,#3b82f6)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, fontWeight:700, color:'#fff', flexShrink:0 }}>
              {(user.full_name || user.email || 'U').slice(0,2).toUpperCase()}
            </div>
          )}
          <div>
            {editing ? (
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <input value={name} onChange={e=>setName(e.target.value)}
                  style={{ padding:'7px 10px', borderRadius:8, background:'var(--bg-elevated)', border:'1px solid var(--accent)', color:'var(--text-primary)', fontSize:15, fontWeight:600, outline:'none', fontFamily:'inherit' }}
                  onKeyDown={e=>e.key==='Enter'&&saveProfile()}
                  autoFocus/>
                <button onClick={saveProfile} disabled={saving} style={{ padding:'7px 14px', borderRadius:8, background:'var(--accent)', color:'#fff', border:'none', cursor:'pointer', fontSize:12, fontWeight:600, fontFamily:'inherit' }}>
                  {saving?'…':'Save'}
                </button>
                <button onClick={()=>setEditing(false)} style={{ padding:'7px 12px', borderRadius:8, background:'var(--bg-elevated)', color:'var(--text-muted)', border:'1px solid var(--border)', cursor:'pointer', fontSize:12, fontFamily:'inherit' }}>Cancel</button>
              </div>
            ) : (
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ fontSize:18, fontWeight:700 }}>{user.full_name}</div>
                <button onClick={startEdit} style={{ background:'none', border:'none', color:'var(--accent)', cursor:'pointer', fontSize:11, fontFamily:'inherit', padding:'2px 6px' }}>✏️ Edit</button>
              </div>
            )}
            <div style={{ fontSize:13, color:'var(--text-muted)', marginTop:2 }}>{user.email}</div>
            <span style={{ display:'inline-block', marginTop:6, padding:'2px 10px', borderRadius:20, background:user.role==='admin'?'rgba(245,158,11,0.15)':'rgba(59,130,246,0.15)', color:user.role==='admin'?'#f59e0b':'#3b82f6', fontSize:10, fontWeight:700 }}>
              {(user.role||'student').toUpperCase()}
            </span>
          </div>
        </div>

        {[
          { label:'Email',         value:user.email },
          { label:'Account Type',  value:user.role||'student' },
          { label:'Wallet Balance',value:`${parseFloat(user.wallet_balance||0).toFixed(0)} units` },
          { label:'Verified',      value:user.is_verified?'✅ Verified':'⚠️ Not verified' },
          { label:'Member Since',  value:safeDate(user.created_at) },
        ].map(row => (
          <div key={row.label} style={{ display:'flex', justifyContent:'space-between', padding:'11px 0', borderBottom:'1px solid var(--border-subtle)', fontSize:13 }}>
            <span style={{ color:'var(--text-muted)', fontWeight:500 }}>{row.label}</span>
            <span style={{ fontWeight:600 }}>{row.value}</span>
          </div>
        ))}
      </div>

      <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
        <button onClick={()=>navigate('/wallet')} style={{ flex:1, minWidth:140, padding:'10px', borderRadius:10, background:'var(--accent-light)', border:'1px solid var(--border)', color:'var(--accent)', fontWeight:600, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>Top Up Wallet</button>
        <button onClick={()=>navigate('/downloads')} style={{ flex:1, minWidth:140, padding:'10px', borderRadius:10, background:'var(--bg-elevated)', border:'1px solid var(--border)', color:'var(--text-primary)', fontWeight:600, fontSize:13, cursor:'pointer', fontFamily:'inherit' }}>My Downloads</button>
      </div>

      {/* Legal links */}
      <div style={{ marginTop:20, display:'flex', gap:16, justifyContent:'center' }}>
        {[{l:'Terms of Service',to:'/terms'},{l:'Privacy Policy',to:'/privacy'},{l:'About',to:'/about'}].map(link=>(
          <button key={link.to} onClick={()=>navigate(link.to)} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:11, cursor:'pointer', fontFamily:'inherit', textDecoration:'underline' }}>{link.l}</button>
        ))}
      </div>
    </div>
  );
}

function NotFound() {
  const navigate = useNavigate();
  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg-base)', textAlign:'center', padding:20 }}>
      <div>
        <div style={{ fontSize:80, fontWeight:800, color:'var(--accent)', opacity:0.12, lineHeight:1 }}>404</div>
        <h2 style={{ fontFamily:'var(--font-display)', fontSize:28, marginBottom:10 }}>Page not found</h2>
        <p style={{ color:'var(--text-muted)', fontSize:14, marginBottom:24 }}>The page you're looking for doesn't exist.</p>
        <button onClick={()=>navigate('/')} style={{ padding:'10px 28px', borderRadius:10, background:'linear-gradient(135deg,#1e40af,#3b82f6)', color:'#fff', border:'none', fontWeight:600, fontSize:14, cursor:'pointer', fontFamily:'inherit' }}>Go Home</button>
      </div>
    </div>
  );
}

function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Auth routes */}
        <Route path="/login"          element={<RedirectIfAuth><AuthPage /></RedirectIfAuth>} />
        <Route path="/register"       element={<RedirectIfAuth><AuthPage /></RedirectIfAuth>} />
        <Route path="/forgot-password"element={<AuthPage />} />
        <Route path="/reset-password" element={<AuthPage />} />
        <Route path="/verify-email"   element={<AuthPage />} />

        {/* Legal pages (no auth needed) */}
        <Route path="/terms"   element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/about"   element={<AboutPage />} />

        {/* Main app */}
        <Route element={<AppLayout />}>
          <Route path="/"                  element={<HomePage />} />
          <Route path="/folder/:folderId"  element={<FolderBrowser />} />
          <Route path="/view/:id"          element={<FileViewerPage />} />

          <Route path="/recent"    element={<RequireAuth><RecentPage /></RequireAuth>} />
          <Route path="/downloads" element={<RequireAuth><DownloadsPage /></RequireAuth>} />
          <Route path="/wallet"    element={<RequireAuth><WalletPage /></RequireAuth>} />
          <Route path="/profile"   element={<RequireAuth><ProfilePage /></RequireAuth>} />

          <Route path="/admin/*"   element={<RequireAdmin><AdminPage /></RequireAdmin>} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ThemedToaster />
        <AppRouter />
      </AuthProvider>
    </ThemeProvider>
  );
}
