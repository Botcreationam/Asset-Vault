// frontend/src/components/layout/TopBar.js
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth }  from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useSearch } from '../../hooks';
import { Ico, Spinner, Badge } from '../ui';

export default function TopBar({ onMenuClick, sidebarOpen }) {
  const { user, logout, isAdmin } = useAuth();
  const { dark, toggle } = useTheme();
  const navigate = useNavigate();

  const [query,       setQuery]       = useState('');
  const [showSearch,  setShowSearch]  = useState(false);
  const [showUser,    setShowUser]    = useState(false);
  const { results, loading: searching } = useSearch(query);

  const searchRef = useRef(null);
  const userRef   = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) setShowSearch(false);
      if (userRef.current   && !userRef.current.contains(e.target))   setShowUser(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const fileTypeIcon = (type) => ({ pdf:'pdf', slides:'slides', image:'image' }[type] || 'file');

  return (
    <header style={{
      height: 'var(--topbar-h)', position: 'sticky', top: 0, zIndex: 200,
      display: 'flex', alignItems: 'center', gap: 12, padding: '0 20px',
      background: 'var(--bg-overlay)', borderBottom: '1px solid var(--border)',
      backdropFilter: 'blur(20px)',
    }}>

      {/* Hamburger / Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onMenuClick} style={{
          width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'transparent', border: 'none', color: 'var(--text-secondary)',
          borderRadius: 'var(--radius-md)', cursor: 'pointer', transition: 'var(--transition)',
        }} onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
           onMouseOut={e =>e.currentTarget.style.background='transparent'}>
          <svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor">
            <path d={sidebarOpen ? "M3 18h13v-2H3v2zm0-5h10v-2H3v2zm0-7v2h13V6H3zm18 9.59L17.42 12 21 8.41 19.59 7l-5 5 5 5L21 15.59z" : "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"} />
          </svg>
        </button>

        <div onClick={() => navigate('/')} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 9,
            background: 'linear-gradient(135deg,var(--accent-dark),var(--accent))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Ico name="shield" size={16} style={{ color: '#fff' }} />
          </div>
          <div style={{ display: sidebarOpen ? 'block' : 'none' }}>
            <div style={{ fontSize: 13, fontWeight: 700, letterSpacing: '-0.3px', lineHeight: 1.2 }}>AcadVault</div>
            <div style={{ fontSize: 9, color: 'var(--accent)', fontWeight: 600, letterSpacing: 1.5, marginTop: 1 }}>ACADEMIC RESOURCES</div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div ref={searchRef} style={{ flex: 1, maxWidth: 520, position: 'relative' }}>
        <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: 'var(--text-muted)' }}>
          {searching ? <Spinner size={15} /> : <Ico name="search" size={15} />}
        </div>
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setShowSearch(!!e.target.value); }}
          onFocus={() => query && setShowSearch(true)}
          placeholder="Search resources, courses, topics..."
          style={{
            width: '100%', padding: '8px 12px 8px 38px',
            background: 'var(--bg-elevated)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
            fontSize: 13, outline: 'none',
          }}
          onFocusCapture={e => { e.target.style.borderColor='var(--accent)'; e.target.style.boxShadow='0 0 0 3px rgba(59,130,246,0.1)'; }}
          onBlurCapture={e  => { e.target.style.borderColor='var(--border)';  e.target.style.boxShadow='none'; }}
        />

        {/* Search dropdown */}
        {showSearch && (
          <div className="fade-in" style={{
            position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0,
            background: 'var(--bg-surface)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
            maxHeight: 380, overflowY: 'auto', zIndex: 300,
          }}>
            {results.length === 0 && !searching && (
              <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
                No results for "{query}"
              </div>
            )}
            {results.map(file => (
              <div key={file.id} onClick={() => {
                navigate(`/view/${file.id}`);
                setShowSearch(false); setQuery('');
              }} style={{
                padding: '10px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                transition: 'background 0.15s', borderBottom: '1px solid var(--border-subtle)',
              }}
              onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
              onMouseOut={e =>e.currentTarget.style.background='transparent'}>
                <div style={{ color: 'var(--accent)' }}>
                  <Ico name={fileTypeIcon(file.file_type)} size={16} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }} className="truncate">{file.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{file.folder_name} · {formatSize(file.size_bytes)}</div>
                </div>
                <span style={{ fontSize: 11, color: 'var(--accent)', fontWeight: 600 }}>{file.download_price} units</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Right actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 'auto' }}>

        {/* Theme toggle */}
        <IconBtn onClick={toggle} title={dark ? 'Light mode' : 'Dark mode'}>
          <Ico name={dark ? 'sun' : 'moon'} size={17} />
        </IconBtn>

        {user ? (
          <>
            {/* Wallet chip */}
            <div onClick={() => navigate('/wallet')} style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: '5px 12px',
              background: 'var(--accent-light)', border: '1px solid var(--border)',
              borderRadius: 20, cursor: 'pointer', transition: 'var(--transition)',
            }}
            onMouseOver={e=>e.currentTarget.style.background='rgba(59,130,246,0.22)'}
            onMouseOut={e =>e.currentTarget.style.background='var(--accent-light)'}>
              <Ico name="wallet" size={14} style={{ color: 'var(--accent)' }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--accent)' }}>
                {parseFloat(user.wallet_balance || 0).toFixed(0)} units
              </span>
            </div>

            {/* Notifications */}
            <IconBtn style={{ position: 'relative' }}>
              <Ico name="bell" size={17} />
              <span style={{
                position: 'absolute', top: 7, right: 7, width: 7, height: 7,
                background: '#ef4444', borderRadius: '50%',
                border: '2px solid var(--bg-base)',
              }} />
            </IconBtn>

            {/* User menu */}
            <div ref={userRef} style={{ position: 'relative' }}>
              <div onClick={() => setShowUser(!showUser)} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '5px 10px',
                background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)',
                cursor: 'pointer', border: '1px solid var(--border)', transition: 'var(--transition)',
              }}
              onMouseOver={e=>e.currentTarget.style.borderColor='var(--accent)'}
              onMouseOut={e =>e.currentTarget.style.borderColor='var(--border)'}>
                {user.avatar_url ? (
                  <img src={user.avatar_url} alt="" style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover' }} />
                ) : (
                  <div style={{
                    width: 28, height: 28, borderRadius: '50%',
                    background: 'linear-gradient(135deg,var(--accent-dark),var(--accent))',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontWeight: 700, color: '#fff',
                  }}>
                    {(user.full_name || user.email || 'U').slice(0,2).toUpperCase()}
                  </div>
                )}
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: 12, fontWeight: 600, lineHeight: 1.3 }}>
                    {(user.full_name || '').split(' ')[0] || 'User'}
                  </span>
                  {isAdmin && <Badge color="yellow" size="sm">ADMIN</Badge>}
                </div>
                <Ico name="chevDown" size={14} style={{ color: 'var(--text-muted)' }} />
              </div>

              {showUser && (
                <div className="fade-in" style={{
                  position: 'absolute', top: 'calc(100% + 8px)', right: 0,
                  background: 'var(--bg-surface)', border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
                  width: 220, zIndex: 300, overflow: 'hidden',
                }}>
                  <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{user.full_name}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{user.email}</div>
                  </div>
                  {[
                    { icon: 'user',    label: 'Profile',        path: '/profile' },
                    { icon: 'wallet',  label: 'Wallet',         path: '/wallet' },
                    { icon: 'star',    label: 'My Downloads',   path: '/downloads' },
                    { icon: 'history', label: 'Recent',         path: '/recent' },
                    ...(isAdmin ? [{ icon: 'admin', label: 'Admin Panel', path: '/admin' }] : []),
                  ].map(item => (
                    <MenuRow key={item.path} icon={item.icon} label={item.label}
                      onClick={() => { navigate(item.path); setShowUser(false); }} />
                  ))}
                  <div style={{ borderTop: '1px solid var(--border-subtle)', marginTop: 4 }}>
                    <MenuRow icon="logout" label="Sign Out" onClick={handleLogout} danger />
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <button onClick={() => navigate('/login')} style={{
            padding: '7px 20px', borderRadius: 'var(--radius-md)',
            background: 'linear-gradient(135deg,var(--accent-dark),var(--accent))',
            color: '#fff', border: 'none', fontWeight: 600, fontSize: 13,
            cursor: 'pointer', fontFamily: 'var(--font-sans)',
          }}>Sign In</button>
        )}
      </div>
    </header>
  );
}

function IconBtn({ children, onClick, title, style }) {
  return (
    <button onClick={onClick} title={title} style={{
      width: 34, height: 34, borderRadius: 'var(--radius-md)', border: 'none',
      background: 'transparent', color: 'var(--text-secondary)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', transition: 'var(--transition)', position: 'relative', ...style,
    }}
    onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
    onMouseOut={e =>e.currentTarget.style.background='transparent'}>
      {children}
    </button>
  );
}

function MenuRow({ icon, label, onClick, danger }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '9px 16px',
      cursor: 'pointer', transition: 'background 0.15s',
      color: danger ? 'var(--danger)' : 'var(--text-primary)',
      fontSize: 13,
    }}
    onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
    onMouseOut={e =>e.currentTarget.style.background='transparent'}>
      <Ico name={icon} size={15} />
      {label}
    </div>
  );
}

function formatSize(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024 * 1024) return `${(bytes/1024).toFixed(0)} KB`;
  return `${(bytes/1024/1024).toFixed(1)} MB`;
}
