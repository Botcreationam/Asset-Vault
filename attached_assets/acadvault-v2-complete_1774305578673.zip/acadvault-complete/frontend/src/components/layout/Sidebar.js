// frontend/src/components/layout/Sidebar.js
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth }  from '../../context/AuthContext';
import { useFolderTree } from '../../hooks';
import { Ico, Spinner } from '../ui';

export default function Sidebar({ open }) {
  const { user, isAdmin } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const { tree, loading } = useFolderTree();

  const W  = open ? 'var(--sidebar-w)' : 'var(--sidebar-collapsed)';
  const active = (path) => location.pathname === path;

  return (
    <aside style={{
      width: W, minWidth: W, maxWidth: W,
      height: 'calc(100vh - var(--topbar-h))',
      position: 'sticky', top: 'var(--topbar-h)',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
      transition: 'width 0.25s cubic-bezier(0.4,0,0.2,1), min-width 0.25s cubic-bezier(0.4,0,0.2,1)',
    }}>
      {/* Primary nav */}
      <nav style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        <NavItem icon="home"    label="Home"          path="/"          open={open} active={active('/')}          onClick={() => navigate('/')} />
        <NavItem icon="history" label="Recent"        path="/recent"    open={open} active={active('/recent')}    onClick={() => navigate('/recent')} />
        <NavItem icon="star"    label="My Downloads"  path="/downloads" open={open} active={active('/downloads')} onClick={() => navigate('/downloads')} />
        {user && <NavItem icon="wallet" label="Wallet" path="/wallet"   open={open} active={active('/wallet')}   onClick={() => navigate('/wallet')} />}
        {isAdmin && <>
          <div style={{ height: 1, background: 'var(--border-subtle)', margin: '6px 4px' }} />
          <NavItem icon="admin"  label="Admin"  path="/admin"  open={open} active={location.pathname.startsWith('/admin')} onClick={() => navigate('/admin')}  accent="#f59e0b" />
        </>}
      </nav>

      {/* Divider */}
      <div style={{ height: 1, background: 'var(--border-subtle)', margin: '4px 8px' }} />

      {/* Folder tree */}
      {open && (
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 8px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', letterSpacing: 1.2, padding: '4px 8px 8px' }}>
            PROGRAMS
          </div>
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 12 }}>
              <Spinner size={18} />
            </div>
          ) : (
            tree.map(folder => (
              <FolderRow key={folder.id} folder={folder} depth={0} navigate={navigate} location={location} />
            ))
          )}
        </div>
      )}
    </aside>
  );
}

function NavItem({ icon, label, open, active, onClick, accent }) {
  const color = active ? (accent || 'var(--accent)') : 'var(--text-secondary)';
  return (
    <button onClick={onClick} title={!open ? label : undefined} style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: open ? '9px 12px' : '9px',
      justifyContent: open ? 'flex-start' : 'center',
      borderRadius: 'var(--radius-md)', border: 'none',
      background: active ? (accent ? 'rgba(245,158,11,0.12)' : 'var(--accent-light)') : 'transparent',
      color, fontWeight: active ? 600 : 400, fontSize: 13,
      cursor: 'pointer', width: '100%', transition: 'var(--transition)',
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap', overflow: 'hidden',
    }}
    onMouseOver={e => { if (!active) e.currentTarget.style.background='var(--bg-elevated)'; }}
    onMouseOut={e  => { if (!active) e.currentTarget.style.background='transparent'; }}>
      <Ico name={icon} size={18} style={{ flexShrink: 0 }} />
      {open && <span>{label}</span>}
    </button>
  );
}

function FolderRow({ folder, depth, navigate, location }) {
  const [expanded, setExpanded] = useState(depth === 0);
  const hasChildren = folder.children && folder.children.length > 0;
  const isActive    = location.pathname === `/folder/${folder.id}`;

  return (
    <div>
      <div
        onClick={() => {
          if (hasChildren) setExpanded(e => !e);
          navigate(`/folder/${folder.id}`);
        }}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: `6px 8px 6px ${depth * 14 + 8}px`,
          borderRadius: 'var(--radius-sm)', cursor: 'pointer',
          transition: 'background 0.15s',
          background: isActive ? 'var(--accent-light)' : 'transparent',
          color: isActive ? 'var(--accent)' : 'var(--text-secondary)',
          fontSize: 13,
        }}
        onMouseOver={e => { if (!isActive) e.currentTarget.style.background='var(--bg-elevated)'; }}
        onMouseOut={e  => { if (!isActive) e.currentTarget.style.background='transparent'; }}
      >
        {hasChildren ? (
          <Ico name={expanded ? 'chevDown' : 'chevRight'} size={13} style={{ flexShrink: 0 }} />
        ) : (
          <span style={{ width: 13, flexShrink: 0 }} />
        )}
        <Ico name="folder" size={15} style={{ color: '#f59e0b', flexShrink: 0 }} />
        <span style={{ truncate: true, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
          {folder.name}
        </span>
        {folder.file_count > 0 && (
          <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600 }}>{folder.file_count}</span>
        )}
      </div>
      {expanded && hasChildren && (
        <div>
          {folder.children.map(child => (
            <FolderRow key={child.id} folder={child} depth={depth + 1} navigate={navigate} location={location} />
          ))}
        </div>
      )}
    </div>
  );
}
