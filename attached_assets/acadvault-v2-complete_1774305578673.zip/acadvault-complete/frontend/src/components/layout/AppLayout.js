// frontend/src/components/layout/AppLayout.js
import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import TopBar  from './TopBar';
import Sidebar from './Sidebar';

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile,    setIsMobile]    = useState(false);

  // FIX #5: Detect mobile and auto-collapse sidebar
  useEffect(() => {
    const check = () => {
      const mobile = window.innerWidth <= 640;
      const tablet = window.innerWidth <= 900;
      setIsMobile(mobile);
      // Auto-collapse on tablet/mobile
      if (tablet) setSidebarOpen(false);
      else         setSidebarOpen(true);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const handleOverlayClick = () => {
    if (isMobile) setSidebarOpen(false);
  };

  return (
    <div className="app-layout">
      <TopBar
        sidebarOpen={sidebarOpen}
        onMenuClick={() => setSidebarOpen(o => !o)}
      />

      <div className="app-body">
        {/* Mobile overlay backdrop */}
        {isMobile && sidebarOpen && (
          <div
            className="sidebar-overlay overlay-visible"
            onClick={handleOverlayClick}
          />
        )}

        {/* Sidebar */}
        <div
          className={`app-sidebar ${isMobile && sidebarOpen ? 'sidebar-open' : ''}`}
          style={{
            width: sidebarOpen && !isMobile ? 'var(--sidebar-w)' : isMobile ? 'var(--sidebar-w)' : 'var(--sidebar-collapsed)',
            minWidth: sidebarOpen && !isMobile ? 'var(--sidebar-w)' : isMobile ? 0 : 'var(--sidebar-collapsed)',
          }}
        >
          <Sidebar
            open={sidebarOpen || isMobile}
            onNavigate={() => { if (isMobile) setSidebarOpen(false); }}
          />
        </div>

        {/* Main content */}
        <main className="app-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
