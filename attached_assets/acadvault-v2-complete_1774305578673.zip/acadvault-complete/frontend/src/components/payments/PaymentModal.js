// frontend/src/components/payments/PaymentModal.js
import React, { useState } from 'react';
import { Modal, Button, Ico, Spinner } from '../ui';
import { useWallet } from '../../hooks';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const METHODS = [
  { id: 'wallet',     label: 'AcadVault Wallet',  emoji: '💳', desc: 'Instant deduction' },
  { id: 'mtn',        label: 'MTN Mobile Money',   emoji: '📱', desc: 'Dial *165#' },
  { id: 'airtel',     label: 'Airtel Money',        emoji: '📲', desc: 'Dial *185#' },
  { id: 'mastercard', label: 'Mastercard / Visa',   emoji: '💳', desc: 'Secure card payment' },
];

export default function PaymentModal({ open, onClose, file, onSuccess }) {
  const { user, refreshUser } = useAuth();
  const { balance, purchase, refetch: refetchWallet } = useWallet();
  const [method,   setMethod]   = useState('wallet');
  const [step,     setStep]     = useState(1); // 1=select, 2=processing, 3=success
  const [phone,    setPhone]    = useState('');
  const [loading,  setLoading]  = useState(false);

  if (!file) return null;

  const price = parseFloat(file.download_price || 5);

  const reset = () => { setStep(1); setMethod('wallet'); setPhone(''); setLoading(false); };
  const close = () => { reset(); onClose?.(); };

  const handlePay = async () => {
    if (method === 'wallet' && balance < price) {
      toast.error(`Insufficient balance. You have ${balance} units, need ${price}.`);
      return;
    }
    setLoading(true);
    setStep(2);
    try {
      await purchase(file.id, method);
      await refreshUser();
      await refetchWallet();
      setStep(3);
      onSuccess?.();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Payment failed. Please try again.');
      setStep(1);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open={open} onClose={step !== 2 ? close : undefined} size="md">
      {step === 1 && (
        <div>
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div style={{
              width: 52, height: 52, borderRadius: 14, margin: '0 auto 12px',
              background: 'linear-gradient(135deg,var(--accent-dark),var(--accent))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Ico name="wallet" size={24} style={{ color: '#fff' }} />
            </div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 22, marginBottom: 4 }}>Unlock Download</h2>
            <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Choose your payment method to download this resource</p>
          </div>

          {/* File preview */}
          <div style={{
            background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)',
            padding: '12px 16px', marginBottom: 20, display: 'flex', gap: 12, alignItems: 'center',
            border: '1px solid var(--border)',
          }}>
            <Ico name={file.file_type === 'slides' ? 'slides' : 'pdf'} size={28} style={{ color: 'var(--accent)' }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }} className="truncate">{file.name}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                {file.page_count ? `${file.page_count} pages · ` : ''}{formatSize(file.size_bytes)}
              </div>
            </div>
            <div style={{ textAlign: 'right', flexShrink: 0 }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--accent)', lineHeight: 1 }}>{price}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>units</div>
            </div>
          </div>

          {/* Wallet balance */}
          <div style={{
            background: balance >= price ? 'rgba(5,150,105,0.08)' : 'rgba(220,38,38,0.08)',
            border: `1px solid ${balance >= price ? 'rgba(5,150,105,0.25)' : 'rgba(220,38,38,0.25)'}`,
            borderRadius: 'var(--radius-md)', padding: '10px 14px', marginBottom: 16,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Wallet Balance</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: balance >= price ? 'var(--success)' : 'var(--danger)' }}>
              {balance} units {balance < price && `(need ${price - balance} more)`}
            </div>
          </div>

          {/* Payment methods */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
            {METHODS.map(m => (
              <div key={m.id} onClick={() => setMethod(m.id)} style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px',
                borderRadius: 'var(--radius-md)', cursor: 'pointer', transition: 'var(--transition)',
                background: method === m.id ? 'var(--accent-light)' : 'var(--bg-elevated)',
                border: `1.5px solid ${method === m.id ? 'var(--accent)' : 'var(--border)'}`,
              }}>
                <span style={{ fontSize: 22 }}>{m.emoji}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{m.label}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{m.desc}</div>
                </div>
                {m.id === 'wallet' && (
                  <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{balance} units</span>
                )}
                <div style={{
                  width: 18, height: 18, borderRadius: '50%',
                  border: `2px solid ${method === m.id ? 'var(--accent)' : 'var(--border)'}`,
                  background: method === m.id ? 'var(--accent)' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  {method === m.id && <Ico name="check" size={10} style={{ color: '#fff' }} />}
                </div>
              </div>
            ))}
          </div>

          {/* Phone for mobile money */}
          {(method === 'mtn' || method === 'airtel') && (
            <input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder={`Enter ${method === 'mtn' ? 'MTN' : 'Airtel'} phone number`}
              style={{
                width: '100%', padding: '9px 12px', marginBottom: 14,
                background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
                fontSize: 13, outline: 'none', fontFamily: 'var(--font-sans)',
              }}
            />
          )}

          <Button variant="primary" fullWidth size="lg" onClick={handlePay} loading={loading}
            icon={<Ico name={method === 'wallet' ? 'wallet' : 'lock'} size={16} style={{ color: '#fff' }} />}>
            Pay {price} Units & Unlock Download
          </Button>
        </div>
      )}

      {step === 2 && (
        <div style={{ textAlign: 'center', padding: '48px 24px' }}>
          <Spinner size={48} />
          <h3 style={{ marginTop: 20, fontFamily: 'var(--font-display)', fontSize: 20 }}>Processing Payment</h3>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>
            {method === 'mtn' || method === 'airtel'
              ? 'Please check your phone and enter your PIN to confirm...'
              : 'Completing secure transaction...'}
          </p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 20 }}>
            {[0,1,2].map(i => (
              <div key={i} className="pulse-ani" style={{
                width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)',
                animationDelay: `${i * 0.3}s`,
              }} />
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div style={{ textAlign: 'center', padding: '40px 24px' }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%', margin: '0 auto 16px',
            background: 'rgba(5,150,105,0.12)', border: '2px solid var(--success)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Ico name="check" size={32} style={{ color: 'var(--success)' }} />
          </div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--success)', marginBottom: 8 }}>
            Payment Successful!
          </h3>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>
            "{file.name}" is now unlocked for download.
          </p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 24 }}>
            New balance: {balance - price} units
          </p>
          <div style={{ display: 'flex', gap: 10 }}>
            <Button variant="ghost" fullWidth onClick={close}>Close</Button>
            <Button variant="success" fullWidth icon={<Ico name="download" size={15} style={{ color: '#fff' }} />}
              onClick={close}>Download Now</Button>
          </div>
        </div>
      )}
    </Modal>
  );
}

function formatSize(b) {
  if (!b) return '';
  return b < 1048576 ? `${(b/1024).toFixed(0)} KB` : `${(b/1048576).toFixed(1)} MB`;
}
