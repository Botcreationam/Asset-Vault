// frontend/src/components/files/FileCard.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Ico, Badge, Button } from '../ui';

const TYPE_CONFIG = {
  pdf:    { icon: 'pdf',    color: '#ef4444', label: 'PDF'    },
  slides: { icon: 'slides', color: '#3b82f6', label: 'SLIDES' },
  image:  { icon: 'image',  color: '#10b981', label: 'IMAGE'  },
  doc:    { icon: 'file',   color: '#8b5cf6', label: 'DOC'    },
  other:  { icon: 'file',   color: '#6b7280', label: 'FILE'   },
};

export function FileCard({ file, owned, onDownload, view = 'grid' }) {
  const navigate = useNavigate();
  const cfg = TYPE_CONFIG[file.file_type] || TYPE_CONFIG.other;

  const formatSize = (b) => {
    if (!b) return '—';
    return b < 1048576 ? `${(b/1024).toFixed(0)} KB` : `${(b/1048576).toFixed(1)} MB`;
  };

  if (view === 'list') {
    return (
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 90px 70px 130px',
        padding: '10px 16px', alignItems: 'center',
        borderBottom: '1px solid var(--border-subtle)',
        transition: 'background 0.15s', cursor: 'pointer',
      }}
      onClick={() => navigate(`/view/${file.id}`)}
      onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
      onMouseOut={e =>e.currentTarget.style.background='transparent'}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
          <Ico name={cfg.icon} size={16} style={{ color: cfg.color, flexShrink: 0 }} />
          <span style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{file.name}</span>
          {owned && <Badge color="green" size="sm">OWNED</Badge>}
        </div>
        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatSize(file.size_bytes)}</span>
        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{file.page_count ? `${file.page_count}p` : '—'}</span>
        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }} onClick={e=>e.stopPropagation()}>
          <Button size="sm" variant="secondary" icon={<Ico name="eye" size={12} />} onClick={() => navigate(`/view/${file.id}`)}>Read</Button>
          <Button size="sm" variant={owned ? 'success' : 'ghost'} icon={<Ico name={owned ? 'download' : 'lock'} size={12} />}
            onClick={(e) => { e.stopPropagation(); onDownload?.(file); }}>
            {owned ? '↓' : `${file.download_price}u`}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="hover-lift" onClick={() => navigate(`/view/${file.id}`)} style={{
      background: 'var(--bg-surface)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)', padding: 16, cursor: 'pointer',
      display: 'flex', flexDirection: 'column', position: 'relative',
      boxShadow: 'var(--shadow-sm)',
    }}>
      {/* Type badge */}
      <div style={{
        position: 'absolute', top: 10, left: 10,
        padding: '2px 7px', borderRadius: 20,
        background: `${cfg.color}20`, color: cfg.color,
        fontSize: 9, fontWeight: 700, letterSpacing: 0.5,
      }}>{cfg.label}</div>

      {/* Owned indicator */}
      {owned && (
        <div style={{
          position: 'absolute', top: 10, right: 10, width: 20, height: 20,
          background: 'rgba(5,150,105,0.15)', border: '1.5px solid #059669',
          borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Ico name="check" size={11} style={{ color: '#059669' }} />
        </div>
      )}

      {/* Icon area */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        height: 64, marginTop: 20, marginBottom: 12,
      }}>
        <div style={{
          width: 48, height: 56, background: `${cfg.color}15`,
          borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
          border: `1.5px solid ${cfg.color}30`,
        }}>
          <Ico name={cfg.icon} size={24} style={{ color: cfg.color }} />
        </div>
      </div>

      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 4, lineHeight: 1.4, flex: 1 }} className="truncate">
        {file.name}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 12 }}>
        {file.page_count ? `${file.page_count}p · ` : ''}{formatSize(file.size_bytes)}
      </div>

      {/* Actions */}
      <div style={{ display: 'flex', gap: 6 }} onClick={e=>e.stopPropagation()}>
        <Button size="sm" variant="secondary" fullWidth onClick={() => navigate(`/view/${file.id}`)}>
          Read
        </Button>
        <Button size="sm" variant={owned ? 'success' : 'ghost'} fullWidth
          icon={<Ico name={owned ? 'download' : 'lock'} size={12} />}
          onClick={() => onDownload?.(file)}>
          {owned ? '↓ Save' : `${file.download_price}u`}
        </Button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
// FOLDER CARD
// ─────────────────────────────────────────────────────────
export function FolderCard({ folder, onClick, onDelete }) {
  const count = (folder.subfolder_count || 0) + (folder.file_count || 0);
  return (
    <div className="hover-lift" onClick={onClick} style={{
      background: 'var(--bg-surface)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)', padding: '18px 16px',
      cursor: 'pointer', position: 'relative', boxShadow: 'var(--shadow-sm)',
    }}>
      {onDelete && (
        <button onClick={e => { e.stopPropagation(); onDelete(); }} style={{
          position: 'absolute', top: 8, right: 8, width: 22, height: 22,
          borderRadius: 5, background: 'var(--danger-bg)', border: 'none',
          color: 'var(--danger)', cursor: 'pointer', display: 'flex',
          alignItems: 'center', justifyContent: 'center', fontSize: 10,
        }}>
          <Ico name="trash" size={12} />
        </button>
      )}
      <div style={{ marginBottom: 10 }}>
        <Ico name="folder" size={34} style={{ color: '#f59e0b' }} />
      </div>
      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4, lineHeight: 1.3 }} className="truncate">
        {folder.name}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
        {count} item{count !== 1 ? 's' : ''}
      </div>
    </div>
  );
}
