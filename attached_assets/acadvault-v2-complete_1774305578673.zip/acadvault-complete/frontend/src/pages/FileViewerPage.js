// frontend/src/pages/FileViewerPage.js
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useFile, useDownload } from '../hooks';
import { useAuth } from '../context/AuthContext';
import { filesAPI } from '../api/client';
import PaymentModal from '../components/payments/PaymentModal';
import { Button, Ico, Spinner, Badge } from '../components/ui';

// FIX #4: Try to use react-pdf if available, otherwise use iframe viewer
let PDFViewer = null;
try {
  const { Document, Page, pdfjs } = require('react-pdf');
  pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;
  PDFViewer = { Document, Page };
} catch {
  // react-pdf not available — use iframe fallback
}

export default function FileViewerPage() {
  const { id }    = useParams();
  const navigate  = useNavigate();
  const { user }  = useAuth();
  const { file, loading, error, setFile } = useFile(id);
  const { download, downloading } = useDownload();

  const [payOpen,    setPayOpen]    = useState(false);
  const [page,       setPage]       = useState(1);
  const [numPages,   setNumPages]   = useState(null);
  const [owned,      setOwned]      = useState(false);
  const [zoom,       setZoom]       = useState(1.0);
  const [pdfError,   setPdfError]   = useState(false);
  const [streamUrl,  setStreamUrl]  = useState(null);

  useEffect(() => { if (file) setOwned(!!file.owned); }, [file]);

  // Record view
  useEffect(() => {
    if (file && user) filesAPI.recordView(file.id).catch(() => {});
  }, [file, user]);

  // Build secure stream URL
  useEffect(() => {
    if (file && user) {
      const token = localStorage.getItem('accessToken');
      const base  = process.env.REACT_APP_API_URL || '';
      setStreamUrl(`${base}/api/files/${file.id}/stream?token=${encodeURIComponent(token)}`);
    }
  }, [file, user]);

  const handleDownload = () => {
    if (!user)  { navigate('/login'); return; }
    if (owned)  { download(file.id, file.name); }
    else        { setPayOpen(true); }
  };

  const onDocumentLoadSuccess = useCallback(({ numPages: n }) => {
    setNumPages(n);
    setPdfError(false);
  }, []);

  const formatSize = (b) => {
    if (!b) return '—';
    return b < 1048576 ? `${(b/1024).toFixed(0)} KB` : `${(b/1048576).toFixed(1)} MB`;
  };

  if (loading) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', minHeight:400 }}>
      <Spinner size={36} />
    </div>
  );
  if (error || !file) return (
    <div style={{ padding:40, textAlign:'center', color:'var(--danger)' }}>
      <div style={{ marginBottom:12 }}>{error || 'File not found'}</div>
      <Button onClick={() => navigate(-1)}>Go Back</Button>
    </div>
  );

  const totalPages = numPages || file.page_count || 1;
  const isPDF      = file.file_type === 'pdf' || file.mime_type === 'application/pdf';

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'calc(100vh - var(--topbar-h))' }}>

      {/* Toolbar */}
      <div className="viewer-toolbar" style={{
        display:'flex', alignItems:'center', gap:10, padding:'10px 20px',
        background:'var(--bg-surface)', borderBottom:'1px solid var(--border)', flexShrink:0, flexWrap:'wrap',
      }}>
        <Button size="sm" variant="ghost"
          icon={<Ico name="chevRight" size={14} style={{ transform:'rotate(180deg)' }}/>}
          onClick={() => navigate(-1)}>Back</Button>

        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:14, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {file.name}
          </div>
          <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:1 }}>
            {file.folder_name} · {formatSize(file.size_bytes)} · {totalPages} pages
          </div>
        </div>

        <Badge color="red">🔒 PROTECTED</Badge>

        {/* Zoom controls */}
        {user && isPDF && !pdfError && PDFViewer && (
          <div style={{ display:'flex', alignItems:'center', gap:6, background:'var(--bg-elevated)', padding:'4px 10px', borderRadius:8, border:'1px solid var(--border)' }}>
            <button onClick={() => setZoom(z => Math.max(0.5, +(z-0.1).toFixed(1)))}
              style={{ background:'none', border:'none', color:'var(--text-primary)', cursor:'pointer', fontSize:16, width:24 }}>−</button>
            <span style={{ fontSize:12, minWidth:44, textAlign:'center' }}>{Math.round(zoom*100)}%</span>
            <button onClick={() => setZoom(z => Math.min(2.5, +(z+0.1).toFixed(1)))}
              style={{ background:'none', border:'none', color:'var(--text-primary)', cursor:'pointer', fontSize:16, width:24 }}>+</button>
          </div>
        )}

        {/* Page navigation */}
        {totalPages > 1 && (
          <div style={{ display:'flex', alignItems:'center', gap:6, background:'var(--bg-elevated)', padding:'4px 12px', borderRadius:8, border:'1px solid var(--border)' }}>
            <button disabled={page===1} onClick={() => setPage(p=>p-1)} style={{ background:'none', border:'none', color:page===1?'var(--text-muted)':'var(--text-primary)', cursor:page===1?'default':'pointer', fontSize:16 }}>‹</button>
            <span style={{ fontSize:12, minWidth:90, textAlign:'center' }}>Page {page} / {totalPages}</span>
            <button disabled={page===totalPages} onClick={() => setPage(p=>p+1)} style={{ background:'none', border:'none', color:page===totalPages?'var(--text-muted)':'var(--text-primary)', cursor:page===totalPages?'default':'pointer', fontSize:16 }}>›</button>
          </div>
        )}

        <Button
          variant={owned ? 'success' : 'primary'}
          icon={<Ico name={owned ? 'download' : 'lock'} size={15} style={{ color:'#fff' }}/>}
          loading={downloading[file.id]}
          onClick={handleDownload}
        >
          {owned ? 'Download' : `Unlock — ${file.download_price} units`}
        </Button>
      </div>

      {/* Viewer area */}
      <div style={{ flex:1, overflow:'auto', background:'#1a1a2e', display:'flex', justifyContent:'center', padding:'24px 20px' }}
        onContextMenu={e => e.preventDefault()}>

        {!user ? (
          <div style={{ textAlign:'center', paddingTop:80, maxWidth:360 }}>
            <Ico name="lock" size={48} style={{ color:'var(--accent)', opacity:0.4, display:'block', margin:'0 auto 16px' }}/>
            <h3 style={{ fontFamily:'var(--font-display)', fontSize:22, marginBottom:8 }}>Sign in to read</h3>
            <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:20 }}>
              Create a free account to read any resource in your browser.
            </p>
            <Button variant="primary" onClick={() => navigate('/login')}>Sign In / Register</Button>
          </div>
        ) : (
          // ── FIX #4: Real PDF viewer using react-pdf, with iframe fallback ──
          <div className="viewer-doc" style={{
            width:'min(780px,100%)', background:'#fff', borderRadius:4,
            boxShadow:'0 20px 80px rgba(0,0,0,0.5)', minHeight:900,
            padding:'48px 60px', position:'relative', userSelect:'none',
          }}
          onCopy={e => e.preventDefault()} onDragStart={e => e.preventDefault()}>

            {/* Watermark */}
            <div style={{
              position:'absolute', inset:0, display:'flex', alignItems:'center',
              justifyContent:'center', pointerEvents:'none',
              transform:'rotate(-35deg)', opacity:0.045, zIndex:10,
            }}>
              <div style={{ fontSize:20, fontWeight:800, color:'#1e40af', letterSpacing:3, whiteSpace:'nowrap' }}>
                {user.email} · ACADVAULT
              </div>
            </div>

            {/* FIX #4: Real react-pdf viewer */}
            {isPDF && streamUrl && PDFViewer && !pdfError ? (
              <div style={{ position:'relative', zIndex:2 }}>
                <PDFViewer.Document
                  file={{ url: streamUrl, withCredentials: false }}
                  onLoadSuccess={onDocumentLoadSuccess}
                  onLoadError={() => setPdfError(true)}
                  loading={
                    <div style={{ textAlign:'center', padding:'60px 0' }}>
                      <Spinner size={32}/>
                      <div style={{ marginTop:12, fontSize:13, color:'#64748b', fontFamily:'sans-serif' }}>Loading document...</div>
                    </div>
                  }
                >
                  <PDFViewer.Page
                    pageNumber={page}
                    scale={zoom}
                    renderTextLayer={false}
                    renderAnnotationLayer={false}
                    width={Math.min(660, window.innerWidth - 80)}
                  />
                </PDFViewer.Document>
                {/* Footer */}
                <div style={{ marginTop:16, borderTop:'1px solid #e8edf8', paddingTop:12, display:'flex', justifyContent:'space-between', fontFamily:'sans-serif', fontSize:10, color:'#aaa' }}>
                  <span>© AcadVault · Authorized viewing only</span>
                  <span>Page {page} of {totalPages}</span>
                </div>
              </div>
            ) : isPDF && streamUrl ? (
              /* Iframe fallback when react-pdf fails or not available */
              <div style={{ position:'relative', zIndex:2 }}>
                <iframe
                  src={`${streamUrl}#toolbar=0&navpanes=0&scrollbar=0&view=FitH&page=${page}`}
                  style={{ width:'100%', height:'80vh', border:'none', borderRadius:4 }}
                  title={file.name}
                />
                <div style={{ marginTop:12, textAlign:'center', fontFamily:'sans-serif', fontSize:11, color:'#888' }}>
                  Page {page} of {totalPages} · AcadVault Protected Document
                </div>
              </div>
            ) : (
              /* Non-PDF content (slides, images, docs) */
              <div style={{ position:'relative', zIndex:2, color:'#1a1a2e', fontFamily:'Georgia,serif' }}>
                <div style={{ textAlign:'center', marginBottom:32 }}>
                  <div style={{ fontSize:9, color:'#888', letterSpacing:2, fontFamily:'sans-serif', marginBottom:8 }}>
                    ACADVAULT ACADEMIC PLATFORM — PROTECTED CONTENT
                  </div>
                  <div style={{ width:48, height:2, background:'#1e40af', margin:'0 auto 24px' }}/>
                  <h1 style={{ fontSize:24, fontWeight:700, color:'#0d1b3e', marginBottom:12 }}>
                    {file.name.replace(/\.(pdf|pptx?|docx?)$/i, '')}
                  </h1>
                  {file.folder_name && (
                    <div style={{ display:'inline-block', padding:'3px 12px', background:'#eff6ff', borderRadius:20, fontSize:11, color:'#1e40af', fontFamily:'sans-serif' }}>
                      {file.folder_name}
                    </div>
                  )}
                </div>
                {file.description && (
                  <div style={{ background:'#f8f9ff', borderRadius:10, padding:'16px 20px', marginBottom:24, border:'1px solid #e8edf8', fontFamily:'sans-serif', fontSize:13, lineHeight:1.8, color:'#4a5568' }}>
                    {file.description}
                  </div>
                )}
                <p style={{ lineHeight:2, color:'#374151', marginBottom:20, fontSize:14, fontFamily:'sans-serif' }}>
                  This {file.file_type} document is available for secure in-browser viewing. 
                  To download and keep a personal copy, unlock it with {file.download_price} units — 
                  it will be watermarked with your account details.
                </p>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
                  {[1,2,3,4].map(n => (
                    <div key={n} style={{ background:'#f0f4ff', borderRadius:8, padding:14, border:'1px solid #dce6f8' }}>
                      <div style={{ fontFamily:'sans-serif', fontSize:10, fontWeight:700, color:'#3b82f6', marginBottom:8 }}>SECTION {n}</div>
                      <div style={{ height:7, background:'#dce6f8', borderRadius:4, marginBottom:6 }}/>
                      <div style={{ height:7, background:'#dce6f8', borderRadius:4, width:'70%', marginBottom:6 }}/>
                      <div style={{ height:7, background:'#dce6f8', borderRadius:4, width:'85%' }}/>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop:28, borderTop:'1px solid #e8edf8', paddingTop:14, display:'flex', justifyContent:'space-between', fontFamily:'sans-serif', fontSize:10, color:'#aaa' }}>
                  <span>© AcadVault · For authorized viewing only</span>
                  <span>Page {page} of {totalPages}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <PaymentModal
        open={payOpen}
        file={file}
        onClose={() => setPayOpen(false)}
        onSuccess={() => {
          setOwned(true);
          setFile(prev => prev ? { ...prev, owned: true } : prev);
          setPayOpen(false);
          setTimeout(() => download(file.id, file.name), 600);
        }}
      />
    </div>
  );
}
