// frontend/src/pages/HomePage.js
import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useFolderContents, useWallet, useDownload } from '../hooks';
import { useAuth } from '../context/AuthContext';
import { FileCard, FolderCard } from '../components/files/FileCard';
import PaymentModal from '../components/payments/PaymentModal';
import { Button, Ico, Spinner, Skeleton, Badge } from '../components/ui';
import { foldersAPI, filesAPI } from '../api/client';
import toast from 'react-hot-toast';

export default function HomePage() {
  return <FolderBrowser />;
}

export function FolderBrowser({ folderId: propFolderId }) {
  const params    = useParams();
  const folderId  = propFolderId ?? params.folderId ?? null;
  const navigate  = useNavigate();
  const { user, isAdmin } = useAuth();
  const { balance } = useWallet();
  const { download, downloading } = useDownload();

  const { folder, subfolders, files, breadcrumbs, loading, error, refetch } = useFolderContents(folderId);

  const [viewMode,      setViewMode]      = useState('grid');
  const [payFile,       setPayFile]       = useState(null);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [creating,      setCreating]      = useState(false);
  const [purchasedIds,  setPurchasedIds]  = useState(new Set());

  // Track locally which files were just purchased
  const isOwned = (file) => purchasedIds.has(file.id) || file.owned;

  const handleDownload = (file) => {
    if (!user) { navigate('/login'); return; }
    if (isOwned(file)) {
      download(file.id, file.name);
    } else {
      setPayFile(file);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    setCreating(true);
    try {
      await foldersAPI.create({ name: newFolderName.trim(), parent_id: folderId || null });
      toast.success(`Folder "${newFolderName}" created`);
      setNewFolderName('');
      setShowNewFolder(false);
      refetch();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to create folder');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteFolder = async (id, name) => {
    if (!window.confirm(`Delete folder "${name}"? This will also delete all contents.`)) return;
    try {
      await foldersAPI.delete(id);
      toast.success('Folder deleted');
      refetch();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to delete folder');
    }
  };

  const handleDeleteFile = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await filesAPI.delete(id);
      toast.success('File deleted');
      refetch();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to delete file');
    }
  };

  if (error) return (
    <div style={{ padding: 40, textAlign: 'center', color: 'var(--danger)' }}>
      <Ico name="shield" size={36} style={{ marginBottom: 12 }} />
      <div>{error}</div>
      <Button style={{ marginTop: 16 }} onClick={refetch}>Retry</Button>
    </div>
  );

  const isEmpty = !loading && subfolders.length === 0 && files.length === 0;

  return (
    <div style={{ padding: '24px 28px', maxWidth: 1400 }}>

      {/* Hero banner (root only) */}
      {!folderId && (
        <div className="fade-in" style={{
          background: 'linear-gradient(135deg, #0f2460 0%, #1a3a8f 50%, #1e4ed8 100%)',
          borderRadius: 'var(--radius-xl)', padding: '32px 36px', marginBottom: 28,
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: -60, right: -60, width: 240, height: 240, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
          <div style={{ position: 'absolute', bottom: -40, right: 80, width: 140, height: 140, borderRadius: '50%', background: 'rgba(59,130,246,0.15)' }} />
          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: 10, color: 'rgba(147,197,253,0.85)', fontWeight: 700, letterSpacing: 2.5, marginBottom: 10 }}>ACADEMIC RESOURCE LIBRARY</div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, color: '#fff', fontWeight: 400, marginBottom: 10, lineHeight: 1.2 }}>
              Your knowledge,<br />organized.
            </h1>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', maxWidth: 440, lineHeight: 1.7 }}>
              Browse thousands of academic resources. <strong style={{ color: '#93c5fd' }}>Read for free</strong> in your browser — download with units.
            </p>
            <div style={{ display: 'flex', gap: 12, marginTop: 20, flexWrap: 'wrap' }}>
              {[
                { label: subfolders.length, sub: 'Programs' },
                { label: user ? Math.floor(balance || 0) : '—', sub: 'Your Units' },
              ].map(s => (
                <div key={s.sub} style={{
                  background: 'rgba(255,255,255,0.1)', borderRadius: 12,
                  padding: '12px 20px', backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255,255,255,0.15)',
                }}>
                  <div style={{ fontSize: 26, fontWeight: 700, color: '#fff', lineHeight: 1 }}>{s.label}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>{s.sub}</div>
                </div>
              ))}
              {!user && (
                <button onClick={() => navigate('/login')} style={{
                  alignSelf: 'center', padding: '10px 22px', borderRadius: 10,
                  background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.3)',
                  color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer',
                  backdropFilter: 'blur(10px)', fontFamily: 'var(--font-sans)',
                }}>Sign in to unlock downloads →</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Breadcrumbs + toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        <button onClick={() => navigate('/')} style={{
          display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none',
          color: 'var(--accent)', fontSize: 13, fontWeight: 500, cursor: 'pointer',
          padding: '4px 8px', borderRadius: 6, fontFamily: 'var(--font-sans)',
        }}>
          <Ico name="home" size={14} /> Home
        </button>

        {breadcrumbs.map((crumb, i) => (
          <React.Fragment key={crumb.id}>
            <Ico name="chevRight" size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
            <button onClick={() => navigate(`/folder/${crumb.id}`)} style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: i === breadcrumbs.length - 1 ? 'var(--text-primary)' : 'var(--accent)',
              fontWeight: i === breadcrumbs.length - 1 ? 600 : 400,
              fontSize: 13, padding: '4px 8px', borderRadius: 6,
              fontFamily: 'var(--font-sans)',
            }}>
              {crumb.name}
            </button>
          </React.Fragment>
        ))}

        {/* Right toolbar */}
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
          {isAdmin && folderId && (
            <>
              {!showNewFolder ? (
                <Button size="sm" variant="ghost" icon={<Ico name="plus" size={13} />}
                  onClick={() => setShowNewFolder(true)}>New Folder</Button>
              ) : (
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <input
                    autoFocus value={newFolderName}
                    onChange={e => setNewFolderName(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleCreateFolder()}
                    placeholder="Folder name..."
                    style={{
                      padding: '6px 10px', borderRadius: 7, fontSize: 12,
                      background: 'var(--bg-elevated)', border: '1px solid var(--accent)',
                      color: 'var(--text-primary)', outline: 'none', fontFamily: 'var(--font-sans)',
                    }}
                  />
                  <Button size="sm" variant="primary" loading={creating} onClick={handleCreateFolder}>Create</Button>
                  <Button size="sm" variant="ghost" onClick={() => { setShowNewFolder(false); setNewFolderName(''); }}>✕</Button>
                </div>
              )}
              <Button size="sm" variant="primary" icon={<Ico name="upload" size={13} style={{ color: '#fff' }} />}
                onClick={() => navigate(`/admin/upload?folderId=${folderId}`)}>Upload</Button>
            </>
          )}

          {/* View toggle */}
          <div style={{ display: 'flex', background: 'var(--bg-elevated)', borderRadius: 8, padding: 2, border: '1px solid var(--border)' }}>
            {['grid', 'list'].map(v => (
              <button key={v} onClick={() => setViewMode(v)} style={{
                width: 28, height: 28, borderRadius: 6, border: 'none', cursor: 'pointer',
                background: viewMode === v ? 'var(--accent)' : 'transparent',
                color: viewMode === v ? '#fff' : 'var(--text-muted)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'var(--transition)',
              }}>
                <Ico name={v} size={14} />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading skeletons */}
      {loading && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12 }}>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} style={{ background: 'var(--bg-surface)', borderRadius: 'var(--radius-lg)', padding: 16, border: '1px solid var(--border)' }}>
              <Skeleton height={40} style={{ marginBottom: 10 }} />
              <Skeleton height={14} style={{ marginBottom: 6 }} />
              <Skeleton height={10} width="60%" />
            </div>
          ))}
        </div>
      )}

      {/* Content */}
      {!loading && (
        <>
          {/* Folder section */}
          {subfolders.length > 0 && (
            <section style={{ marginBottom: 28 }}>
              {folderId && <SectionTitle icon="folder" title="Folders" count={subfolders.length} />}
              <div style={{
                display: 'grid',
                gridTemplateColumns: viewMode === 'grid'
                  ? 'repeat(auto-fill,minmax(160px,1fr))'
                  : '1fr',
                gap: viewMode === 'grid' ? 12 : 0,
              }}>
                {viewMode === 'list' && (
                  <div style={{
                    display: 'grid', gridTemplateColumns: '1fr 100px',
                    padding: '8px 16px', fontSize: 11, fontWeight: 700,
                    color: 'var(--text-muted)', letterSpacing: 0.5,
                    background: 'var(--bg-surface)', borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
                    border: '1px solid var(--border)', borderBottom: '1px solid var(--border-subtle)',
                  }}>
                    <span>NAME</span><span>ITEMS</span>
                  </div>
                )}
                {subfolders.map(f => (
                  viewMode === 'grid' ? (
                    <FolderCard key={f.id} folder={f}
                      onClick={() => navigate(`/folder/${f.id}`)}
                      onDelete={isAdmin ? () => handleDeleteFolder(f.id, f.name) : null}
                    />
                  ) : (
                    <ListFolderRow key={f.id} folder={f}
                      onClick={() => navigate(`/folder/${f.id}`)}
                      onDelete={isAdmin ? () => handleDeleteFolder(f.id, f.name) : null}
                    />
                  )
                ))}
              </div>
            </section>
          )}

          {/* Files section */}
          {files.length > 0 && (
            <section>
              {folderId && <SectionTitle icon="file" title="Files" count={files.length} />}
              {viewMode === 'grid' ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12 }}>
                  {files.map(f => (
                    <FileCard key={f.id} file={f} owned={isOwned(f)} view="grid"
                      onDownload={handleDownload} />
                  ))}
                </div>
              ) : (
                <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 90px 70px 130px', padding: '9px 16px', fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', letterSpacing: 0.5, borderBottom: '1px solid var(--border)' }}>
                    <span>NAME</span><span>SIZE</span><span>PAGES</span><span style={{ textAlign: 'right' }}>ACTIONS</span>
                  </div>
                  {files.map(f => (
                    <div key={f.id} style={{ position: 'relative' }}>
                      <FileCard file={f} owned={isOwned(f)} view="list" onDownload={handleDownload} />
                      {isAdmin && (
                        <button onClick={() => handleDeleteFile(f.id, f.name)} style={{
                          position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)',
                          width: 24, height: 24, borderRadius: 5,
                          background: 'var(--danger-bg)', border: 'none', color: 'var(--danger)',
                          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}>
                          <Ico name="trash" size={12} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {isEmpty && (
            <div style={{ textAlign: 'center', padding: '80px 20px', color: 'var(--text-muted)' }}>
              <Ico name="folder" size={48} style={{ marginBottom: 16, opacity: 0.4 }} />
              <div style={{ fontSize: 16, fontWeight: 500, marginBottom: 8 }}>
                {folderId ? 'This folder is empty' : 'No programs yet'}
              </div>
              {isAdmin && <p style={{ fontSize: 13 }}>Use the Admin Panel to add folders and upload files.</p>}
            </div>
          )}
        </>
      )}

      {/* Payment modal */}
      <PaymentModal
        open={!!payFile}
        file={payFile}
        onClose={() => setPayFile(null)}
        onSuccess={() => {
          setPurchasedIds(s => new Set([...s, payFile?.id]));
          setPayFile(null);
          // Trigger download after short delay
          if (payFile) setTimeout(() => download(payFile.id, payFile.name), 500);
        }}
      />
    </div>
  );
}

function SectionTitle({ icon, title, count }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
      <Ico name={icon} size={16} style={{ color: 'var(--text-muted)' }} />
      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>{title}</span>
      <span style={{ fontSize: 11, color: 'var(--text-muted)', background: 'var(--bg-elevated)', padding: '1px 7px', borderRadius: 10 }}>{count}</span>
    </div>
  );
}

function ListFolderRow({ folder, onClick, onDelete }) {
  const count = (folder.subfolder_count || 0) + (folder.file_count || 0);
  return (
    <div onClick={onClick} style={{
      display: 'grid', gridTemplateColumns: '1fr 100px',
      padding: '10px 16px', cursor: 'pointer', alignItems: 'center',
      borderBottom: '1px solid var(--border-subtle)', transition: 'background 0.15s',
      background: 'var(--bg-surface)', position: 'relative',
    }}
    onMouseOver={e=>e.currentTarget.style.background='var(--bg-elevated)'}
    onMouseOut={e =>e.currentTarget.style.background='var(--bg-surface)'}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Ico name="folder" size={16} style={{ color: '#f59e0b' }} />
        <span style={{ fontSize: 13, fontWeight: 500 }}>{folder.name}</span>
      </div>
      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{count} items</span>
      {onDelete && (
        <button onClick={e=>{e.stopPropagation();onDelete();}} style={{
          position:'absolute',right:8,top:'50%',transform:'translateY(-50%)',
          width:22,height:22,borderRadius:5,background:'var(--danger-bg)',
          border:'none',color:'var(--danger)',cursor:'pointer',
          display:'flex',alignItems:'center',justifyContent:'center',
        }}>
          <Ico name="trash" size={12}/>
        </button>
      )}
    </div>
  );
}
