// frontend/src/pages/AuthPage.js
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button, Input, Ico } from '../components/ui';
import { authAPI } from '../api/client';
import toast from 'react-hot-toast';

export default function AuthPage() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const [searchParams] = useSearchParams();
  const { login, register } = useAuth();

  // Support ?mode=register or ?reset=token or ?verify=token
  const resetToken  = searchParams.get('token') && location.pathname.includes('reset') ? searchParams.get('token') : null;
  const verifyToken = searchParams.get('token') && location.pathname.includes('verify') ? searchParams.get('token') : null;

  const from = location.state?.from?.pathname || '/';
  const [mode, setMode] = useState(
    resetToken  ? 'reset'  :
    verifyToken ? 'verify' :
    location.state?.mode || 'login'
  );

  const [form,    setForm]    = useState({ email: '', password: '', full_name: '', newPassword: '' });
  const [errors,  setErrors]  = useState({});
  const [loading, setLoading] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [resetDone,  setResetDone]  = useState(false);
  const [verifyDone, setVerifyDone] = useState(false);

  // Auto-verify email token on load
  useEffect(() => {
    if (verifyToken) {
      authAPI.get(`/api/auth/verify-email?token=${verifyToken}`)
        .then(() => setVerifyDone(true))
        .catch(() => toast.error('Verification link is invalid or expired'));
    }
  }, [verifyToken]);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const e = {};
    if (['login','register','forgot'].includes(mode)) {
      if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) e.email = 'Valid email required';
    }
    if (['login','register'].includes(mode)) {
      if (form.password.length < 8) e.password = 'Minimum 8 characters';
    }
    if (mode === 'register' && form.full_name.trim().length < 2) e.full_name = 'Full name required';
    if (mode === 'reset' && form.newPassword.length < 8) e.newPassword = 'Minimum 8 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
        toast.success('Welcome back!');
        navigate(from, { replace: true });

      } else if (mode === 'register') {
        await register(form.email, form.password, form.full_name);
        toast.success('Account created! Check your email to verify your address 📧');
        navigate(from, { replace: true });

      } else if (mode === 'forgot') {
        await authAPI.post('/api/auth/forgot-password', { email: form.email });
        setForgotSent(true);

      } else if (mode === 'reset') {
        await authAPI.post('/api/auth/reset-password', {
          token: resetToken || searchParams.get('token'),
          newPassword: form.newPassword,
        });
        setResetDone(true);
        toast.success('Password reset! You can now log in.');
        setTimeout(() => navigate('/login'), 2000);
      }
    } catch (err) {
      const msg = err.response?.data?.error || err.response?.data?.errors?.[0]?.msg || 'Something went wrong';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleOAuth = (provider) => {
    toast(`${provider} OAuth — configure your OAuth app credentials in backend/.env`, { icon: 'ℹ️' });
  };

  // ── Verify success screen ────────────────────────────
  if (verifyDone) {
    return (
      <AuthShell>
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>✅</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 8 }}>Email Verified!</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>
            Your email has been verified. You can now sign in.
          </p>
          <Button variant="primary" fullWidth onClick={() => navigate('/login')}>Sign In Now</Button>
        </div>
      </AuthShell>
    );
  }

  // ── Reset success screen ─────────────────────────────
  if (resetDone) {
    return (
      <AuthShell>
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>🔐</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 8 }}>Password Reset!</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Redirecting you to login...</p>
        </div>
      </AuthShell>
    );
  }

  // ── Forgot-password sent screen ──────────────────────
  if (forgotSent) {
    return (
      <AuthShell>
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>📧</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 8 }}>Check your email</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>
            If <strong>{form.email}</strong> is registered, we've sent a reset link. Check your inbox and spam folder.
          </p>
          <Button variant="ghost" fullWidth onClick={() => { setForgotSent(false); setMode('login'); }}>
            Back to Sign In
          </Button>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell>
      {/* Logo */}
      <div style={{ textAlign: 'center', marginBottom: 28 }}>
        <div style={{
          width: 54, height: 54, borderRadius: 16, margin: '0 auto 14px',
          background: 'linear-gradient(135deg,var(--accent-dark),var(--accent))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(59,130,246,0.35)',
        }}>
          <Ico name="shield" size={26} style={{ color: '#fff' }} />
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 26, marginBottom: 6 }}>
          {mode === 'login'   ? 'Welcome back'     :
           mode === 'register'? 'Create account'   :
           mode === 'forgot'  ? 'Forgot password'  :
           mode === 'reset'   ? 'Set new password' : 'AcadVault'}
        </h1>
        <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          {mode === 'login'    ? 'Sign in to your AcadVault account'       :
           mode === 'register' ? 'Join thousands of students on AcadVault' :
           mode === 'forgot'   ? "Enter your email and we'll send a reset link" :
                                 'Choose a new secure password'}
        </p>
      </div>

      {/* OAuth (login/register only) */}
      {(mode === 'login' || mode === 'register') && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 20 }}>
            {[{id:'google',label:'Google',emoji:'🔵'},{id:'facebook',label:'Facebook',emoji:'📘'},{id:'apple',label:'Apple',emoji:'⬛'}].map(p => (
              <button key={p.id} onClick={() => handleOAuth(p.id)} style={{
                padding: '9px 4px', borderRadius: 9,
                background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                cursor: 'pointer', fontFamily: 'var(--font-sans)', color: 'var(--text-primary)',
                transition: 'var(--transition)',
              }}
              onMouseOver={e=>e.currentTarget.style.borderColor='var(--accent)'}
              onMouseOut={e =>e.currentTarget.style.borderColor='var(--border)'}>
                <div style={{ fontSize: 18 }}>{p.emoji}</div>
                <div style={{ fontSize: 10, marginTop: 3, fontWeight: 500 }}>{p.label}</div>
              </button>
            ))}
          </div>
          <div style={{ position: 'relative', textAlign: 'center', marginBottom: 20 }}>
            <div style={{ height: 1, background: 'var(--border)' }} />
            <span style={{ position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)', background: 'var(--bg-surface)', padding: '0 12px', fontSize: 11, color: 'var(--text-muted)' }}>
              or use email
            </span>
          </div>
        </>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {mode === 'register' && (
          <Input label="Full Name" value={form.full_name} onChange={set('full_name')}
            placeholder="Alex Mwangi" error={errors.full_name}
            icon={<Ico name="user" size={15} />} />
        )}

        {(mode === 'login' || mode === 'register' || mode === 'forgot') && (
          <Input label="Email Address" type="email" value={form.email} onChange={set('email')}
            placeholder="you@university.ac" error={errors.email}
            icon={<Ico name="search" size={15} />} />
        )}

        {(mode === 'login' || mode === 'register') && (
          <div>
            <Input label="Password" type="password" value={form.password} onChange={set('password')}
              placeholder={mode === 'login' ? '••••••••' : 'At least 8 characters'} error={errors.password}
              icon={<Ico name="lock" size={15} />} />
            {mode === 'login' && (
              <div style={{ textAlign: 'right', marginTop: 5 }}>
                <span onClick={() => setMode('forgot')}
                  style={{ fontSize: 12, color: 'var(--accent)', cursor: 'pointer', fontWeight: 500 }}>
                  Forgot password?
                </span>
              </div>
            )}
          </div>
        )}

        {mode === 'reset' && (
          <Input label="New Password" type="password" value={form.newPassword} onChange={set('newPassword')}
            placeholder="At least 8 characters" error={errors.newPassword}
            icon={<Ico name="lock" size={15} />} />
        )}

        <Button type="submit" variant="primary" fullWidth size="lg" loading={loading} style={{ marginTop: 4 }}>
          {mode === 'login'    ? 'Sign In'             :
           mode === 'register' ? 'Create Account'      :
           mode === 'forgot'   ? 'Send Reset Link'     :
                                 'Set New Password'}
        </Button>
      </form>

      {/* Back / switch mode */}
      {(mode === 'forgot' || mode === 'reset') && (
        <button onClick={() => setMode('login')} style={{
          width: '100%', marginTop: 14, padding: '8px', background: 'none', border: 'none',
          color: 'var(--text-muted)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-sans)',
        }}>← Back to Sign In</button>
      )}

      {(mode === 'login' || mode === 'register') && (
        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: 'var(--text-muted)' }}>
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <span onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
            style={{ color: 'var(--accent)', fontWeight: 600, cursor: 'pointer' }}>
            {mode === 'login' ? 'Sign up free' : 'Sign in'}
          </span>
        </p>
      )}

      {/* Demo credentials */}
      {mode === 'login' && (
        <div style={{
          marginTop: 20, padding: '12px 14px',
          background: 'var(--accent-light)', border: '1px solid var(--border)',
          borderRadius: 'var(--radius-md)',
        }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8 }}>DEMO ACCOUNTS — CLICK TO FILL</div>
          {[{label:'Admin',e:'admin@acadvault.com',p:'Admin@123'},{label:'Student',e:'student@demo.com',p:'Student@123'}].map(a => (
            <div key={a.label} onClick={() => setForm(f => ({ ...f, email: a.e, password: a.p }))}
              style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', cursor: 'pointer', fontSize: 12 }}>
              <span style={{ color: 'var(--accent)', fontWeight: 600 }}>{a.label}</span>
              <span style={{ color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: 11 }}>{a.e}</span>
            </div>
          ))}
        </div>
      )}

      {/* Security note */}
      <div style={{
        marginTop: 16, padding: '9px 12px',
        background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)',
        display: 'flex', gap: 8, alignItems: 'center',
      }}>
        <Ico name="shield" size={13} style={{ color: 'var(--accent)', flexShrink: 0 }} />
        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
          Protected by 256-bit encryption. Your data is never shared.
        </span>
      </div>
    </AuthShell>
  );
}

// Wrapper so all auth modes share the same shell
function AuthShell({ children }) {
  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center',
      justifyContent: 'center', background: 'var(--bg-base)', padding: 16,
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'fixed', top: '-20%', right: '-10%', width: '50vw', height: '70vh',
        background: 'radial-gradient(circle, rgba(59,130,246,0.06) 0%, transparent 70%)',
        pointerEvents: 'none', borderRadius: '50%',
      }} />
      <div className="slide-up auth-card" style={{
        background: 'var(--bg-surface)', border: '1px solid var(--border)',
        borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)',
        width: '100%', maxWidth: 420, padding: '40px 36px', position: 'relative',
      }}>
        {children}
      </div>
    </div>
  );
}
