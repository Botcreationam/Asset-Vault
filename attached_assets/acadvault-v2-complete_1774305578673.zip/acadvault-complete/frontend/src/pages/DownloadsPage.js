// frontend/src/pages/DownloadsPage.js
import React from 'react';
import { usePurchasedFiles, useDownload } from '../hooks';
import { FileCard } from '../components/files/FileCard';
import { Ico, Spinner } from '../components/ui';

export default function DownloadsPage() {
  const { files, loading } = usePurchasedFiles();
  const { download, downloading } = useDownload();

  return (
    <div style={{ padding: '28px' }}>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, marginBottom: 6 }}>My Downloads</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 24 }}>
        {files.length} resource{files.length !== 1 ? 's' : ''} unlocked
      </p>
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 60 }}><Spinner size={32} /></div>
      ) : files.length === 0 ? (
        <div style={{ textAlign: 'center', paddingTop: 80, color: 'var(--text-muted)' }}>
          <Ico name="star" size={48} style={{ opacity: 0.3, display: 'block', margin: '0 auto 12px' }} />
          <div style={{ fontSize: 15, fontWeight: 500 }}>No downloads yet</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>Unlock resources to see them here</div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12 }}>
          {files.map(f => (
            <FileCard key={f.id} file={f} owned
              onDownload={() => download(f.id, f.name)} />
          ))}
        </div>
      )}
    </div>
  );
}
