// frontend/src/pages/RecentPage.js
import React, { useState } from 'react';
import { useRecentFiles, useDownload } from '../hooks';
import { FileCard } from '../components/files/FileCard';
import PaymentModal from '../components/payments/PaymentModal';
import { Ico, Spinner } from '../components/ui';

export default function RecentPage() {
  const { files, loading } = useRecentFiles();
  const { download } = useDownload();
  const [payFile, setPayFile] = useState(null);
  const [purchased, setPurchased] = useState(new Set());

  const handleDownload = (file) => {
    if (file.owned || purchased.has(file.id)) download(file.id, file.name);
    else setPayFile(file);
  };

  return (
    <div style={{ padding: '28px' }}>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, marginBottom: 6 }}>Recently Viewed</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 24 }}>Files you've opened recently</p>
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 60 }}><Spinner size={32} /></div>
      ) : files.length === 0 ? (
        <div style={{ textAlign: 'center', paddingTop: 80, color: 'var(--text-muted)' }}>
          <Ico name="history" size={48} style={{ opacity: 0.3, marginBottom: 12, display: 'block', margin: '0 auto 12px' }} />
          <div style={{ fontSize: 15, fontWeight: 500 }}>No recently viewed files</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>Browse the library to get started</div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12 }}>
          {files.map(f => (
            <FileCard key={f.id} file={f} owned={f.owned || purchased.has(f.id)}
              onDownload={handleDownload} />
          ))}
        </div>
      )}
      <PaymentModal open={!!payFile} file={payFile} onClose={() => setPayFile(null)}
        onSuccess={() => { setPurchased(s => new Set([...s, payFile?.id])); setPayFile(null); }} />
    </div>
  );
}
