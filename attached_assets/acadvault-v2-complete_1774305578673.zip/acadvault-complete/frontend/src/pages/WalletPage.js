// frontend/src/pages/WalletPage.js
import React, { useState } from 'react';
import { useWallet } from '../hooks';
import { useAuth } from '../context/AuthContext';
import { Button, Modal, Input, Ico, Spinner, Card, Badge } from '../components/ui';
import toast from 'react-hot-toast';

const TOPUP_METHODS = [
  { id:'mtn',        label:'MTN Mobile Money', emoji:'📱', color:'#f59e0b' },
  { id:'airtel',     label:'Airtel Money',      emoji:'📲', color:'#ef4444' },
  { id:'mastercard', label:'Mastercard/Visa',   emoji:'💳', color:'#3b82f6' },
];
const QUICK_AMOUNTS = [10, 20, 50, 100];
const PAGE_SIZE = 15;

export default function WalletPage() {
  const { refreshUser } = useAuth();
  const { balance, transactions, loading, topup, refetch } = useWallet();
  const [showTopup, setShowTopup] = useState(false);
  const [amount,    setAmount]    = useState('');
  const [method,    setMethod]    = useState('mtn');
  const [phone,     setPhone]     = useState('');
  const [paying,    setPaying]    = useState(false);
  const [page,      setPage]      = useState(1);

  // FIX #13: Pagination for transactions
  const totalPages = Math.ceil((transactions?.length || 0) / PAGE_SIZE);
  const paged = (transactions || []).slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);

  // FIX #15: Topup now auto-credits in dev mode
  const handleTopup = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt < 1) { toast.error('Enter a valid amount'); return; }
    setPaying(true);
    try {
      const data = await topup(amt, method, phone);
      if (data.autoCredit) {
        toast.success(`✅ ${amt} units added to your wallet!`);
      } else {
        toast.success(data.message || 'Top-up initiated!');
      }
      setShowTopup(false); setAmount(''); setPhone('');
      await refetch();
      await refreshUser(); // Update wallet balance in topbar
    } catch (e) {
      toast.error(e.response?.data?.error || 'Top-up failed');
    } finally {
      setPaying(false);
    }
  };

  // Safe date format
  const fmtDate = (d) => {
    if (!d) return '—';
    try { const p=new Date(d); if(isNaN(p.getTime())) return '—'; return p.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); }
    catch { return '—'; }
  };

  const totalSpent   = (transactions||[]).filter(t=>t.type==='debit' ).reduce((s,t)=>s+parseFloat(t.amount),0);
  const totalCredited = (transactions||[]).filter(t=>t.type==='credit').reduce((s,t)=>s+parseFloat(t.amount),0);

  return (
    <div style={{ padding:'28px', maxWidth:900 }}>
      <h1 style={{ fontFamily:'var(--font-display)', fontSize:28, marginBottom:8 }}>Wallet</h1>
      <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:28 }}>Manage your AcadVault units</p>

      {/* Stats grid */}
      <div className="wallet-stats" style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:16, marginBottom:32 }}>
        {/* Balance card */}
        <Card style={{ padding:'24px', background:'linear-gradient(135deg,var(--accent-dark),var(--accent))', border:'none' }}>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.65)', fontWeight:700, letterSpacing:1.5, marginBottom:8 }}>BALANCE</div>
          <div style={{ fontSize:44, fontWeight:700, color:'#fff', lineHeight:1 }}>
            {loading ? '…' : Math.floor(balance)}
          </div>
          <div style={{ fontSize:14, color:'rgba(255,255,255,0.7)', marginTop:4 }}>units available</div>
          <Button size="sm" onClick={()=>setShowTopup(true)}
            style={{ marginTop:16, background:'rgba(255,255,255,0.15)', border:'1px solid rgba(255,255,255,0.25)', color:'#fff' }}
            icon={<Ico name="plus" size={13} style={{color:'#fff'}}/>}>Top Up</Button>
        </Card>

        <Card style={{ padding:'24px' }}>
          <div style={{ fontSize:10, color:'var(--text-muted)', fontWeight:700, letterSpacing:1.2, marginBottom:8 }}>TOTAL SPENT</div>
          <div style={{ fontSize:32, fontWeight:700, color:'var(--danger)' }}>{totalSpent.toFixed(0)}</div>
          <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>units on downloads</div>
        </Card>

        <Card style={{ padding:'24px' }}>
          <div style={{ fontSize:10, color:'var(--text-muted)', fontWeight:700, letterSpacing:1.2, marginBottom:8 }}>TOTAL CREDITED</div>
          <div style={{ fontSize:32, fontWeight:700, color:'var(--success)' }}>{totalCredited.toFixed(0)}</div>
          <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>units deposited</div>
        </Card>
      </div>

      {/* Transaction history */}
      <Card>
        <div style={{ padding:'14px 18px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <h3 style={{ fontSize:15, fontWeight:600 }}>Transaction History</h3>
          <Button size="sm" variant="ghost" onClick={refetch} icon={<Ico name="history" size={13}/>}>Refresh</Button>
        </div>

        {loading ? (
          <div style={{ padding:40, display:'flex', justifyContent:'center' }}><Spinner/></div>
        ) : paged.length===0 ? (
          <div style={{ padding:'40px', textAlign:'center', color:'var(--text-muted)', fontSize:13 }}>
            No transactions yet. Top up to get started!
          </div>
        ) : (
          paged.map(tx => (
            <div key={tx.id} style={{ display:'flex', alignItems:'center', gap:14, padding:'12px 20px', borderBottom:'1px solid var(--border-subtle)' }}>
              <div style={{
                width:36, height:36, borderRadius:'50%', flexShrink:0,
                background:tx.type==='credit'?'rgba(5,150,105,0.12)':'rgba(220,38,38,0.1)',
                display:'flex', alignItems:'center', justifyContent:'center',
              }}>
                <Ico name={tx.type==='credit'?'plus':'download'} size={16}
                  style={{color:tx.type==='credit'?'var(--success)':'var(--danger)'}}/>
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {tx.description || (tx.type==='credit'?'Top-up':'Purchase')}
                </div>
                <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>{fmtDate(tx.created_at)}</div>
              </div>
              <div style={{ textAlign:'right', flexShrink:0 }}>
                <div style={{ fontSize:15, fontWeight:700, color:tx.type==='credit'?'var(--success)':'var(--danger)' }}>
                  {tx.type==='credit'?'+':'−'}{parseFloat(tx.amount).toFixed(0)} units
                </div>
                <div style={{ fontSize:10, color:'var(--text-muted)' }}>
                  Balance: {parseFloat(tx.balance_after||0).toFixed(0)}
                </div>
              </div>
            </div>
          ))
        )}
      </Card>

      {/* FIX #13: Pagination */}
      {totalPages > 1 && (
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center', gap:8, marginTop:16 }}>
          <Button size="sm" variant="ghost" disabled={page===1} onClick={()=>setPage(p=>p-1)}>← Prev</Button>
          <span style={{ fontSize:13, color:'var(--text-muted)' }}>Page {page} of {totalPages}</span>
          <Button size="sm" variant="ghost" disabled={page===totalPages} onClick={()=>setPage(p=>p+1)}>Next →</Button>
        </div>
      )}

      {/* Top-up Modal */}
      <Modal open={showTopup} onClose={()=>setShowTopup(false)} title="Top Up Wallet">
        <div style={{ display:'flex', flexDirection:'column', gap:14, marginTop:14 }}>
          <div style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)' }}>QUICK SELECT</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
            {QUICK_AMOUNTS.map(a => (
              <button key={a} onClick={()=>setAmount(String(a))} style={{
                padding:'10px', borderRadius:9,
                border:`1.5px solid ${amount===String(a)?'var(--accent)':'var(--border)'}`,
                background:amount===String(a)?'var(--accent-light)':'var(--bg-elevated)',
                color:amount===String(a)?'var(--accent)':'var(--text-primary)',
                fontWeight:700, fontSize:15, cursor:'pointer', fontFamily:'inherit', transition:'var(--transition)',
              }}>{a}</button>
            ))}
          </div>

          <Input label="Custom Amount (units)" type="number" value={amount}
            onChange={e=>setAmount(e.target.value)} placeholder="Enter amount"
            icon={<Ico name="wallet" size={15}/>}/>

          <div style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)' }}>PAYMENT METHOD</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {TOPUP_METHODS.map(m => (
              <div key={m.id} onClick={()=>setMethod(m.id)} style={{
                display:'flex', alignItems:'center', gap:10, padding:'11px 14px',
                borderRadius:9, cursor:'pointer', transition:'var(--transition)',
                background:method===m.id?'var(--accent-light)':'var(--bg-elevated)',
                border:`1.5px solid ${method===m.id?'var(--accent)':'var(--border)'}`,
              }}>
                <span style={{ fontSize:20 }}>{m.emoji}</span>
                <span style={{ fontSize:13, fontWeight:500, flex:1 }}>{m.label}</span>
                <div style={{
                  width:16, height:16, borderRadius:'50%',
                  border:`2px solid ${method===m.id?'var(--accent)':'var(--border)'}`,
                  background:method===m.id?'var(--accent)':'transparent',
                }}/>
              </div>
            ))}
          </div>

          {(method==='mtn'||method==='airtel') && (
            <Input label="Phone Number" value={phone} onChange={e=>setPhone(e.target.value)}
              placeholder="+260 9xx xxx xxx" icon={<Ico name="user" size={15}/>}/>
          )}

          {process.env.NODE_ENV !== 'production' && (
            <div style={{ padding:'8px 12px', background:'rgba(245,158,11,0.08)', border:'1px solid rgba(245,158,11,0.2)', borderRadius:8, fontSize:11, color:'#f59e0b' }}>
              ℹ️ Development mode — wallet will be credited instantly without a real payment
            </div>
          )}

          <Button variant="primary" fullWidth size="lg" loading={paying} onClick={handleTopup}
            icon={<Ico name="wallet" size={15} style={{color:'#fff'}}/>}>
            Top Up {amount?`${amount} Units`:''}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
