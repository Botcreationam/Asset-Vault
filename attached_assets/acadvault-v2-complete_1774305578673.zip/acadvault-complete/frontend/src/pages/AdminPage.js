// frontend/src/pages/AdminPage.js
import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useAdminStats, useAdminUsers, useAdminActivity, useFolderTree, useUploadFile } from '../hooks';
import { adminAPI, foldersAPI } from '../api/client';
import { Card, Button, Input, Ico, Spinner, Badge } from '../components/ui';
import toast from 'react-hot-toast';

const TABS = [
  { id:'overview', icon:'chart',   label:'Overview'  },
  { id:'upload',   icon:'upload',  label:'Upload'    },
  { id:'folders',  icon:'folder',  label:'Folders'   },
  { id:'users',    icon:'users',   label:'Users'     },
  { id:'activity', icon:'history', label:'Activity'  },
];

export default function AdminPage() {
  const [tab, setTab] = useState('overview');
  return (
    <div style={{ display:'flex', height:'calc(100vh - var(--topbar-h))' }}>
      {/* Admin sidebar */}
      <div className="admin-sidebar" style={{ width:200, borderRight:'1px solid var(--border)', background:'var(--bg-surface)', padding:'16px 10px', flexShrink:0 }}>
        <div style={{ fontSize:10, fontWeight:700, color:'#f59e0b', letterSpacing:1.5, padding:'0 8px 12px' }}>ADMIN PANEL</div>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            width:'100%', display:'flex', alignItems:'center', gap:9,
            padding:'9px 12px', borderRadius:8, border:'none',
            background: tab===t.id ? 'rgba(245,158,11,0.12)' : 'transparent',
            color: tab===t.id ? '#f59e0b' : 'var(--text-secondary)',
            fontWeight: tab===t.id ? 600 : 400, fontSize:13, cursor:'pointer',
            fontFamily:'inherit', transition:'var(--transition)', marginBottom:2,
          }}
          onMouseOver={e=>{ if(tab!==t.id) e.currentTarget.style.background='var(--bg-elevated)'; }}
          onMouseOut={e =>{ if(tab!==t.id) e.currentTarget.style.background='transparent'; }}>
            <Ico name={t.icon} size={16}/> <span className="admin-tab-label">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex:1, overflow:'auto', padding:'28px' }}>
        {tab==='overview' && <OverviewTab />}
        {tab==='upload'   && <UploadTab />}
        {tab==='folders'  && <FoldersTab />}
        {tab==='users'    && <UsersTab />}
        {tab==='activity' && <ActivityTab />}
      </div>
    </div>
  );
}

// ─── OVERVIEW ───────────────────────────────────────────
function OverviewTab() {
  const { stats, topFiles, loading } = useAdminStats();
  if (loading) return <Center><Spinner size={36}/></Center>;
  if (!stats)  return <div style={{color:'var(--text-muted)'}}>Could not load stats</div>;
  const cards = [
    {l:'Students',  v:stats.totalStudents,  icon:'users',    c:'#3b82f6'},
    {l:'Resources', v:stats.totalFiles,     icon:'file',     c:'#8b5cf6'},
    {l:'Purchases', v:stats.totalPurchases, icon:'star',     c:'#f59e0b'},
    {l:'Revenue',   v:`${stats.totalRevenue.toFixed(0)}u`, icon:'wallet', c:'#10b981'},
    {l:'Downloads', v:stats.totalDownloads, icon:'download', c:'#ef4444'},
    {l:'Views',     v:stats.totalViews,     icon:'eye',      c:'#6366f1'},
  ];
  return (
    <div>
      <h2 style={{ fontFamily:'var(--font-display)', fontSize:26, marginBottom:24 }}>Platform Overview</h2>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:14, marginBottom:32 }}>
        {cards.map(s => (
          <Card key={s.l} style={{ padding:'18px 20px' }}>
            <div style={{ width:36, height:36, borderRadius:9, background:`${s.c}18`, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:12 }}>
              <Ico name={s.icon} size={18} style={{ color:s.c }}/>
            </div>
            <div style={{ fontSize:28, fontWeight:700, lineHeight:1, marginBottom:4 }}>{s.v}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{s.l}</div>
          </Card>
        ))}
      </div>
      <Card>
        <div style={{ padding:'14px 18px', borderBottom:'1px solid var(--border)' }}>
          <h3 style={{ fontSize:15, fontWeight:600 }}>Top Downloaded Files</h3>
        </div>
        {topFiles.length===0 ? <Empty text="No downloads yet"/> : topFiles.slice(0,10).map((f,i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 18px', borderBottom:'1px solid var(--border-subtle)' }}>
            <span style={{ fontSize:13, fontWeight:700, color:'var(--text-muted)', width:20 }}>#{i+1}</span>
            <Ico name="file" size={15} style={{ color:'var(--accent)' }}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{f.name}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)' }}>{f.folder}</div>
            </div>
            <div style={{ textAlign:'right', flexShrink:0 }}>
              <div style={{ fontSize:13, fontWeight:600 }}>{f.download_count} ↓</div>
              <div style={{ fontSize:11, color:'var(--text-muted)' }}>{f.view_count} views</div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ─── UPLOAD ─────────────────────────────────────────────
function UploadTab() {
  const { tree } = useFolderTree();
  const [selectedFolder, setSelectedFolder] = useState('');
  const [fileName,    setFileName]    = useState('');
  const [description, setDescription] = useState('');
  const [price,       setPrice]       = useState('5');
  const [published,   setPublished]   = useState(true);
  const [fileObj,     setFileObj]     = useState(null);

  const { uploadFile, loading, progress } = useUploadFile(() => {
    setFileObj(null); setFileName(''); setDescription('');
  });

  const onDrop = useCallback((accepted) => {
    if (accepted[0]) {
      setFileObj(accepted[0]);
      if (!fileName) setFileName(accepted[0].name.replace(/\.[^.]+$/, ''));
    }
  }, [fileName]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, multiple: false,
    accept: {
      'application/pdf':['.pdf'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation':['.pptx'],
      'application/vnd.ms-powerpoint':['.ppt'],
      'image/*':['.jpg','.jpeg','.png','.webp'],
    },
  });

  // FIX #13: flatten tree for select with indentation
  const flatFolders = [];
  const flatten = (nodes, depth=0) => nodes.forEach(n => {
    flatFolders.push({ id:n.id, label:'  '.repeat(depth) + n.name });
    if (n.children) flatten(n.children, depth+1);
  });
  flatten(tree);

  return (
    <div style={{ maxWidth:640 }}>
      <h2 style={{ fontFamily:'var(--font-display)', fontSize:26, marginBottom:8 }}>Upload Resource</h2>
      <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:24 }}>Add PDFs, slides, and notes to the library</p>

      <div {...getRootProps()} style={{
        border:`2px dashed ${isDragActive?'var(--accent)':'var(--border)'}`,
        borderRadius:'var(--radius-lg)', padding:'36px 20px', textAlign:'center',
        cursor:'pointer', marginBottom:24, transition:'var(--transition)',
        background:isDragActive?'var(--accent-light)':'var(--bg-elevated)',
      }}>
        <input {...getInputProps()}/>
        {fileObj ? (
          <div>
            <Ico name="check" size={36} style={{ color:'var(--success)', display:'block', margin:'0 auto 8px' }}/>
            <div style={{ fontSize:14, fontWeight:600 }}>{fileObj.name}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:4 }}>{(fileObj.size/1024/1024).toFixed(2)} MB</div>
            <button onClick={e=>{ e.stopPropagation(); setFileObj(null); }} style={{ marginTop:8, background:'none', border:'none', color:'var(--danger)', fontSize:12, cursor:'pointer', fontFamily:'inherit' }}>✕ Remove</button>
          </div>
        ) : (
          <div>
            <Ico name="upload" size={36} style={{ color:'var(--text-muted)', display:'block', margin:'0 auto 12px' }}/>
            <div style={{ fontSize:14, fontWeight:500, marginBottom:4 }}>{isDragActive?'Drop it here!':'Drag & drop file here'}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>PDF, PPTX, Images — max 100 MB</div>
          </div>
        )}
      </div>

      {loading && (
        <div style={{ marginBottom:20 }}>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:6 }}>
            <span>Uploading...</span><span>{progress}%</span>
          </div>
          <div style={{ height:6, background:'var(--bg-elevated)', borderRadius:3, overflow:'hidden' }}>
            <div style={{ height:'100%', width:`${progress}%`, background:'var(--accent)', transition:'width 0.3s', borderRadius:3 }}/>
          </div>
        </div>
      )}

      <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
        <div>
          <label style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)', display:'block', marginBottom:5 }}>Target Folder *</label>
          <select value={selectedFolder} onChange={e=>setSelectedFolder(e.target.value)} style={{
            width:'100%', padding:'9px 12px', borderRadius:'var(--radius-md)',
            background:'var(--bg-elevated)', border:'1px solid var(--border)',
            color:'var(--text-primary)', fontSize:13, outline:'none', fontFamily:'inherit',
          }}>
            <option value="">— Select folder —</option>
            {flatFolders.map(f=><option key={f.id} value={f.id}>{f.label}</option>)}
          </select>
        </div>

        <Input label="Resource Name" value={fileName} onChange={e=>setFileName(e.target.value)} placeholder="e.g. Introduction to Python" icon={<Ico name="file" size={15}/>}/>

        <div>
          <label style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)', display:'block', marginBottom:5 }}>Description (optional)</label>
          <textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Brief description..." rows={3} style={{ width:'100%', padding:'9px 12px', borderRadius:'var(--radius-md)', background:'var(--bg-elevated)', border:'1px solid var(--border)', color:'var(--text-primary)', fontSize:13, outline:'none', fontFamily:'inherit', resize:'vertical' }}/>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
          <Input label="Download Price (units)" type="number" value={price} onChange={e=>setPrice(e.target.value)} icon={<Ico name="wallet" size={15}/>}/>
          <div>
            <label style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)', display:'block', marginBottom:5 }}>Visibility</label>
            <div style={{ display:'flex', gap:8 }}>
              {[{v:true,l:'Published'},{v:false,l:'Draft'}].map(o=>(
                <button key={String(o.v)} onClick={()=>setPublished(o.v)} style={{
                  flex:1, padding:'9px', borderRadius:8, cursor:'pointer', fontFamily:'inherit',
                  border:`1.5px solid ${published===o.v?'var(--accent)':'var(--border)'}`,
                  background:published===o.v?'var(--accent-light)':'var(--bg-elevated)',
                  color:published===o.v?'var(--accent)':'var(--text-secondary)',
                  fontWeight:600, fontSize:12, transition:'var(--transition)',
                }}>{o.l}</button>
              ))}
            </div>
          </div>
        </div>

        <Button variant="primary" size="lg" onClick={() => uploadFile(fileObj, { folderId:selectedFolder, name:fileName, description, price:parseFloat(price), published })}
          loading={loading} disabled={!fileObj||!selectedFolder||loading}
          icon={<Ico name="upload" size={15} style={{color:'#fff'}}/>} fullWidth>
          Upload Resource
        </Button>
      </div>
    </div>
  );
}

// ─── FIX #6: FOLDERS TAB with root folder creation ──────
function FoldersTab() {
  const { tree, refetch } = useFolderTree();
  const [showNew,   setShowNew]   = useState(false);
  const [newName,   setNewName]   = useState('');
  const [parentId,  setParentId]  = useState('');
  const [creating,  setCreating]  = useState(false);

  // FIX #10: search
  const [search, setSearch] = useState('');

  const flatFolders = [];
  const flatten = (nodes, depth=0) => nodes.forEach(n => {
    flatFolders.push({ id:n.id, label:'  '.repeat(depth)+n.name, depth, fileCount:n.file_count||0 });
    if (n.children) flatten(n.children, depth+1);
  });
  flatten(tree);

  const filtered = search.trim()
    ? flatFolders.filter(f => f.label.toLowerCase().includes(search.toLowerCase()))
    : flatFolders;

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      await foldersAPI.create({ name: newName.trim(), parent_id: parentId || null });
      toast.success(`Folder "${newName}" created`);
      setNewName(''); setParentId(''); setShowNew(false);
      refetch();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to create folder');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete folder "${name}"? This removes all contents.`)) return;
    try {
      await foldersAPI.delete(id);
      toast.success('Folder deleted');
      refetch();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Delete failed');
    }
  };

  return (
    <div style={{ maxWidth:700 }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:24 }}>
        <h2 style={{ fontFamily:'var(--font-display)', fontSize:26 }}>Folder Management</h2>
        <Button variant="primary" icon={<Ico name="plus" size={14} style={{color:'#fff'}}/>} onClick={()=>setShowNew(true)}>New Folder</Button>
      </div>

      {/* FIX #10: Folder search */}
      <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search folders..." icon={<Ico name="search" size={15}/>} containerStyle={{ marginBottom:16 }}/>

      {/* New folder form */}
      {showNew && (
        <Card style={{ padding:'18px', marginBottom:18 }}>
          <div style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>Create New Folder</div>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            <Input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="Folder name" label="Name" onKeyDown={e=>e.key==='Enter'&&handleCreate()}/>
            <div>
              <label style={{ fontSize:12, fontWeight:600, color:'var(--text-secondary)', display:'block', marginBottom:5 }}>Parent Folder (leave empty for root)</label>
              <select value={parentId} onChange={e=>setParentId(e.target.value)} style={{ width:'100%', padding:'9px 12px', borderRadius:'var(--radius-md)', background:'var(--bg-elevated)', border:'1px solid var(--border)', color:'var(--text-primary)', fontSize:13, outline:'none', fontFamily:'inherit' }}>
                <option value="">— Root level —</option>
                {flatFolders.map(f=><option key={f.id} value={f.id}>{f.label}</option>)}
              </select>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <Button variant="ghost" onClick={()=>{ setShowNew(false); setNewName(''); setParentId(''); }}>Cancel</Button>
              <Button variant="primary" onClick={handleCreate} loading={creating}>Create</Button>
            </div>
          </div>
        </Card>
      )}

      <Card>
        {filtered.length===0 ? <Empty text="No folders found"/> : filtered.map(f => (
          <div key={f.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 16px', borderBottom:'1px solid var(--border-subtle)' }}>
            <Ico name="folder" size={16} style={{ color:'#f59e0b', marginLeft:f.depth*16 }}/>
            <div style={{ flex:1 }}>
              <span style={{ fontSize:13, fontWeight:500 }}>{f.label.trim()}</span>
              <span style={{ fontSize:11, color:'var(--text-muted)', marginLeft:8 }}>{f.fileCount} files</span>
            </div>
            <Button size="sm" variant="danger" icon={<Ico name="trash" size={12}/>} onClick={()=>handleDelete(f.id,f.label.trim())}>Delete</Button>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ─── FIX #9+10+13: USERS TAB with 2FA toggle, search, pagination ──
function UsersTab() {
  const [search, setSearch] = useState('');
  const [page,   setPage]   = useState(1);
  const PAGE_SIZE = 10;
  const { users, loading, refetch } = useAdminUsers(search);

  const safeDate = (d) => {
    if (!d) return '—';
    try { const p=new Date(d); if(isNaN(p.getTime())) return '—'; return p.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); } catch { return '—'; }
  };

  const toggleActive = async (userId, cur) => {
    try { await adminAPI.updateUser(userId, { is_active: !cur }); toast.success(`User ${cur?'deactivated':'activated'}`); refetch(); }
    catch { toast.error('Update failed'); }
  };

  // FIX #13: Client-side pagination
  const totalPages = Math.ceil(users.length / PAGE_SIZE);
  const paged = users.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);

  return (
    <div>
      <h2 style={{ fontFamily:'var(--font-display)', fontSize:26, marginBottom:20 }}>User Management</h2>
      <Input value={search} onChange={e=>{ setSearch(e.target.value); setPage(1); }} placeholder="Search by name or email..." icon={<Ico name="search" size={15}/>} containerStyle={{ marginBottom:16 }}/>

      <Card>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 80px 70px 80px 90px', padding:'9px 16px', fontSize:11, fontWeight:700, color:'var(--text-muted)', letterSpacing:0.5, borderBottom:'1px solid var(--border)' }}>
          <span>USER</span><span>ROLE</span><span>BAL</span><span>JOINED</span><span style={{textAlign:'right'}}>STATUS</span>
        </div>
        {loading ? <Center style={{padding:40}}><Spinner/></Center> : paged.map(u => (
          <div key={u.id} style={{ display:'grid', gridTemplateColumns:'1fr 80px 70px 80px 90px', padding:'11px 16px', borderBottom:'1px solid var(--border-subtle)', alignItems:'center' }}>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.full_name}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.email}</div>
            </div>
            <Badge color={u.role==='admin'?'yellow':'blue'} size="sm">{u.role.toUpperCase()}</Badge>
            <span style={{ fontSize:13 }}>{parseFloat(u.wallet_balance).toFixed(0)}u</span>
            <span style={{ fontSize:11, color:'var(--text-muted)' }}>{safeDate(u.created_at)}</span>
            <div style={{ textAlign:'right' }}>
              <button onClick={()=>toggleActive(u.id,u.is_active)} style={{
                padding:'4px 10px', borderRadius:6, border:'none', cursor:'pointer',
                background:u.is_active?'var(--success-bg)':'var(--danger-bg)',
                color:u.is_active?'var(--success)':'var(--danger)',
                fontSize:11, fontWeight:600, fontFamily:'inherit',
              }}>
                {u.is_active?'Active':'Banned'}
              </button>
            </div>
          </div>
        ))}
        {!loading && users.length===0 && <Empty text="No users found"/>}
      </Card>

      {/* FIX #13: Pagination */}
      {totalPages > 1 && (
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center', gap:8, marginTop:16 }}>
          <Button size="sm" variant="ghost" disabled={page===1} onClick={()=>setPage(p=>p-1)}>← Prev</Button>
          <span style={{ fontSize:13, color:'var(--text-muted)' }}>Page {page} of {totalPages}</span>
          <Button size="sm" variant="ghost" disabled={page===totalPages} onClick={()=>setPage(p=>p+1)}>Next →</Button>
        </div>
      )}
    </div>
  );
}

// ─── ACTIVITY TAB ────────────────────────────────────────
function ActivityTab() {
  const { logs, loading } = useAdminActivity();
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  const safeDate = (d) => {
    if (!d) return '—';
    try { const p=new Date(d); if(isNaN(p.getTime())) return '—'; return p.toLocaleString('en-GB',{dateStyle:'short',timeStyle:'short'}); } catch { return '—'; }
  };

  const actionColor = (a) => ({
    user_login:'blue', user_registered:'green', file_purchased:'yellow', file_uploaded:'blue',
  }[a] || 'gray');

  const paged = logs.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);
  const totalPages = Math.ceil(logs.length / PAGE_SIZE);

  return (
    <div>
      <h2 style={{ fontFamily:'var(--font-display)', fontSize:26, marginBottom:20 }}>Activity Log</h2>
      <Card>
        {loading ? <Center style={{padding:40}}><Spinner/></Center> : (
          <>
            {paged.map(log => (
              <div key={log.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 18px', borderBottom:'1px solid var(--border-subtle)' }}>
                <Badge color={actionColor(log.action)} size="sm">{log.action.replace(/_/g,' ').toUpperCase()}</Badge>
                <div style={{ flex:1, fontSize:13, color:'var(--text-secondary)' }}>{log.full_name || log.email || 'Unknown'}</div>
                <div style={{ fontSize:11, color:'var(--text-muted)', flexShrink:0 }}>{safeDate(log.created_at)}</div>
                <div style={{ fontSize:11, color:'var(--text-muted)', flexShrink:0 }}>{log.ip_address}</div>
              </div>
            ))}
            {logs.length===0 && <Empty text="No activity yet"/>}
          </>
        )}
      </Card>
      {totalPages > 1 && (
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center', gap:8, marginTop:16 }}>
          <Button size="sm" variant="ghost" disabled={page===1} onClick={()=>setPage(p=>p-1)}>← Prev</Button>
          <span style={{ fontSize:13, color:'var(--text-muted)' }}>Page {page} of {totalPages}</span>
          <Button size="sm" variant="ghost" disabled={page===totalPages} onClick={()=>setPage(p=>p+1)}>Next →</Button>
        </div>
      )}
    </div>
  );
}

function Center({children,style={}}) { return <div style={{display:'flex',justifyContent:'center',alignItems:'center',...style}}>{children}</div>; }
function Empty({text}) { return <div style={{padding:'32px',textAlign:'center',color:'var(--text-muted)',fontSize:13}}>{text}</div>; }
