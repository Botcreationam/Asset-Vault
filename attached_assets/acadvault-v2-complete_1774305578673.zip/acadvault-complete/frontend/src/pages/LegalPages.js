// frontend/src/pages/LegalPages.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

function LegalLayout({ title, lastUpdated, children }) {
  const navigate = useNavigate();
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 28px' }}>
      <button onClick={() => navigate(-1)} style={{
        background: 'none', border: 'none', color: 'var(--accent)',
        fontSize: 13, cursor: 'pointer', fontFamily: 'inherit',
        display: 'flex', alignItems: 'center', gap: 6, marginBottom: 28, padding: 0,
      }}>← Back</button>

      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 34, marginBottom: 8 }}>{title}</h1>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 36 }}>Last updated: {lastUpdated}</p>

      <div style={{
        background: 'var(--bg-surface)', border: '1px solid var(--border)',
        borderRadius: 'var(--radius-xl)', padding: '36px 40px',
        fontSize: 14, lineHeight: 1.8, color: 'var(--text-secondary)',
      }}>
        {children}
      </div>
    </div>
  );
}

const H2 = ({ children }) => (
  <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--text-primary)', marginTop: 32, marginBottom: 12 }}>
    {children}
  </h2>
);
const P = ({ children }) => <p style={{ marginBottom: 14 }}>{children}</p>;
const Li = ({ children }) => <li style={{ marginBottom: 6, marginLeft: 20 }}>{children}</li>;

export function TermsPage() {
  return (
    <LegalLayout title="Terms of Service" lastUpdated="January 2025">
      <P>Welcome to AcadVault. By using this platform, you agree to these terms. Please read them carefully.</P>

      <H2>1. Use of the Platform</H2>
      <P>AcadVault is an academic resource platform. You may:</P>
      <ul>
        <Li>Browse and read materials freely in your browser</Li>
        <Li>Purchase download access using wallet units</Li>
        <Li>Share content only as permitted by copyright law</Li>
      </ul>

      <H2>2. Account Responsibilities</H2>
      <P>You are responsible for maintaining the security of your account. Do not share your password or allow others to use your account.</P>

      <H2>3. Content and Copyright</H2>
      <P>All materials on AcadVault are protected by copyright. You may not redistribute, resell, or reproduce content without explicit permission from the content owner.</P>
      <P>Downloads are watermarked with your account information. Sharing downloaded files violates these terms and may result in account suspension.</P>

      <H2>4. Payments and Refunds</H2>
      <P>Wallet units are non-refundable once used to unlock content. Unused units may be refunded at AcadVault's discretion. Contact support within 7 days for refund requests.</P>

      <H2>5. Prohibited Activities</H2>
      <ul>
        <Li>Sharing account credentials with others</Li>
        <Li>Attempting to bypass content protection measures</Li>
        <Li>Uploading copyrighted content without authorization</Li>
        <Li>Using the platform for any illegal purpose</Li>
      </ul>

      <H2>6. Termination</H2>
      <P>AcadVault reserves the right to suspend or terminate accounts that violate these terms without notice.</P>

      <H2>7. Contact</H2>
      <P>For questions about these terms, contact us at legal@acadvault.com</P>
    </LegalLayout>
  );
}

export function PrivacyPage() {
  return (
    <LegalLayout title="Privacy Policy" lastUpdated="January 2025">
      <P>AcadVault is committed to protecting your privacy. This policy explains how we collect, use, and protect your personal information.</P>

      <H2>1. Information We Collect</H2>
      <ul>
        <Li><strong>Account data:</strong> Name, email address, and password (encrypted)</Li>
        <Li><strong>Usage data:</strong> Files viewed, downloaded, and purchased</Li>
        <Li><strong>Payment data:</strong> Transaction records (we do not store card numbers)</Li>
        <Li><strong>Technical data:</strong> IP address, browser type, device information</Li>
      </ul>

      <H2>2. How We Use Your Information</H2>
      <ul>
        <Li>To provide and improve our services</Li>
        <Li>To process payments and prevent fraud</Li>
        <Li>To send important account notifications</Li>
        <Li>To enforce our Terms of Service</Li>
      </ul>

      <H2>3. Data Security</H2>
      <P>We use industry-standard encryption (256-bit TLS) to protect data in transit. Passwords are hashed using bcrypt. We never store plain-text passwords.</P>

      <H2>4. Data Sharing</H2>
      <P>We do not sell your personal information to third parties. We may share data with:</P>
      <ul>
        <Li>Payment processors (MTN, Airtel, Stripe) — only what is necessary for transactions</Li>
        <Li>Law enforcement when legally required</Li>
      </ul>

      <H2>5. Watermarking</H2>
      <P>Downloaded files are watermarked with your name and email. This is to discourage unauthorized sharing and protect content creators.</P>

      <H2>6. Your Rights</H2>
      <ul>
        <Li>Access your personal data</Li>
        <Li>Request correction of inaccurate data</Li>
        <Li>Request deletion of your account</Li>
        <Li>Opt out of non-essential emails</Li>
      </ul>

      <H2>7. Cookies</H2>
      <P>We use localStorage to store authentication tokens. We do not use tracking cookies or third-party advertising cookies.</P>

      <H2>8. Contact</H2>
      <P>For privacy concerns, contact us at privacy@acadvault.com</P>
    </LegalLayout>
  );
}

export function AboutPage() {
  const navigate = useNavigate();
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 28px' }}>
      <button onClick={() => navigate(-1)} style={{
        background: 'none', border: 'none', color: 'var(--accent)',
        fontSize: 13, cursor: 'pointer', fontFamily: 'inherit',
        display: 'flex', alignItems: 'center', gap: 6, marginBottom: 28, padding: 0,
      }}>← Back</button>

      <div style={{
        background: 'linear-gradient(135deg,#0f2460,#1a3a8f,#1e4ed8)',
        borderRadius: 20, padding: '48px 40px', marginBottom: 32, textAlign: 'center',
      }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🎓</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 36, color: '#fff', marginBottom: 12 }}>AcadVault</h1>
        <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.75)', maxWidth: 480, margin: '0 auto' }}>
          A secure academic resource platform built for students across Zambia and beyond.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 32 }}>
        {[
          { icon: '📚', title: 'Free Reading', desc: 'Browse and read all resources directly in your browser at no cost.' },
          { icon: '🔒', title: 'Secure Downloads', desc: 'Pay with wallet units, MTN, or Airtel Money to unlock offline copies.' },
          { icon: '📂', title: 'Organized Library', desc: 'Resources organized by program, year, semester, and course.' },
          { icon: '🇿🇲', title: 'Built for Zambia', desc: 'Supports MTN Mobile Money and Airtel Money for local payments.' },
        ].map(f => (
          <div key={f.title} style={{
            background: 'var(--bg-surface)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-lg)', padding: '20px',
          }}>
            <div style={{ fontSize: 28, marginBottom: 10 }}>{f.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 6 }}>{f.title}</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6 }}>{f.desc}</div>
          </div>
        ))}
      </div>

      <div style={{
        background: 'var(--bg-surface)', border: '1px solid var(--border)',
        borderRadius: 'var(--radius-xl)', padding: '28px', textAlign: 'center',
      }}>
        <div style={{ fontSize: 14, color: 'var(--text-muted)' }}>
          Questions? Contact us at <a href="mailto:hello@acadvault.com" style={{ color: 'var(--accent)' }}>hello@acadvault.com</a>
        </div>
      </div>
    </div>
  );
}
