// frontend/src/hooks/index.js
import { useState, useEffect, useCallback, useRef } from 'react';
import { foldersAPI, filesAPI, paymentsAPI, adminAPI } from '../api/client';
import toast from 'react-hot-toast';

// ─────────────────────────────────────────────────────────
// useFolderContents — fetch a folder's subfolders + files
// ─────────────────────────────────────────────────────────
export function useFolderContents(folderId) {
  const [data,    setData]    = useState({ folder: null, subfolders: [], files: [], breadcrumbs: [] });
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (folderId) {
        const { data: d } = await foldersAPI.getOne(folderId);
        setData(d);
      } else {
        // Root: get top-level folders
        const { data: d } = await foldersAPI.getAll(null);
        setData({ folder: null, subfolders: d.folders, files: [], breadcrumbs: [] });
      }
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load folder');
    } finally {
      setLoading(false);
    }
  }, [folderId]);

  useEffect(() => { fetch(); }, [fetch]);

  return { ...data, loading, error, refetch: fetch };
}

// ─────────────────────────────────────────────────────────
// useFolderTree — full nested tree for sidebar
// ─────────────────────────────────────────────────────────
export function useFolderTree() {
  const [tree,    setTree]    = useState([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await foldersAPI.getTree();
      setTree(data.tree);
    } catch {}
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);
  return { tree, loading, refetch: fetch };
}

// ─────────────────────────────────────────────────────────
// useFile — single file metadata
// ─────────────────────────────────────────────────────────
export function useFile(fileId) {
  const [file,    setFile]    = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    if (!fileId) return;
    setLoading(true);
    filesAPI.getOne(fileId)
      .then(({ data }) => setFile(data.file))
      .catch(e => setError(e.response?.data?.error || 'Failed to load file'))
      .finally(() => setLoading(false));
  }, [fileId]);

  return { file, loading, error, setFile };
}

// ─────────────────────────────────────────────────────────
// useRecentFiles
// ─────────────────────────────────────────────────────────
export function useRecentFiles() {
  const [files,   setFiles]   = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    filesAPI.getRecent()
      .then(({ data }) => setFiles(data.files))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return { files, loading };
}

// ─────────────────────────────────────────────────────────
// usePurchasedFiles
// ─────────────────────────────────────────────────────────
export function usePurchasedFiles() {
  const [files,   setFiles]   = useState([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(() => {
    setLoading(true);
    filesAPI.getPurchased()
      .then(({ data }) => setFiles(data.files))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  return { files, loading, refetch: fetch };
}

// ─────────────────────────────────────────────────────────
// useSearch — debounced full-text search
// ─────────────────────────────────────────────────────────
export function useSearch(query, delay = 350) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const timer = useRef(null);

  useEffect(() => {
    clearTimeout(timer.current);
    if (!query || query.trim().length < 2) { setResults([]); return; }
    timer.current = setTimeout(async () => {
      setLoading(true);
      try {
        const { data } = await filesAPI.search({ q: query.trim(), limit: 30 });
        setResults(data.files);
      } catch {}
      finally { setLoading(false); }
    }, delay);
    return () => clearTimeout(timer.current);
  }, [query, delay]);

  return { results, loading };
}

// ─────────────────────────────────────────────────────────
// useWallet
// ─────────────────────────────────────────────────────────
export function useWallet() {
  const [balance,      setBalance]      = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [loading,      setLoading]      = useState(false);

  const fetch = useCallback(() => {
    setLoading(true);
    paymentsAPI.getWallet()
      .then(({ data }) => {
        setBalance(data.balance);
        setTransactions(data.transactions);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const purchase = useCallback(async (fileId, method = 'wallet') => {
    const { data } = await paymentsAPI.purchase({ file_id: fileId, method });
    if (method === 'wallet') fetch(); // refresh balance
    return data;
  }, [fetch]);

  const topup = useCallback(async (amount, method, phone) => {
    const { data } = await paymentsAPI.topup({ amount, method, phone });
    return data;
  }, []);

  return { balance, transactions, loading, purchase, topup, refetch: fetch };
}

// ─────────────────────────────────────────────────────────
// useDownload — generate download token and trigger download
// ─────────────────────────────────────────────────────────
export function useDownload() {
  const [downloading, setDownloading] = useState({});

  const download = useCallback(async (fileId, fileName) => {
    setDownloading(d => ({ ...d, [fileId]: true }));
    try {
      const { data } = await filesAPI.getDownloadToken(fileId);
      const url = filesAPI.triggerDownload(data.downloadToken);
      const a   = document.createElement('a');
      a.href     = url;
      a.download = fileName || 'download';
      a.target   = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast.success('Download started!');
    } catch (e) {
      toast.error(e.response?.data?.error || 'Download failed');
    } finally {
      setDownloading(d => ({ ...d, [fileId]: false }));
    }
  }, []);

  return { download, downloading };
}

// ─────────────────────────────────────────────────────────
// useAdminStats
// ─────────────────────────────────────────────────────────
export function useAdminStats() {
  const [stats,        setStats]        = useState(null);
  const [dailyRevenue, setDailyRevenue] = useState([]);
  const [topFiles,     setTopFiles]     = useState([]);
  const [loading,      setLoading]      = useState(false);

  useEffect(() => {
    setLoading(true);
    adminAPI.getStats()
      .then(({ data }) => {
        setStats(data.stats);
        setDailyRevenue(data.dailyRevenue);
        setTopFiles(data.topFiles);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return { stats, dailyRevenue, topFiles, loading };
}

// ─────────────────────────────────────────────────────────
// useAdminUsers
// ─────────────────────────────────────────────────────────
export function useAdminUsers(search = '') {
  const [users,   setUsers]   = useState([]);
  const [loading, setLoading] = useState(false);
  const timer = useRef(null);

  const fetch = useCallback((q) => {
    setLoading(true);
    adminAPI.getUsers({ search: q || undefined })
      .then(({ data }) => setUsers(data.users))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => fetch(search), 400);
    return () => clearTimeout(timer.current);
  }, [search, fetch]);

  return { users, loading, refetch: () => fetch(search) };
}

// ─────────────────────────────────────────────────────────
// useAdminActivity
// ─────────────────────────────────────────────────────────
export function useAdminActivity() {
  const [logs,    setLogs]    = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    adminAPI.getActivity({ limit: 100 })
      .then(({ data }) => setLogs(data.logs))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return { logs, loading };
}

// ─────────────────────────────────────────────────────────
// useCreateFolder
// ─────────────────────────────────────────────────────────
export function useCreateFolder(onSuccess) {
  const [loading, setLoading] = useState(false);

  const create = useCallback(async (name, parentId) => {
    setLoading(true);
    try {
      const { data } = await foldersAPI.create({ name, parent_id: parentId || null });
      toast.success(`Folder "${name}" created`);
      onSuccess && onSuccess(data.folder);
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to create folder');
    } finally {
      setLoading(false);
    }
  }, [onSuccess]);

  return { create, loading };
}

// ─────────────────────────────────────────────────────────
// useUploadFile
// ─────────────────────────────────────────────────────────
export function useUploadFile(onSuccess) {
  const [progress, setProgress] = useState(0);
  const [loading,  setLoading]  = useState(false);

  const uploadFile = useCallback(async (file, meta) => {
    setLoading(true);
    setProgress(0);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('folder_id', meta.folderId);
      formData.append('name', meta.name || file.name);
      if (meta.description) formData.append('description', meta.description);
      formData.append('download_price', meta.price ?? 5);
      formData.append('is_published', meta.published ?? true);

      const { data } = await filesAPI.upload(formData, setProgress);
      toast.success(`"${data.file.name}" uploaded`);
      onSuccess && onSuccess(data.file);
    } catch (e) {
      toast.error(e.response?.data?.error || 'Upload failed');
    } finally {
      setLoading(false);
      setProgress(0);
    }
  }, [onSuccess]);

  return { uploadFile, loading, progress };
}
