// frontend/src/api/client.js
import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || '';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
});

// ── Request interceptor: attach access token ──────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response interceptor: auto-refresh on 401 ─────────────
let isRefreshing = false;
let failedQueue  = [];

function processQueue(error, token = null) {
  failedQueue.forEach(p => (error ? p.reject(error) : p.resolve(token)));
  failedQueue = [];
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const orig = error.config;
    if (
      error.response?.status === 401 &&
      error.response?.data?.code === 'TOKEN_EXPIRED' &&
      !orig._retry
    ) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          orig.headers.Authorization = `Bearer ${token}`;
          return api(orig);
        });
      }
      orig._retry  = true;
      isRefreshing = true;

      const refreshToken = localStorage.getItem('refreshToken');
      if (!refreshToken) {
        isRefreshing = false;
        window.dispatchEvent(new Event('auth:logout'));
        return Promise.reject(error);
      }

      try {
        const { data } = await axios.post(`${BASE_URL}/api/auth/refresh`, { refreshToken });
        localStorage.setItem('accessToken',  data.accessToken);
        localStorage.setItem('refreshToken', data.refreshToken);
        api.defaults.headers.common.Authorization = `Bearer ${data.accessToken}`;
        processQueue(null, data.accessToken);
        orig.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(orig);
      } catch (refreshErr) {
        processQueue(refreshErr, null);
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.dispatchEvent(new Event('auth:logout'));
        return Promise.reject(refreshErr);
      } finally {
        isRefreshing = false;
      }
    }
    return Promise.reject(error);
  }
);

export default api;

// ── Auth API ──────────────────────────────────────────────
export const authAPI = {
  register:           (data)  => api.post('/api/auth/register', data),
  login:              (data)  => api.post('/api/auth/login', data),
  logout:             (data)  => api.post('/api/auth/logout', data),
  refresh:            (data)  => api.post('/api/auth/refresh', data),
  oauth:              (data)  => api.post('/api/auth/oauth', data),
  me:                 ()      => api.get('/api/auth/me'),
  changePassword:     (data)  => api.patch('/api/auth/change-password', data),
  // FIX #1: Profile update
  updateProfile:      (data)  => api.patch('/api/auth/profile', data),
  // FIX #2: Password reset
  forgotPassword:     (email) => api.post('/api/auth/forgot-password', { email }),
  resetPassword:      (data)  => api.post('/api/auth/reset-password', data),
  // FIX #3: Email verification
  verifyEmail:        (token) => api.get(`/api/auth/verify-email?token=${encodeURIComponent(token)}`),
  resendVerification: ()      => api.post('/api/auth/resend-verification'),
};

// ── Folders API ───────────────────────────────────────────
export const foldersAPI = {
  getAll:   (parentId) => api.get('/api/folders', { params: { parent_id: parentId } }),
  getTree:  ()         => api.get('/api/folders/tree'),
  getOne:   (id)       => api.get(`/api/folders/${id}`),
  create:   (data)     => api.post('/api/folders', data),
  update:   (id, data) => api.patch(`/api/folders/${id}`, data),
  delete:   (id)       => api.delete(`/api/folders/${id}`),
};

// ── Files API ─────────────────────────────────────────────
export const filesAPI = {
  search:        (params)       => api.get('/api/files/search', { params }),
  getRecent:     ()             => api.get('/api/files/recent'),
  getPurchased:  ()             => api.get('/api/files/purchased'),
  getOne:        (id)           => api.get(`/api/files/${id}`),
  recordView:    (id)           => api.post(`/api/files/${id}/view`),
  getStreamUrl:  (id)           => `${BASE_URL}/api/files/${id}/stream`,
  getDownloadToken: (id)        => api.post(`/api/files/${id}/download-token`),
  triggerDownload:  (token)     => `${BASE_URL}/api/files/download/${token}`,
  upload:        (formData, onProgress) => api.post('/api/files', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => onProgress && onProgress(Math.round((e.loaded * 100) / e.total)),
  }),
  update:  (id, data)     => api.patch(`/api/files/${id}`, data),
  delete:  (id)           => api.delete(`/api/files/${id}`),
};

// ── Payments API ──────────────────────────────────────────
export const paymentsAPI = {
  getWallet:       ()     => api.get('/api/payments/wallet'),
  topup:           (data) => api.post('/api/payments/topup', data),
  purchase:        (data) => api.post('/api/payments/purchase', data),
  confirmPurchase: (data) => api.post('/api/payments/purchase/confirm', data),
  getHistory:      (p)    => api.get('/api/payments/history', { params: p }),
};

// ── Admin API ─────────────────────────────────────────────
export const adminAPI = {
  getStats:    ()          => api.get('/api/admin/stats'),
  getUsers:    (params)    => api.get('/api/admin/users', { params }),
  updateUser:  (id, data)  => api.patch(`/api/admin/users/${id}`, data),
  getActivity: (params)    => api.get('/api/admin/activity', { params }),
  publishFile: (id, val)   => api.patch(`/api/admin/files/${id}/publish`, { is_published: val }),
};

