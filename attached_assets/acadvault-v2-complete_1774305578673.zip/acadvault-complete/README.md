# 🎓 AcadVault — Academic Resource Platform

A **secure, full-stack academic resource platform** where students read materials
for free in-browser and pay to download them. Built with React, Node.js, Express,
and PostgreSQL.

---

## ✨ Features

| Feature | Details |
|---|---|
| 📂 **Folder System** | Google Drive–style hierarchy: Program → Year → Semester → Course |
| 📄 **Free Reading** | Secure in-browser viewer, watermarked with user email |
| 💰 **Paid Downloads** | Wallet units, MTN Mobile Money, Airtel Money, Mastercard |
| 🔒 **Content Protection** | No direct URLs, streaming only, expiring download tokens |
| 👤 **Authentication** | Email/password + Google/Facebook/Apple OAuth, JWT auto-refresh |
| ⚙️ **Admin Panel** | Upload files, manage folders, user management, stats dashboard |
| 🌙 **Dark / Light Mode** | Full theme with CSS variables |
| 🔍 **Live Search** | Real-time full-text search across all resources |
| 📊 **Activity Logs** | Track logins, purchases, downloads |

---

## 🚀 Quick Start — VS Code (Windows / Mac / Linux)

### Prerequisites
Install these first (free):
- **Node.js 18+** → https://nodejs.org (choose LTS)
- **PostgreSQL 14+** → https://postgresql.org OR use free cloud: https://neon.tech

### Windows — One Click
Double-click **`start.bat`** and follow the prompts.

### Mac / Linux — One Command
```bash
bash start.sh
```

### Manual Setup
```bash
# 1. Install all dependencies
cd backend  && npm install && cd ..
cd frontend && npm install && cd ..

# 2. Configure backend environment
cd backend
cp .env.example .env
# Open .env and set your DATABASE_URL and JWT secrets

# 3. Create database tables and seed demo data
node scripts/migrate.js
node scripts/seed.js
cd ..

# 4. Start backend (Terminal 1)
cd backend && npm run dev

# 5. Start frontend (Terminal 2)
cd frontend && npm start
```

Open **http://localhost:3000** in your browser ✅

---

## 🔑 Default Login Accounts

| Role | Email | Password | Notes |
|---|---|---|---|
| **Admin** | `admin@acadvault.com` | `Admin@123` | Full access, 999 units |
| **Student** | `student@demo.com` | `Student@123` | 50 units balance |

---

## 🗄️ Free PostgreSQL Options

You do **not** need to install PostgreSQL locally. Use one of these free cloud options:

| Service | Free Tier | Link |
|---|---|---|
| **Neon** | 3 GB free | https://neon.tech |
| **Supabase** | 500 MB free | https://supabase.com |
| **Railway** | $5 credit/month | https://railway.app |
| **ElephantSQL** | 20 MB free | https://elephantsql.com |

After creating a database, copy the connection string into `backend/.env`:
```
DATABASE_URL=postgresql://username:password@host:5432/dbname
```

---

## 🏗️ Project Structure

```
acadvault/
│
├── backend/                    ← Node.js / Express API
│   ├── config/
│   │   ├── db.js               ← PostgreSQL pool + transactions
│   │   └── logger.js           ← Winston logging
│   ├── middleware/
│   │   ├── auth.js             ← JWT auth guards
│   │   └── upload.js           ← Multer file validation
│   ├── routes/
│   │   ├── auth.js             ← Register, login, OAuth, refresh
│   │   ├── folders.js          ← CRUD + breadcrumbs + tree
│   │   ├── files.js            ← Upload, stream, download tokens
│   │   ├── payments.js         ← Wallet, MTN, Airtel, Stripe
│   │   └── admin.js            ← Stats, users, activity
│   ├── scripts/
│   │   ├── migrate.js          ← Apply schema.sql
│   │   └── seed.js             ← Add demo content
│   ├── services/
│   │   └── storageService.js   ← Local / AWS S3 abstraction
│   ├── utils/
│   │   └── jwt.js              ← Token signing & rotation
│   ├── schema.sql              ← Full PostgreSQL schema
│   ├── server.js               ← Express app entry point
│   ├── Dockerfile
│   └── .env.example            ← Environment template
│
├── frontend/                   ← React 18 app
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── api/
│   │   │   └── client.js       ← Axios + auto token refresh
│   │   ├── context/
│   │   │   ├── AuthContext.js  ← Global auth state
│   │   │   └── ThemeContext.js ← Dark / light mode
│   │   ├── hooks/
│   │   │   └── index.js        ← All data-fetching hooks
│   │   ├── components/
│   │   │   ├── ui/             ← Button, Input, Modal, Badge, Icons
│   │   │   ├── layout/         ← TopBar, Sidebar, AppLayout
│   │   │   ├── files/          ← FileCard, FolderCard
│   │   │   └── payments/       ← PaymentModal
│   │   ├── pages/
│   │   │   ├── HomePage.js     ← Folder browser + file grid
│   │   │   ├── FileViewerPage.js ← Protected in-browser viewer
│   │   │   ├── AuthPage.js     ← Login + register
│   │   │   ├── WalletPage.js   ← Balance + transactions + top-up
│   │   │   ├── AdminPage.js    ← Admin dashboard
│   │   │   ├── DownloadsPage.js
│   │   │   └── RecentPage.js
│   │   ├── App.js              ← Routes + providers + guards
│   │   ├── index.js            ← React root
│   │   └── index.css           ← CSS variables + global styles
│   ├── Dockerfile
│   ├── nginx-frontend.conf
│   └── package.json
│
├── docker-compose.yml          ← One-command Docker stack
├── nginx.conf                  ← Production reverse proxy + SSL
├── start.bat                   ← Windows one-click launcher
├── start.sh                    ← Mac/Linux one-click launcher
└── .env.example                ← Docker environment template
```

---

## 🐳 Docker (One Command)

```bash
# Copy and configure
cp .env.example .env
# Edit .env — change DB_PASSWORD and JWT secrets

# Start everything (PostgreSQL + Backend + Frontend)
docker-compose up --build

# First time — run in another terminal:
docker-compose exec backend node scripts/migrate.js
docker-compose exec backend node scripts/seed.js
```

Open **http://localhost:3000** ✅

---

## 🌐 Deploying Online (Free)

### Option A — Railway (Easiest)
1. Push code to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add a PostgreSQL plugin
4. Set environment variables from `backend/.env.example`
5. Done — Railway gives you a live URL

### Option B — Render
1. Push to GitHub
2. Create a Web Service (backend) + Static Site (frontend)
3. Add a free PostgreSQL database
4. Set environment variables

### Option C — Neon DB + any host
1. Create free PostgreSQL at neon.tech
2. Copy the connection string
3. Deploy backend to Railway/Render/Fly.io
4. Deploy frontend to Vercel/Netlify

---

## 🔐 Security Features

| Threat | Protection |
|---|---|
| Unauthorized downloads | Files never served publicly — JWT required |
| Direct URL file access | Private storage, UUID keys, no original filenames |
| Token theft | 15-min access tokens + rotating refresh tokens |
| Brute force | Rate limiter: 20 req/15min on auth endpoints |
| File type abuse | MIME + extension whitelist in multer |
| Content copying | Watermark overlay + right-click disabled |
| CSRF | SameSite cookies + CORS whitelist |
| SQL injection | Parameterized queries throughout |
| XSS | Helmet CSP headers |

---

## 💳 Activating Real Payments

### MTN Mobile Money (Zambia)
1. Register at https://momodeveloper.mtn.com
2. Add `MTN_SUBSCRIPTION_KEY`, `MTN_API_USER`, `MTN_API_KEY` to `.env`
3. Update `backend/routes/payments.js` → `initiatePayment()` with live API call

### Airtel Money (Zambia)
1. Register at https://developers.airtel.africa
2. Add `AIRTEL_CLIENT_ID`, `AIRTEL_CLIENT_SECRET`
3. Implement the `/collection/oauth2/token` + `/merchant/v2/payments/` flow

### Stripe (Mastercard/Visa)
1. Create account at stripe.com
2. Add `STRIPE_SECRET_KEY` to `.env`
3. Run: `npm install stripe` in backend
4. Replace stub in `payments.js` with `stripe.paymentIntents.create()`

---

## 📡 API Reference

### Auth
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | — | Create account |
| POST | `/api/auth/login` | — | Login |
| POST | `/api/auth/refresh` | — | Rotate tokens |
| POST | `/api/auth/logout` | ✓ | Invalidate session |
| POST | `/api/auth/oauth` | — | OAuth login |
| GET | `/api/auth/me` | ✓ | Get current user |
| PATCH | `/api/auth/change-password` | ✓ | Change password |

### Folders
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/folders` | — | Root or children |
| GET | `/api/folders/tree` | — | Full nested tree |
| GET | `/api/folders/:id` | — | Folder + contents + breadcrumbs |
| POST | `/api/folders` | Admin | Create folder |
| PATCH | `/api/folders/:id` | Admin | Rename / reorder |
| DELETE | `/api/folders/:id` | Admin | Delete (cascades) |

### Files
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/files/search?q=` | — | Full-text search |
| GET | `/api/files/recent` | ✓ | Recently viewed |
| GET | `/api/files/purchased` | ✓ | Owned files |
| GET | `/api/files/:id` | — | File metadata |
| POST | `/api/files/:id/view` | ✓ | Record view |
| GET | `/api/files/:id/stream` | ✓ | Stream for reading |
| POST | `/api/files/:id/download-token` | ✓ | Generate download link |
| GET | `/api/files/download/:token` | — | Deliver file |
| POST | `/api/files` | Admin | Upload file |
| PATCH | `/api/files/:id` | Admin | Update metadata |
| DELETE | `/api/files/:id` | Admin | Delete |

### Payments
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/payments/wallet` | ✓ | Balance + history |
| POST | `/api/payments/topup` | ✓ | Initiate top-up |
| POST | `/api/payments/topup/confirm` | — | Webhook |
| POST | `/api/payments/purchase` | ✓ | Buy file |
| POST | `/api/payments/purchase/confirm` | — | Webhook |
| GET | `/api/payments/history` | Admin | All transactions |

---

## 🐛 Bugs Fixed in This Version

| Bug | Fix |
|---|---|
| `Invalid time value` crash | Safe `isNaN()` guard on all date formatting |
| `require()` inside React components | Replaced with proper `useNavigate()` hook |
| Admin panel flickering | Stable role-based guard in `RequireAdmin` |
| Login not redirecting | `RedirectIfAuth` wrapper on `/login` route |
| Logout not clearing session | Full token + localStorage clear + navigate |
| Profile page crash | Null checks + safe date + proper imports |
| Bad folder names in zip | Cleaned up shell expansion artefacts |

---

*AcadVault © 2025 — Built for students in Zambia 🇿🇲 and beyond*
