#!/bin/bash
# ============================================================
#  AcadVault — Mac / Linux Quick Start
#  Run: bash start.sh
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║         AcadVault  Launcher          ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${NC}"

# Check Node.js
if ! command -v node &>/dev/null; then
  echo -e "${RED}❌ Node.js not found. Install from https://nodejs.org${NC}"
  exit 1
fi
echo -e "${GREEN}✅ Node.js $(node -v)${NC}"

# Create .env if missing
if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo -e "${YELLOW}📋 Created backend/.env${NC}"
  echo -e "${YELLOW}   → Open backend/.env and add your PostgreSQL DATABASE_URL${NC}"
  echo -e "${YELLOW}   → Then run this script again${NC}"
  exit 0
fi

# Install deps
if [ ! -d backend/node_modules ]; then
  echo -e "${BLUE}📦 Installing backend...${NC}"
  cd backend && npm install && cd ..
fi
if [ ! -d frontend/node_modules ]; then
  echo -e "${BLUE}📦 Installing frontend...${NC}"
  cd frontend && npm install && cd ..
fi

# Migrate?
echo ""
read -p "Run database migration? (first time only) [y/N]: " MIGRATE
if [[ "$MIGRATE" =~ ^[Yy]$ ]]; then
  cd backend
  node scripts/migrate.js
  node scripts/seed.js
  cd ..
fi

# Start backend
echo -e "${BLUE}🚀 Starting backend on :5000...${NC}"
cd backend && npm run dev &
BACKEND_PID=$!
cd ..

sleep 2

# Start frontend
echo -e "${BLUE}🚀 Starting frontend on :3000...${NC}"
cd frontend && npm start &
FRONTEND_PID=$!
cd ..

echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  AcadVault running!${NC}"
echo -e "${GREEN}  → http://localhost:3000${NC}"
echo ""
echo "  Admin:   admin@acadvault.com / Admin@123"
echo "  Student: student@demo.com    / Student@123"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait and clean up on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Stopped.'" EXIT
wait
